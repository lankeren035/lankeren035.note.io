# Debug 录制与可视化说明

本版本用于排查“发送端已经发了很多帧，但检测端在某一帧提前判定”的情况。

## 1. Debug 模式会生成什么

开启 debug 后会生成两类文件，默认在项目根目录：

```text
debug_runs/
  det_<session_id>.jsonl      # 检测端逐帧检测结果
  send_<session_id>.mp4       # 发送端从 start 到 end 保存的视频
  send_<session_id>.json      # 发送端本轮元信息和检测返回结果
  vis_<session_id>.mp4        # visualize_debug_session.py 生成的可视化视频
```

## 2. 检测端 debug 文件内容

`det_<session_id>.jsonl` 是 JSON Lines，每一行一个 JSON。

### start 行

```json
{"type":"start","session_id":"xxx","source":"camera_0","fps":30.0}
```

### frame 行

每一帧会记录球和人体关键点情况：

```json
{
  "type": "frame",
  "frame_idx": 12,
  "time_sec": 0.4,
  "ball": {
    "detected": true,
    "center": [620.4, 351.8],
    "bbox": [600.1, 330.2, 641.0, 372.6],
    "conf": 0.742,
    "class": "sports ball",
    "radius": 20.5
  },
  "feet": [
    {"x": 310.2, "y": 501.4, "conf": 0.81, "label": "p0_right_toe"}
  ],
  "hands": []
}
```

### result 行

```json
{"type":"result","result":{...检测端返回给发送端的结果...}}
```

## 3. 发送端 debug 视频

摄像头发送端开启 debug 后，会把从 `start` 到 `end` 的所有摄像头帧保存为：

```text
debug_runs/send_<session_id>.mp4
```

这个视频的第 `N` 帧对应检测端 debug 里的：

```text
frame_idx = N
```

## 4. 推荐 debug 参数

### service_kick_detector_tcp_win.ps1

```powershell
$DEBUG_DETECTIONS = "1"
$DEBUG_LOG_DIR = "$PROJECT_ROOT\debug_runs"
$DEBUG_FULL_SESSION = "1"
$SOCKET_TIMEOUT = "0"
```

说明：

```text
DEBUG_FULL_SESSION=1 时，检测端不会检测到结果就立刻停止处理；
它会一直处理到发送端发 end，所以 debug 文件更完整。
```

### mock_camera_sender_tcp_win.ps1

```powershell
$DEBUG_SAVE_VIDEO = "1"
$DEBUG_SAVE_DIR = "$PROJECT_ROOT\debug_runs"
```

为了让 debug 样例自动结束，建议临时设置：

```powershell
$MAX_SECONDS = "8"
```

或者在摄像头预览窗口按 `q` 手动结束本轮。

## 5. 可视化

运行：

```bat
python visualize_debug_session.py --debug-dir D:\football\debug_runs --session-id <session_id>
```

例如：

```bat
python visualize_debug_session.py --debug-dir D:\football\debug_runs --session-id 7a12bc34de56
```

输出：

```text
debug_runs/vis_<session_id>.mp4
```

可视化内容：

```text
绿色框：球检测框
绿色点：球心
蓝色点：脚/脚尖关键点
橙色点：手腕关键点
红框：最终判定踢球帧
红点：kick_point
```

## 6. 注意

普通运行时可以关闭 debug：

```powershell
$DEBUG_DETECTIONS = "0"
$DEBUG_SAVE_VIDEO = "0"
```

这样不会写 jsonl，不会保存视频，不影响正常检测速度。
