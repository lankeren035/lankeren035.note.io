#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Optional, Tuple

import cv2


def load_jsonl(path: Path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def find_files(debug_dir: Path, session_id: str) -> Tuple[Path, Path]:
    det = debug_dir / f"det_{session_id}.jsonl"
    vid = debug_dir / f"send_{session_id}.mp4"
    if not det.is_file():
        raise FileNotFoundError(det)
    if not vid.is_file():
        raise FileNotFoundError(vid)
    return vid, det


def to_int_pt(p):
    return int(round(float(p[0]))), int(round(float(p[1])))


def draw_text(img, text, xy, scale=0.55, color=(255, 255, 255), bg=(0, 0, 0)):
    x, y = xy
    (tw, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)
    cv2.rectangle(img, (x, y - th - base - 3), (x + tw + 4, y + 3), bg, -1)
    cv2.putText(img, text, (x + 2, y - base), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


def draw_frame(img, row: Optional[Dict], result: Optional[Dict], frame_idx: int):
    if row is None:
        draw_text(img, f"frame={frame_idx} no detector row", (10, 25), color=(0, 255, 255))
        return img

    ball = row.get("ball") or {}
    if ball.get("detected"):
        bbox = ball.get("bbox")
        center = ball.get("center")
        conf = ball.get("conf")
        if bbox:
            x1, y1, x2, y2 = [int(round(float(v))) for v in bbox]
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            draw_text(img, f"ball {conf:.3f}" if isinstance(conf, (int, float)) else "ball", (x1, max(20, y1 - 5)), color=(0, 255, 0))
        if center:
            cv2.circle(img, to_int_pt(center), 5, (0, 255, 0), -1)
    else:
        draw_text(img, "ball: none", (10, 50), color=(0, 0, 255))

    for p in row.get("feet") or []:
        xy = (int(round(float(p["x"]))), int(round(float(p["y"]))))
        cv2.circle(img, xy, 4, (255, 0, 0), -1)
        cv2.putText(img, p.get("label", "foot"), (xy[0] + 4, xy[1] - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 0, 0), 1)

    for p in row.get("hands") or []:
        xy = (int(round(float(p["x"]))), int(round(float(p["y"]))))
        cv2.circle(img, xy, 4, (0, 165, 255), -1)

    kick = (result or {}).get("kick") if result else None
    if kick:
        kidx = int(kick.get("frame_idx", -1))
        if frame_idx == kidx:
            cv2.rectangle(img, (2, 2), (img.shape[1] - 3, img.shape[0] - 3), (0, 0, 255), 4)
            kp = ((kick.get("kick_point") or {}).get("px"))
            if kp:
                cv2.circle(img, to_int_pt(kp), 9, (0, 0, 255), -1)
            draw_text(img, f"KICK frame={kidx} conf={float(kick.get('confidence',0.0)):.3f} kind={kick.get('kind','')}", (10, 28), color=(0, 0, 255))
        else:
            draw_text(img, f"frame={frame_idx} kick={kidx}", (10, 28), color=(255, 255, 255))
    else:
        draw_text(img, f"frame={frame_idx} no kick", (10, 28), color=(255, 255, 255))
    return img


def main():
    ap = argparse.ArgumentParser("Visualize detector debug jsonl on sender debug video")
    ap.add_argument("--debug-dir", default="debug_runs")
    ap.add_argument("--session-id", default="", help="session id; if set, --video/--det-log are optional")
    ap.add_argument("--video", default="")
    ap.add_argument("--det-log", default="")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    debug_dir = Path(args.debug_dir)
    if args.session_id:
        video_path, det_path = find_files(debug_dir, args.session_id)
    else:
        if not args.video or not args.det_log:
            raise SystemExit("Provide either --session-id or both --video and --det-log")
        video_path, det_path = Path(args.video), Path(args.det_log)

    rows = load_jsonl(det_path)
    frame_rows = {int(r["frame_idx"]): r for r in rows if r.get("type") == "frame"}
    result = None
    for r in rows:
        if r.get("type") == "result":
            result = r.get("result")

    out = Path(args.out) if args.out else video_path.with_name(video_path.stem.replace("send_", "vis_") + ".mp4")
    out.parent.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    writer = cv2.VideoWriter(str(out), cv2.VideoWriter_fourcc(*"mp4v"), float(fps), (w, h))
    if not writer.isOpened():
        raise RuntimeError(f"cannot open writer: {out}")

    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = draw_frame(frame, frame_rows.get(idx), result, idx)
        writer.write(frame)
        idx += 1

    cap.release()
    writer.release()
    print(f"[DONE] wrote {out}")


if __name__ == "__main__":
    main()
