@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0mock_camera_sender_tcp_win.ps1"
pause
