# 可见球高速位移优先版

本版修改的是踢球事件判断逻辑，不修改 TCP 服务、摄像头发送端、debug 记录和可视化流程。

## 核心策略

近距离摄像头场景中，球大概率一直可见，因此首选证据应是：

```text
球连续可见 + 球心发生高速大位移 + 脚部运动方向与球运动方向一致
```

不再先用“脚球距离”筛 contact candidate。原因是摄像头可能没有拍到脚和球刚刚接触的那一帧，只拍到了前后相邻帧，此时脚球距离会误导判断。

## 事件优先级

1. `ball_speed_foot_dir`
   - 球从上一帧到当前帧发生大位移；
   - 脚部在相邻小窗口内也发生位移；
   - 脚位移方向和球位移方向同向。

2. `ball_speed_strong`
   - 如果姿态暂时不可用，但球位移极大，也允许触发。
   - 用于避免 pose 漏检导致漏判。

3. `blur_loss`
   - 只有可见球高速位移逻辑不成立时才启用；
   - 对应球静止/低速后突然丢失、多帧检测不到的运动模糊情况。

## 新增可调参数

在 `service_kick_detector_tcp_win.ps1` 中可调：

```powershell
$MIN_BALL_MOVE_PX = "35"
$MIN_BALL_MOVE_RATIO = "0.03"
$MIN_BALL_SPEED_PXPF = "0"
$FOOT_BALL_SAME_DIR_COS = "0.35"
$MIN_FOOT_MOVE_PX = "15"
$STRONG_BALL_MOVE_MULT = "2.0"
$BALL_SPEED_LOOKBACK = "3"
$BALL_SPEED_JUMP_RATIO = "1.6"
```

含义：

- `MIN_BALL_MOVE_PX`：球心单步位移的像素门槛。
- `MIN_BALL_MOVE_RATIO`：球心单步位移至少达到图像宽度的比例。
- `MIN_BALL_SPEED_PXPF`：每帧球心速度门槛；0 表示复用上面两个参数得到的门槛。
- `FOOT_BALL_SAME_DIR_COS`：脚位移与球位移同向的最低余弦值。
- `MIN_FOOT_MOVE_PX`：脚至少移动多少像素才算有效同向证据。
- `STRONG_BALL_MOVE_MULT`：没有脚同向证据时，球位移必须达到硬门槛的多少倍。
- `BALL_SPEED_LOOKBACK`：计算前序球速中值时向前看几帧。
- `BALL_SPEED_JUMP_RATIO`：当前球速至少是前序中值的多少倍。

## 调参建议

如果仍然静止误报：

```powershell
$MIN_BALL_MOVE_PX = "50"
$MIN_BALL_MOVE_RATIO = "0.04"
$STRONG_BALL_MOVE_MULT = "2.5"
```

如果真实踢球漏检：

```powershell
$MIN_BALL_MOVE_PX = "25"
$MIN_BALL_MOVE_RATIO = "0.02"
$FOOT_BALL_SAME_DIR_COS = "0.25"
$MIN_FOOT_MOVE_PX = "10"
```

## 关于返回帧

`ball_speed_foot_dir` 的事件帧默认在大位移前后两帧中选择更接近脚的一帧。由于真实摄像头可能没拍到精确接触帧，结果可能在真实答案前后 1 帧内波动。debug 可视化时优先看 evidence 中的：

```text
ball_step=当前高速位移发生的帧
move_px=球心位移
foot_cos=脚和球同向程度
```
