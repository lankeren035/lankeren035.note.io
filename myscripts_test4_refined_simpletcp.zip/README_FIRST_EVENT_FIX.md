# First-event online fix

本版修正足球踢球检测在线逻辑：

1. 默认只返回第一个有效 kick。
2. 主判定是：球连续可见并发生大位移，同时脚在前几帧或当前帧与球同方向移动。
3. 在线 early stop 阶段默认不允许 blur_loss fallback 抢先触发，避免开头偶发丢球/框跳变误报。
4. blur_loss fallback 只在最终没有主事件时兜底。
5. `--debug-full-session` 会故意关闭 early stop，只用于录完整 debug，不应用来判断真实在线是否能提前停止。

如果要离线排查所有补踢事件，才加：

```bash
--return-all-events
```

如果确实要让丢球 fallback 在线提前返回，才加：

```bash
--allow-blur-fallback-early
```
