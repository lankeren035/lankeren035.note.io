# kick detector v2 debug fix

本版修复两个关键误判：

1. 视频 1 开头第一二帧的球框/脚点跳变不能当 kick。
   默认忽略开头 `--event-search-start-sec 0.80` 秒。需要立即检测时可改成 0。

2. 视频 4 的 75/76 帧不能仅靠“脚之前动过 + 球大位移”触发。
   主逻辑现在要求 event 帧或前一帧必须有真实球框，并且附近有脚点支持：
   `--contact-support-dist-norm 2.25`。
   注意这不是旧版“先按距离找候选”，主证据仍然是球大位移。

3. 支持短暂漏球：例如 128 有球、129 漏检、130 球已飞出，会触发
   `ball_gap_reappear_foot_dir`。

4. 增加 debug 决策输出：
   - 启动服务加 `--debug-detections --debug-decision --debug-full-session`
   - jsonl 里会新增 `type=decision`，包含 `candidate_debug_top`，能看到每个大位移候选为什么被 accepted 或 rejected。

回放已有 debug jsonl：

```bash
python replay_debug_jsonl.py --dir debug_runs --debug-candidate-limit 20
```

这次在你提供的四个 debug jsonl 上回放结果：

- 1-1-193.jsonl: old frame_idx=1 -> new frame_idx=130
- 2-102-255.jsonl: old frame_idx=101 / frame_id=102 -> new 保持 frame_idx=101 / frame_id=102
- 3-60-174.jsonl: old frame_idx=60 -> new frame_idx=60
- 4-76-601.jsonl: old frame_idx=76 -> new frame_idx=327

在线模式 `debug_full_session=1` 会继续跑完整段；这不代表不能 early stop。
本版会在 `type=decision` 里写 `would_early_stop`，用于判断如果不全量调试，实际会在哪个前缀触发。

## 2026-05-22 final small fixes

### Local-video sender keyboard control

`mock_sender_tcp.py` now keeps per-video progress in memory.

- Press `Enter`: process the next video in the list.
- Press `Space` then `Enter`: continue the current video's remaining frames from the last sent frame.
- Press `q`: quit.

The detector still returns the first valid event in each segment. The sender adds these fields to the returned JSON:

- `sender.global_start_frame`: original-video frame where this segment starts.
- `sender.global_next_frame`: next original-video frame to send if continuing.
- `sender.global_event_frame_idx`: event frame converted back to original-video 0-based index.
- `sender.global_event_frame_id`: event frame converted back to original-video 1-based id.

### PowerShell comment spacing

All `.ps1` scripts now keep an empty line around comment blocks to avoid PowerShell line-continuation/comment adjacency issues.
