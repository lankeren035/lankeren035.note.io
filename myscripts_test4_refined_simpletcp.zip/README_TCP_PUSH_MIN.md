# TCP 推帧版使用说明

## 协议

现在只有一种客户端到服务端的数据包：

```text
uint32_be payload_len + payload
payload = JSON header + \n\n + JPEG bytes
```

不再使用 start 包和 end 包。服务端收到第一帧就开始处理；检测到踢球事件后立刻返回 JSON，然后重置，继续监听下一次帧包。

为了防止发送端在收到结果前已经多发了少量帧，服务端返回结果后会短暂丢弃 socket 中已经缓存的残留帧。

## 本地视频发送端

```bash
python mock_sender_tcp.py --video-dir videos
```

交互：

```text
Enter：处理下一个视频
Space + Enter：继续当前视频后续帧
q：退出
```

## 摄像头发送端

```bash
python mock_camera_sender_tcp.py --camera-index 0
```

交互：

```text
Enter/Space：继续摄像头检测
q：退出
```

## 默认在线参数

```text
online_chunk = 4
online_wait_sec = 0.12
stable_chunks = 1
```

`online_wait_sec` 在代码中的最小等待帧数已经改为 0，完全由外部参数控制。
