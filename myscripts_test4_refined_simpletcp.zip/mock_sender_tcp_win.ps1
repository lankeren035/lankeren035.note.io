$ErrorActionPreference = "Stop"

function Use-Env($Name, $Default) {
  $v = [Environment]::GetEnvironmentVariable($Name)
  if ($null -ne $v) {
    $s = [string]$v
    if ($s.Trim() -ne "") { return $s.Trim() }
  }
  return [string]$Default
}

function Add-Opt([System.Collections.ArrayList]$ArgsList, [string]$Name, $Value) {
  $s = [string]$Value
  if ($null -eq $Value -or $s.Trim() -eq "") {
    throw "Missing value for $Name"
  }
  [void]$ArgsList.Add($Name)
  [void]$ArgsList.Add($s)
}

$SCRIPT_DIR   = $PSScriptRoot
$PROJECT_ROOT = Use-Env "PROJECT_ROOT" (Split-Path -Parent $SCRIPT_DIR)
$PYTHON       = Use-Env "PYTHON" "D:\anaconda3\envs\football\python.exe"

if (!(Test-Path $PYTHON)) {
  throw "Python not found: $PYTHON. Edit PYTHON in this ps1 or set environment variable PYTHON."
}

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

# 模拟发送端：按回车后读取本地视频，主动推 JPEG 帧到检测端 TCP 端口。
# 不需要 ffmpeg，不需要 RTSP server。

$DETECTOR_HOST = Use-Env "DETECTOR_HOST" "127.0.0.1"
$DETECTOR_PORT = Use-Env "DETECTOR_PORT" "19090"
$VIDEO_DIR     = Use-Env "VIDEO_DIR" "$PROJECT_ROOT\videos"
$VIDEO         = Use-Env "VIDEO" ""
$JPEG_QUALITY  = Use-Env "JPEG_QUALITY" "85"
$MAX_SECONDS   = Use-Env "MAX_SECONDS" "20"
$MAX_FRAMES    = Use-Env "MAX_FRAMES" "0"
$REALTIME      = Use-Env "REALTIME" "1"
$ONCE          = Use-Env "ONCE" "0"

if (!(Test-Path $VIDEO_DIR) -and $VIDEO.Trim() -eq "") {
  throw "VIDEO_DIR not found: $VIDEO_DIR. Edit VIDEO_DIR in this ps1 or set environment variable VIDEO."
}

Write-Host "[SENDER PS1] PROJECT_ROOT=$PROJECT_ROOT"
Write-Host "[SENDER PS1] DETECTOR=$DETECTOR_HOST`:$DETECTOR_PORT"
Write-Host "[SENDER PS1] VIDEO_DIR=$VIDEO_DIR"

$ArgsList = New-Object System.Collections.ArrayList
[void]$ArgsList.Add("$SCRIPT_DIR\mock_sender_tcp.py")
Add-Opt $ArgsList "--host" $DETECTOR_HOST
Add-Opt $ArgsList "--port" $DETECTOR_PORT
Add-Opt $ArgsList "--video-dir" $VIDEO_DIR
Add-Opt $ArgsList "--jpeg-quality" $JPEG_QUALITY
Add-Opt $ArgsList "--max-seconds" $MAX_SECONDS
Add-Opt $ArgsList "--max-frames" $MAX_FRAMES
if ($REALTIME -eq "1") { [void]$ArgsList.Add("--realtime") }
if ($ONCE -eq "1") { [void]$ArgsList.Add("--once") }
if ($VIDEO.Trim() -ne "") {
  [void]$ArgsList.Add("--video")
  [void]$ArgsList.Add($VIDEO)
}

& $PYTHON @ArgsList
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
