@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0visualize_debug_all_win.ps1"
pause
