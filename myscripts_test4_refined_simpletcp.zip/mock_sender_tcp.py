#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Local-video sender for TCP kick detector.

Interaction:
- Enter: process next video.
- Space + Enter: continue current video from the saved frame position.
- q: quit.

Protocol: every client->server packet is one frame packet containing JSON header + JPEG image.
No separate start/end packets are used.
"""
from __future__ import annotations

import argparse
import json
import socket
import time
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

import cv2

from tcp_packet import NonBlockingJsonReader, make_frame_packet, recv_json, send_packet

VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v"}


def collect_videos(video_dir: Path, video: str = "") -> List[Path]:
    if video:
        p = Path(video).resolve()
        if not p.is_file():
            raise FileNotFoundError(p)
        return [p]
    root = video_dir.resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    xs = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in VIDEO_EXTS)
    if not xs:
        raise RuntimeError(f"no videos found under: {root}")
    return xs


def encode_and_send_frame(sock: socket.socket, frame, meta: Dict, jpeg_quality: int) -> None:
    ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
    if not ok:
        raise RuntimeError("JPEG encode failed")
    send_packet(sock, make_frame_packet(meta, enc.tobytes()))


def send_video_segment(args, sock: socket.socket, video_path: Path, start_frame: int = 0) -> Dict:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    start_frame = max(0, int(start_frame))
    if total_frames > 0 and start_frame >= total_frames:
        cap.release()
        return {"status": "eof", "event": "no_event", "source": str(video_path), "sender": {
            "video": str(video_path), "global_start_frame": start_frame, "global_next_frame": start_frame,
            "total_frames": total_frames, "sent_frames": 0, "eof": True}}

    if start_frame > 0:
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

    fps = float(cap.get(cv2.CAP_PROP_FPS) or args.fps or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = float(args.fps or 25.0)
    delay = (1.0 / fps) if args.realtime else 0.0

    session_id = uuid4().hex[:12]
    reader = NonBlockingJsonReader()
    local_count = 0
    t0 = time.time()
    got_result = None

    try:
        while True:
            result = reader.try_recv(sock)
            if result is not None:
                got_result = result
                print(f"[SENDER] result before next frame, local_sent={local_count}, global_next={start_frame + local_count}", flush=True)
                break

            if args.max_frames > 0 and local_count >= args.max_frames:
                break
            if args.max_seconds > 0 and (local_count / max(fps, 1.0)) >= args.max_seconds:
                break

            ok, frame = cap.read()
            if not ok:
                break

            global_frame_idx = start_frame + local_count
            next_global = global_frame_idx + 1
            is_last = bool(
                (total_frames > 0 and next_global >= total_frames) or
                (args.max_frames > 0 and local_count + 1 >= args.max_frames) or
                (args.max_seconds > 0 and ((local_count + 1) / max(fps, 1.0)) >= args.max_seconds)
            )
            meta = {
                "session_id": session_id,
                "source": f"{video_path.name}@frame{start_frame}",
                "fps": fps,
                "frame_idx": local_count,
                "global_frame_idx": global_frame_idx,
                "is_last": is_last,
                "params": {"sender_start_frame": int(start_frame), "sender_video": str(video_path)},
            }
            encode_and_send_frame(sock, frame, meta, args.jpeg_quality)
            local_count += 1

            if local_count % 10 == 0:
                print(f"[SENDER] sent local_frame={local_count}, global_next={start_frame + local_count}", flush=True)

            result = reader.try_recv(sock)
            if result is not None:
                got_result = result
                print(f"[SENDER] result at local_sent={local_count}, global_next={start_frame + local_count}", flush=True)
                break

            if is_last:
                break
            if delay > 0:
                time.sleep(delay)

        if got_result is None:
            print(f"[SENDER] segment sent, local_frames={local_count}, global_next={start_frame + local_count}, wait result...", flush=True)
            got_result = recv_json(sock)

        global_next_frame = start_frame + local_count
        got_result.setdefault("sender", {})
        got_result["sender"].update({
            "sent_frames": local_count,
            "send_time_sec": time.time() - t0,
            "video": str(video_path),
            "global_start_frame": int(start_frame),
            "global_next_frame": int(global_next_frame),
            "total_frames": int(total_frames),
            "eof": bool(total_frames > 0 and global_next_frame >= total_frames),
        })

        kick = got_result.get("kick")
        if isinstance(kick, dict) and "frame_idx" in kick:
            got_result["sender"]["global_event_frame_idx"] = int(start_frame) + int(kick["frame_idx"])
            got_result["sender"]["global_event_frame_id"] = got_result["sender"]["global_event_frame_idx"] + 1
        return got_result
    finally:
        cap.release()


def build_argparser():
    p = argparse.ArgumentParser("Local video TCP frame sender")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=19090)
    p.add_argument("--video", default="", help="single video path; if empty, use --video-dir")
    p.add_argument("--video-dir", default="videos")
    p.add_argument("--jpeg-quality", type=int, default=85)
    p.add_argument("--fps", type=float, default=25.0, help="fallback fps if video fps is invalid")
    p.add_argument("--max-seconds", type=float, default=20.0)
    p.add_argument("--max-frames", type=int, default=0)
    p.add_argument("--connect-timeout", type=float, default=10.0)
    p.add_argument("--realtime", action="store_true", help="send frames according to original fps; default sends as fast as possible")
    p.add_argument("--once", action="store_true", help="send one segment and exit")
    return p


def main():
    args = build_argparser().parse_args()
    videos = collect_videos(Path(args.video_dir), args.video)
    print(f"[SENDER] videos={len(videos)}")
    for i, v in enumerate(videos):
        print(f"  [{i}] {v}")

    print(f"[SENDER] connect {args.host}:{args.port}")
    with socket.create_connection((args.host, int(args.port)), timeout=float(args.connect_timeout)) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        print("[SENDER] connected")

        next_video_idx = 0
        current_video_idx: Optional[int] = None
        progress_by_video = {str(v): 0 for v in videos}

        while True:
            if args.once:
                cmd_raw = ""
            else:
                current_desc = "none" if current_video_idx is None else f"[{current_video_idx}] {videos[current_video_idx].name}"
                next_desc = f"[{next_video_idx % len(videos)}] {videos[next_video_idx % len(videos)].name}"
                cmd_raw = input(
                    "\nEnter=next video, Space=continue current video, q=quit\n"
                    f"current: {current_desc}\nnext   : {next_desc}\n> "
                )

            if cmd_raw.strip().lower() in {"q", "quit", "exit"}:
                break
            if cmd_raw == "" or args.once:
                video_idx = next_video_idx % len(videos)
                next_video_idx += 1
                current_video_idx = video_idx
            elif cmd_raw == " ":
                if current_video_idx is None:
                    current_video_idx = 0
                    next_video_idx = max(next_video_idx, 1)
                video_idx = current_video_idx
            else:
                print("[SENDER] unknown command. Use Enter, Space, or q.")
                continue

            video_path = videos[video_idx]
            start_frame = int(progress_by_video.get(str(video_path), 0))
            print(f"[SENDER] selected [{video_idx}] {video_path.name}, start_frame={start_frame}")

            try:
                result = send_video_segment(args, sock, video_path, start_frame=start_frame)
                print(json.dumps(result, ensure_ascii=False, indent=2))
                sender = result.get("sender", {}) if isinstance(result, dict) else {}
                if "global_next_frame" in sender:
                    progress_by_video[str(video_path)] = int(sender["global_next_frame"])
                    print(f"[SENDER] saved progress: {video_path.name} -> frame {progress_by_video[str(video_path)]}")
            except Exception as exc:
                print(f"[SENDER][ERROR] {exc}")
                break

            if args.once:
                break


if __name__ == "__main__":
    main()
