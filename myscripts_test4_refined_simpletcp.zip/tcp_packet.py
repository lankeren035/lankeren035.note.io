#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Small length-prefixed TCP packet helpers.

Frame packet format, no separate start/end packet:
  uint32_be payload_len
  payload = utf8_json_header + b"\n\n" + jpeg_bytes

The JSON header may contain fps/source/session_id/frame_idx/is_last/params.
Every client-to-server packet contains one JPEG image.
"""
from __future__ import annotations

import json
import socket
import struct
from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np

MAX_PACKET_BYTES = 64 * 1024 * 1024
_HEADER_SEP = b"\n\n"


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks = []
    left = int(n)
    while left > 0:
        b = sock.recv(left)
        if not b:
            raise EOFError("socket closed while receiving")
        chunks.append(b)
        left -= len(b)
    return b"".join(chunks)


def recv_packet(sock: socket.socket) -> bytes:
    raw_len = recv_exact(sock, 4)
    n = struct.unpack("!I", raw_len)[0]
    if n <= 0 or n > MAX_PACKET_BYTES:
        raise RuntimeError(f"invalid packet length: {n}")
    return recv_exact(sock, n)


def send_packet(sock: socket.socket, payload: bytes) -> None:
    if len(payload) <= 0 or len(payload) > MAX_PACKET_BYTES:
        raise ValueError(f"invalid packet length: {len(payload)}")
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def send_json(sock: socket.socket, data: Dict[str, Any]) -> None:
    raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
    send_packet(sock, raw)


def recv_json(sock: socket.socket) -> Dict[str, Any]:
    raw = recv_packet(sock)
    return json.loads(raw.decode("utf-8", errors="replace"))


def make_frame_packet(meta: Dict[str, Any], jpeg_bytes: bytes) -> bytes:
    if not jpeg_bytes:
        raise ValueError("empty jpeg payload")
    header = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return header + _HEADER_SEP + jpeg_bytes


def parse_frame_packet(payload: bytes) -> Tuple[Dict[str, Any], np.ndarray]:
    if _HEADER_SEP not in payload:
        raise RuntimeError("frame packet missing JSON header separator")
    raw_header, jpg = payload.split(_HEADER_SEP, 1)
    meta = json.loads(raw_header.decode("utf-8", errors="replace"))
    arr = np.frombuffer(jpg, dtype=np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        raise RuntimeError("cannot decode JPEG frame")
    return meta, frame


def recv_frame_packet(sock: socket.socket) -> Tuple[Dict[str, Any], np.ndarray]:
    return parse_frame_packet(recv_packet(sock))


class NonBlockingJsonReader:
    def __init__(self):
        self.buf = bytearray()
        self.need: Optional[int] = None

    def try_recv(self, sock: socket.socket) -> Optional[Dict[str, Any]]:
        import select
        readable, _, _ = select.select([sock], [], [], 0)
        if not readable:
            return None
        b = sock.recv(65536)
        if not b:
            return None
        self.buf.extend(b)

        if self.need is None:
            if len(self.buf) < 4:
                return None
            self.need = struct.unpack("!I", bytes(self.buf[:4]))[0]
            del self.buf[:4]
            if self.need <= 0 or self.need > MAX_PACKET_BYTES:
                raise RuntimeError(f"invalid result packet length: {self.need}")

        if len(self.buf) < self.need:
            return None
        raw = bytes(self.buf[:self.need])
        del self.buf[:self.need]
        self.need = None
        return json.loads(raw.decode("utf-8", errors="replace"))
