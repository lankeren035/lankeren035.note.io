# 本地摄像头实时发送端说明

本版本基于 `myscripts_test2.zip`，检测端协议不变：

- start 包：`uint32_be长度 + JSON`
- 视频帧包：`uint32_be长度 + JPEG bytes`
- end 包：`uint32_be(0)`

区别只是发送端的视频来源变了：

- 原来：`cv2.VideoCapture(video_path)` 从 mp4 读帧
- 现在：`cv2.VideoCapture(camera_index)` 从本地摄像头实时读帧

## 启动方式

先启动检测端：

```bat
service_kick_detector_tcp_win.bat
```

再启动摄像头发送端：

```bat
mock_camera_sender_tcp_win.bat
```

发送端启动后会打开摄像头，按 Enter 开始一轮检测。检测端返回结果后，本轮停止；再次按 Enter 可以开始下一轮。

## 参数位置

改 `mock_camera_sender_tcp_win.ps1`：

```powershell
$CAMERA_INDEX = "0"
$WIDTH = "1280"
$HEIGHT = "720"
$FPS = "30"
$JPEG_QUALITY = "85"
$MAX_SECONDS = "0"
$MAX_FRAMES = "0"
$SHOW = "1"
```

`MAX_SECONDS=0` 和 `MAX_FRAMES=0` 表示不限制，直到检测端返回结果或手动停止。

## 传输格式

每一帧：

```python
ok, frame = cap.read()
ok, enc = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality])
send_packet(sock, enc.tobytes())
```

其中 `send_packet` 是：

```python
sock.sendall(struct.pack("!I", len(payload)) + payload)
```

所以真实对接时仍然是逐帧 JPEG 流，不是一次性发送视频文件。
