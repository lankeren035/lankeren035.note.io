# Debug 录制与自动可视化说明

本版本用于排查“发送端发了很多帧，但检测端提前判定”的情况。

## 1. Debug 模式生成的原始文件

开启 debug 后，每一轮 start 到 end 会生成：

```text
debug_runs/
  det_<session_id>.jsonl      # 检测端逐帧检测结果
  send_<session_id>.mp4       # 发送端保存的原始摄像头视频
  send_<session_id>.json      # 发送端元信息和检测返回结果
```

检测端逐帧文件 `det_<session_id>.jsonl` 记录：

```json
{"type":"frame","frame_idx":12,"ball":{"detected":true,"center":[620.4,351.8],"bbox":[600.1,330.2,641.0,372.6],"conf":0.742},"feet":[{"x":310.2,"y":501.4,"label":"p0_right_toe"}],"hands":[]}
```

## 2. 开启 debug

### service_kick_detector_tcp_win.ps1

```powershell
$DEBUG_DETECTIONS = "1"
$DEBUG_LOG_DIR = "$PROJECT_ROOT\debug_runs"
$DEBUG_FULL_SESSION = "1"
$SOCKET_TIMEOUT = "0"
```

`DEBUG_FULL_SESSION=1` 表示检测端检测到结果后仍继续处理到发送端发 end，这样 debug 文件更完整。

### mock_camera_sender_tcp_win.ps1

```powershell
$DEBUG_SAVE_VIDEO = "1"
$DEBUG_SAVE_DIR = "$PROJECT_ROOT\debug_runs"
```

调试时建议给摄像头发送端设一个自动结束时间，例如：

```powershell
$MAX_SECONDS = "8"
```

或者在摄像头预览窗口按 `q` 结束本轮。

## 3. 自动可视化

直接双击：

```bat
visualize_debug_all_win.bat
```

它会自动扫描：

```text
debug_runs/det_<session_id>.jsonl
debug_runs/send_<session_id>.mp4
```

只要两个文件的 `<session_id>` 能配对，就会生成：

```text
debug_runs/vis_<session_id>.mp4
debug_runs/vis_<session_id>_frames/
  000000.jpg
  000001.jpg
  ...
```

如果已经存在：

```text
debug_runs/vis_<session_id>.mp4
```

则默认跳过该 session，不重复生成。

## 4. 手动运行

处理整个 debug 文件夹：

```bat
python visualize_debug_session.py --debug-dir D:\football\debug_runs
```

只处理一个 session：

```bat
python visualize_debug_session.py --debug-dir D:\football\debug_runs --session-id 7a12bc34de56
```

强制重新生成：

```bat
python visualize_debug_session.py --debug-dir D:\football\debug_runs --overwrite
```

## 5. 可视化内容

```text
绿色框：球检测框
绿色点：球心
蓝色点：脚/脚尖关键点
橙色点：手腕关键点
红框：最终判定踢球帧
红点：kick_point
```

普通运行时关闭 debug：

```powershell
$DEBUG_DETECTIONS = "0"
$DEBUG_SAVE_VIDEO = "0"
```
