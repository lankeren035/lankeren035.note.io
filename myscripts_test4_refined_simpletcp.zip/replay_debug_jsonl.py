#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Replay detector debug jsonl without rerunning YOLO.

用途：
  python replay_debug_jsonl.py --jsonl debug_runs/4-xxx.jsonl
  python replay_debug_jsonl.py --dir debug_runs

它只读取已经写出的 frame 检测结果，重新跑 kick_offline.detect_events，
用于排查“为什么这个候选被接受/拒绝”。
"""
from __future__ import annotations

import argparse
import json
import sys
import types
from pathlib import Path
from types import SimpleNamespace

# 这个脚本只回放 jsonl，不需要真的调用 YOLO。没有 ultralytics 的机器也能分析。
try:
    import ultralytics  # noqa: F401
except Exception:
    m = types.ModuleType("ultralytics")
    m.YOLO = object
    sys.modules["ultralytics"] = m

from kick_common import BodyPoint, FrameObs
from kick_offline import detect_events


def _body_points(xs):
    return [BodyPoint(float(x["x"]), float(x["y"]), float(x.get("conf", 0.0)), str(x.get("label", ""))) for x in xs]


def load_jsonl(path: Path):
    obs = []
    fps = 30.0
    width = 0
    height = 0
    old_result = None
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        if not line.strip():
            continue
        o = json.loads(line)
        typ = o.get("type")
        if typ == "start":
            fps = float(o.get("fps") or fps)
        elif typ == "frame":
            b = o.get("ball") or {}
            if b.get("detected") and b.get("center") is not None:
                box = tuple(float(v) for v in b.get("bbox", [0, 0, 0, 0]))
                center = tuple(float(v) for v in b.get("center"))
                conf = float(b.get("conf") or 0.0)
                radius = float(b.get("radius") or 8.0)
                cls_name = str(b.get("class") or "")
                width = max(width, int(max(box[0], box[2], center[0])) + 1)
                height = max(height, int(max(box[1], box[3], center[1])) + 1)
            else:
                box = None
                center = None
                conf = 0.0
                radius = 8.0
                cls_name = ""
            obs.append(FrameObs(
                int(o.get("frame_idx", len(obs))),
                float(o.get("time_sec", len(obs) / max(fps, 1e-6))),
                box,
                center,
                conf,
                radius,
                cls_name,
                _body_points(o.get("feet", [])),
                _body_points(o.get("hands", [])),
            ))
        elif typ == "result":
            old_result = o.get("result") or {}
            v = old_result.get("video") or {}
            width = int(v.get("width") or width)
            height = int(v.get("height") or height)
    return obs, fps, width, height, old_result


def make_args(a):
    return SimpleNamespace(
        contact_percentile=a.contact_percentile,
        motion_percentile=a.motion_percentile,
        direction_cos_thresh=a.direction_cos_thresh,
        motion_window_sec=0.24,
        min_visible_steps=2,
        loss_reappear_sec=0.70,
        min_ball_move_px=a.min_ball_move_px,
        min_ball_move_ratio=a.min_ball_move_ratio,
        ball_move_lookahead_sec=0.20,
        ball_move_contact_gate=1.50,
        min_ball_speed_pxpf=0.0,
        foot_ball_same_dir_cos=a.foot_ball_same_dir_cos,
        min_foot_move_px=a.min_foot_move_px,
        strong_ball_move_mult=2.0,
        ball_speed_lookback=3,
        ball_speed_jump_ratio=a.ball_speed_jump_ratio,
        min_event_gap_sec=1.20,
        return_all_events=a.return_all_events,
        disable_blur_fallback=a.disable_blur_fallback,
        event_search_start_sec=a.event_search_start_sec,
        contact_support_dist_norm=a.contact_support_dist_norm,
        ball_gap_lookback=a.ball_gap_lookback,
        debug_decision=True,
        debug_candidate_limit=a.debug_candidate_limit,
    )


def replay_one(path: Path, args):
    obs, fps, w, h, old = load_jsonl(path)
    events, _, _, stats = detect_events(obs, fps, h, width=w, detail=False, args=make_args(args))
    old_kick = (old.get("kick") or {}) if old else {}
    print("=" * 80)
    print(f"file: {path}")
    print(f"frames={len(obs)} fps={fps} size={w}x{h}")
    if old_kick:
        print(f"old_result: frame_idx={old_kick.get('frame_idx')} frame_id={old_kick.get('frame_id')} kind={old_kick.get('kind')}")
    if events:
        e = events[0]
        print(f"new_result: frame_idx={e.frame_idx} frame_id={e.frame_id} kind={e.kind}")
        print(f"evidence: {e.evidence}")
    else:
        print("new_result: no_event")
    print("candidate_debug_top:")
    for c in stats.get("candidate_debug_top", []):
        print(json.dumps(c, ensure_ascii=False))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--jsonl", default=None)
    p.add_argument("--dir", default=None)
    p.add_argument("--event-search-start-sec", type=float, default=0.80)
    p.add_argument("--contact-support-dist-norm", type=float, default=2.25)
    p.add_argument("--ball-gap-lookback", type=int, default=3)
    p.add_argument("--min-ball-move-px", type=float, default=35.0)
    p.add_argument("--min-ball-move-ratio", type=float, default=0.03)
    p.add_argument("--foot-ball-same-dir-cos", type=float, default=0.35)
    p.add_argument("--min-foot-move-px", type=float, default=15.0)
    p.add_argument("--ball-speed-jump-ratio", type=float, default=1.6)
    p.add_argument("--contact-percentile", type=float, default=35.0)
    p.add_argument("--motion-percentile", type=float, default=85.0)
    p.add_argument("--direction-cos-thresh", type=float, default=0.15)
    p.add_argument("--debug-candidate-limit", type=int, default=20)
    p.add_argument("--return-all-events", action="store_true")
    p.add_argument("--disable-blur-fallback", action="store_true")
    args = p.parse_args()

    paths = []
    if args.jsonl:
        paths.append(Path(args.jsonl))
    if args.dir:
        paths.extend(sorted(Path(args.dir).glob("*.jsonl")))
    if not paths:
        raise SystemExit("provide --jsonl or --dir")
    for x in paths:
        replay_one(x, args)


if __name__ == "__main__":
    main()
