#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Camera sender for TCP kick detector.

Protocol: every client->server packet is one frame packet containing JSON header + JPEG image.
After a result is received, streaming pauses; press Enter/Space to continue camera streaming.
"""
from __future__ import annotations

import argparse
import json
import socket
import time
from pathlib import Path
from typing import Dict, Optional
from uuid import uuid4

import cv2

from tcp_packet import NonBlockingJsonReader, make_frame_packet, recv_json, send_packet


def open_camera(args) -> cv2.VideoCapture:
    if args.backend == "dshow":
        cap = cv2.VideoCapture(int(args.camera_index), cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap.release()
            cap = cv2.VideoCapture(int(args.camera_index))
    else:
        cap = cv2.VideoCapture(int(args.camera_index))

    if not cap.isOpened():
        raise RuntimeError(f"cannot open camera index: {args.camera_index}")
    if args.width > 0:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(args.width))
    if args.height > 0:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(args.height))
    if args.fps > 0:
        cap.set(cv2.CAP_PROP_FPS, float(args.fps))
    return cap


def encode_and_send_frame(sock: socket.socket, frame, meta: Dict, jpeg_quality: int) -> None:
    ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
    if not ok:
        raise RuntimeError("JPEG encode failed")
    send_packet(sock, make_frame_packet(meta, enc.tobytes()))


def send_camera_session(args, sock: socket.socket, cap: cv2.VideoCapture) -> Dict:
    fps = float(args.fps or cap.get(cv2.CAP_PROP_FPS) or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = 25.0

    session_id = uuid4().hex[:12]
    source = f"camera_{args.camera_index}"
    reader = NonBlockingJsonReader()
    t0 = time.time()
    frame_idx = 0
    sent_frames = 0
    got_result = None

    debug_writer = None
    debug_video_path = None
    debug_meta_path = None
    if args.debug_save_video:
        debug_dir = Path(args.debug_save_dir)
        debug_dir.mkdir(parents=True, exist_ok=True)
        debug_video_path = debug_dir / f"send_{session_id}.mp4"
        debug_meta_path = debug_dir / f"send_{session_id}.json"
        print(f"[CAMERA][DEBUG] save video: {debug_video_path}", flush=True)

    print(f"[CAMERA] start session={session_id}, source={source}, fps={fps:.3f}", flush=True)

    while True:
        result = reader.try_recv(sock)
        if result is not None:
            got_result = result
            print(f"[CAMERA] result before next frame, sent_frames={sent_frames}", flush=True)
            break

        ok, frame = cap.read()
        if not ok or frame is None:
            print("[CAMERA][WARN] read camera frame failed", flush=True)
            time.sleep(0.01)
            continue

        if args.max_frames > 0 and frame_idx >= args.max_frames:
            break
        if args.max_seconds > 0 and (time.time() - t0) >= args.max_seconds:
            break

        if args.debug_save_video:
            if debug_writer is None:
                vh, vw = frame.shape[:2]
                fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                debug_writer = cv2.VideoWriter(str(debug_video_path), fourcc, float(fps), (int(vw), int(vh)))
                if not debug_writer.isOpened():
                    raise RuntimeError(f"cannot open debug video writer: {debug_video_path}")
            debug_writer.write(frame)

        is_last = bool(
            (args.max_frames > 0 and frame_idx + 1 >= args.max_frames) or
            (args.max_seconds > 0 and (time.time() - t0) >= args.max_seconds)
        )
        meta = {
            "session_id": session_id,
            "source": source,
            "fps": fps,
            "frame_idx": frame_idx,
            "is_last": is_last,
            "params": {},
        }
        encode_and_send_frame(sock, frame, meta, args.jpeg_quality)
        sent_frames += 1
        frame_idx += 1

        if sent_frames % int(args.print_every) == 0:
            print(f"[CAMERA] sent frame={sent_frames}", flush=True)

        result = reader.try_recv(sock)
        if result is not None:
            got_result = result
            print(f"[CAMERA] result at sent_frame={sent_frames}", flush=True)
            break

        if args.show:
            cv2.imshow("camera sender", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                print("[CAMERA] manual stop current session", flush=True)
                break
        if is_last:
            break

    if got_result is None:
        print(f"[CAMERA] segment ended, sent_frames={sent_frames}, wait result...", flush=True)
        got_result = recv_json(sock)

    if debug_writer is not None:
        debug_writer.release()

    got_result.setdefault("sender", {})
    got_result["sender"].update({"sent_frames": sent_frames, "send_time_sec": time.time() - t0, "source": source})

    if args.debug_save_video and debug_meta_path is not None:
        meta = {"session_id": session_id, "source": source, "fps": fps, "video": str(debug_video_path), "sent_frames": sent_frames, "result_status": got_result.get("status"), "result": got_result}
        debug_meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[CAMERA][DEBUG] save meta: {debug_meta_path}", flush=True)
    return got_result


def build_argparser():
    p = argparse.ArgumentParser("Camera TCP frame sender")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=19090)
    p.add_argument("--camera-index", type=int, default=0)
    p.add_argument("--backend", choices=["default", "dshow"], default="dshow")
    p.add_argument("--width", type=int, default=1280)
    p.add_argument("--height", type=int, default=720)
    p.add_argument("--fps", type=float, default=30.0)
    p.add_argument("--jpeg-quality", type=int, default=85)
    p.add_argument("--max-seconds", type=float, default=0.0, help="0 means no time limit")
    p.add_argument("--max-frames", type=int, default=0, help="0 means no frame limit")
    p.add_argument("--connect-timeout", type=float, default=10.0)
    p.add_argument("--show", action="store_true", help="show camera preview; press q/ESC to stop current session")
    p.add_argument("--print-every", type=int, default=10)
    p.add_argument("--debug-save-video", action="store_true")
    p.add_argument("--debug-save-dir", default="debug_runs")
    p.add_argument("--once", action="store_true")
    return p


def main():
    args = build_argparser().parse_args()
    args.print_every = max(1, int(args.print_every))

    cap = open_camera(args)
    actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    actual_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    print(f"[CAMERA] opened camera={args.camera_index}, size={actual_w}x{actual_h}, cap_fps={actual_fps:.3f}")

    print(f"[CAMERA] connect {args.host}:{args.port}")
    try:
        with socket.create_connection((args.host, int(args.port)), timeout=float(args.connect_timeout)) as sock:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            print("[CAMERA] connected")
            while True:
                if not args.once:
                    cmd = input("\nEnter/Space=continue camera detection, q=quit: ")
                    if cmd.strip().lower() in {"q", "quit", "exit"}:
                        break
                try:
                    result = send_camera_session(args, sock, cap)
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                except Exception as exc:
                    print(f"[CAMERA][ERROR] {exc}", flush=True)
                    break
                if args.once:
                    break
    finally:
        cap.release()
        if args.show:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
