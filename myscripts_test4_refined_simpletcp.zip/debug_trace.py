#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import numpy as np


def _safe(x: Any) -> Any:
    if x is None or isinstance(x, (str, bool, int)):
        return x
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, np.ndarray):
        return _safe(x.tolist())
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        v = float(x)
        return v if math.isfinite(v) else None
    if isinstance(x, dict):
        return {str(k): _safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_safe(v) for v in x]
    if isinstance(x, Path):
        return str(x)
    return str(x)


def point_to_dict(p) -> Dict[str, Any]:
    return {
        "x": round(float(p.x), 3),
        "y": round(float(p.y), 3),
        "conf": round(float(p.conf), 4),
        "label": str(p.label),
    }


def obs_to_debug_row(obs) -> Dict[str, Any]:
    if obs.ball_center_raw is None:
        ball = {"detected": False}
    else:
        ball = {
            "detected": True,
            "center": [round(float(obs.ball_center_raw[0]), 3), round(float(obs.ball_center_raw[1]), 3)],
            "bbox": [round(float(v), 3) for v in obs.ball_box] if obs.ball_box is not None else None,
            "conf": round(float(obs.ball_conf), 4),
            "class": str(obs.ball_class or ""),
            "radius": round(float(obs.ball_radius), 3),
        }
    return {
        "type": "frame",
        "frame_idx": int(obs.frame_idx),
        "time_sec": round(float(obs.time_sec), 6),
        "ball": ball,
        "feet": [point_to_dict(p) for p in obs.foot_points],
        "hands": [point_to_dict(p) for p in obs.hand_points],
    }


class DebugJsonlWriter:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.f = self.path.open("w", encoding="utf-8")

    def write(self, obj: Dict[str, Any]) -> None:
        self.f.write(json.dumps(_safe(obj), ensure_ascii=False, separators=(",", ":")) + "\n")
        self.f.flush()

    def close(self) -> None:
        try:
            self.f.close()
        except Exception:
            pass
