# 静止球误报过滤与逐帧球检测 Debug

本版本基于 `myscripts_test2`，不改变 TCP 传输协议和服务架构，只强化踢球事件判定：

- 踢球事件必须由**球心真实位移**触发；
- 脚靠近球只作为接触候选，不再单独构成事件；
- 通过可调参数过滤静止球检测框抖动、短暂漏检、鞋子误检造成的误报；
- 增加逐帧球检测 debug 输出，便于查看每帧球的位置。

## 1. 新增核心参数

在 `service_kick_detector_tcp_win.ps1` 中可调：

```powershell
$MIN_BALL_MOVE_PX = Use-Env "MIN_BALL_MOVE_PX" "35"
$MIN_BALL_MOVE_RATIO = Use-Env "MIN_BALL_MOVE_RATIO" "0.03"
$DEBUG_DETECTIONS = Use-Env "DEBUG_DETECTIONS" "0"
```

事件必须满足：

```text
球心累计位移 >= max(MIN_BALL_MOVE_PX, MIN_BALL_MOVE_RATIO * 图像宽度)
```

例如 1280 宽的视频，默认门槛为：

```text
max(35px, 0.03 * 1280 = 38.4px) = 38.4px
```

所以静止球几像素的检测抖动不会触发 `kick_detected`。

## 2. 参数怎么调

### 静止球仍然误报

调大：

```powershell
$MIN_BALL_MOVE_PX = "50"
$MIN_BALL_MOVE_RATIO = "0.04"
```

### 真踢球漏检

调小：

```powershell
$MIN_BALL_MOVE_PX = "25"
$MIN_BALL_MOVE_RATIO = "0.02"
```

### 只想用像素阈值，不想用比例阈值

```powershell
$MIN_BALL_MOVE_PX = "40"
$MIN_BALL_MOVE_RATIO = "0"
```

### 只想用图像宽度百分比

```powershell
$MIN_BALL_MOVE_PX = "0"
$MIN_BALL_MOVE_RATIO = "0.03"
```

## 3. Debug 输出

开启：

```powershell
$DEBUG_DETECTIONS = "1"
```

检测端会输出每一帧选中的球检测结果：

```text
[DEBUG_BALL] frame=12 valid=1 center=(620.4,351.8) bbox=(600.1,330.2,641.0,372.6) conf=0.742 cls=sports ball candidates=1
[DEBUG_BALL] frame=13 valid=0 candidates=0
```

字段含义：

- `frame`: 0-based 帧号；
- `valid=1`: 当前帧选中了可靠球框；
- `center`: 球心像素坐标；
- `bbox`: 球框 `x1,y1,x2,y2`；
- `conf`: 球检测置信度；
- `candidates`: 当前帧通过类别/置信度/面积过滤后的球候选数量。

如果静止球误报，先打开 debug，看误报前后球心是否真的跳动。如果球心突然跳到鞋子或别的目标，说明是球检测模型误检；如果只是小幅抖动，继续调大 `MIN_BALL_MOVE_PX / MIN_BALL_MOVE_RATIO`。

## 4. 代码逻辑变化

### 原逻辑

主要依赖：

```text
脚球接近 + 球运动百分位阈值 + blur_loss fallback
```

静止视频中，运动阈值可能被检测框抖动压得很低，导致误报。

### 新逻辑

在原逻辑基础上增加硬门槛：

```text
脚球接近 + 原有运动方向/速度判断 + 球心累计位移硬阈值
```

`direct_motion` 和 `blur_loss` 都必须通过球心累计位移门槛。

## 5. 启动

检测端：

```bat
service_kick_detector_tcp_win.bat
```

摄像头发送端：

```bat
mock_camera_sender_tcp_win.bat
```
