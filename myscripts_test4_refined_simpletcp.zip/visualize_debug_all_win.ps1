$ErrorActionPreference = "Stop"

$SCRIPT_DIR = $PSScriptRoot
$PROJECT_ROOT = Split-Path -Parent $SCRIPT_DIR
$PYTHON = "D:\anaconda3\envs\football\python.exe"

$DEBUG_DIR = "$PROJECT_ROOT\debug_runs"
$OUT_DIR = "$DEBUG_DIR"
$OVERWRITE = "0"

Write-Host "[VIS] DEBUG_DIR=$DEBUG_DIR"
Write-Host "[VIS] OUT_DIR=$OUT_DIR"

$ArgsList = @(
  "$SCRIPT_DIR\visualize_debug_session.py",
  "--debug-dir", "$DEBUG_DIR",
  "--out-dir", "$OUT_DIR"
)

if ($OVERWRITE -eq "1") {
  $ArgsList += "--overwrite"
}

& "$PYTHON" @ArgsList
