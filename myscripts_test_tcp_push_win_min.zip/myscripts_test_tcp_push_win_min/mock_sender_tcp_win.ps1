$ErrorActionPreference = "Stop"

function Use-Env($Name, $Default) {
  $v = [Environment]::GetEnvironmentVariable($Name)
  if ($null -ne $v -and $v -ne "") { return $v }
  return $Default
}

$SCRIPT_DIR   = $PSScriptRoot
$PROJECT_ROOT = Use-Env "PROJECT_ROOT" (Split-Path -Parent $SCRIPT_DIR)
$PYTHON       = Use-Env "PYTHON" "D:\anaconda3\envs\football\python.exe"

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

# 模拟发送端：按回车后读取本地视频，主动推 JPEG 帧到检测端 TCP 端口。
# 不需要 ffmpeg，不需要 RTSP server。
$DETECTOR_HOST = Use-Env "DETECTOR_HOST" "127.0.0.1"
$DETECTOR_PORT = Use-Env "DETECTOR_PORT" "19090"
$VIDEO_DIR     = Use-Env "VIDEO_DIR" "$PROJECT_ROOT\videos"
$VIDEO         = Use-Env "VIDEO" ""
$JPEG_QUALITY  = Use-Env "JPEG_QUALITY" "85"
$MAX_SECONDS   = Use-Env "MAX_SECONDS" "20"
$MAX_FRAMES    = Use-Env "MAX_FRAMES" "0"
$REALTIME      = Use-Env "REALTIME" "0"
$ONCE          = Use-Env "ONCE" "0"

$Extra = @()
if ($REALTIME -eq "1") { $Extra += "--realtime" }
if ($ONCE -eq "1") { $Extra += "--once" }
if ($VIDEO -ne "") { $Extra += @("--video", $VIDEO) }

& $PYTHON "$SCRIPT_DIR\mock_sender_tcp.py" `
  --host $DETECTOR_HOST `
  --port $DETECTOR_PORT `
  --video-dir $VIDEO_DIR `
  --jpeg-quality $JPEG_QUALITY `
  --max-seconds $MAX_SECONDS `
  --max-frames $MAX_FRAMES `
  @Extra
