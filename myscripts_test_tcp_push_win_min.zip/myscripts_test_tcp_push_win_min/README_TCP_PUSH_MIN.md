# Windows TCP 主动推帧最小版

只保留当前 demo 必要文件：

- `service_kick_detector_tcp_win.bat`：启动检测端常驻服务。
- `service_kick_detector_tcp_win.ps1`：检测端参数配置。
- `service_kick_detector_tcp.py`：检测端 TCP 服务，模型只加载一次。
- `mock_sender_tcp_win.bat`：启动模拟发送端。
- `mock_sender_tcp_win.ps1`：发送端参数配置。
- `mock_sender_tcp.py`：读取本地视频并逐帧推给检测端。
- `kick_common.py`、`kick_offline.py`：原始可跑通检测逻辑依赖。

不包含 RTSP、MediaMTX、ffmpeg、HTTP callback、旧 mock_start、旧 mock_push。

## 启动顺序

1. 双击 `service_kick_detector_tcp_win.bat`
2. 双击 `mock_sender_tcp_win.bat`
3. 在发送端窗口按 Enter，发送一个视频；收到检测结果后自动停止发送并等待下一次 Enter。

## 主要配置

检测端模型路径在 `service_kick_detector_tcp_win.ps1` 顶部改：

```powershell
$PYTHON     = Use-Env "PYTHON" "D:\anaconda3\envs\football\python.exe"
$BALL_MODEL = Use-Env "BALL_MODEL" "$PROJECT_ROOT\my_models\yolo11s.engine"
$POSE_MODEL = Use-Env "POSE_MODEL" "$PROJECT_ROOT\my_models\yolo11m-pose.engine"
```

发送端视频目录在 `mock_sender_tcp_win.ps1` 顶部改：

```powershell
$VIDEO_DIR = Use-Env "VIDEO_DIR" "$PROJECT_ROOT\videos"
```
