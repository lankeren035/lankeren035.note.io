$ErrorActionPreference = "Stop"

function Use-Env($Name, $Default) {
  $v = [Environment]::GetEnvironmentVariable($Name)
  if ($null -ne $v -and $v -ne "") { return $v }
  return $Default
}

$SCRIPT_DIR   = $PSScriptRoot
$PROJECT_ROOT = Use-Env "PROJECT_ROOT" (Split-Path -Parent $SCRIPT_DIR)
$PYTHON       = Use-Env "PYTHON" "D:\anaconda3\envs\football\python.exe"

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

# TCP 推帧检测服务：发送端主动连接这个端口并逐帧发送 JPEG 帧。
# 不使用 RTSP，不需要 MediaMTX，不需要 ffmpeg。
$BIND_HOST = Use-Env "TCP_HOST" "0.0.0.0"
$TCP_PORT  = Use-Env "TCP_PORT" "19090"
$DEFAULT_MAX_SECONDS = Use-Env "DEFAULT_MAX_SECONDS" "20"
$SOCKET_TIMEOUT = Use-Env "SOCKET_TIMEOUT" "60"

$BALL_MODEL = Use-Env "BALL_MODEL" "$PROJECT_ROOT\my_models\yolo11s.engine"
$POSE_MODEL = Use-Env "POSE_MODEL" "$PROJECT_ROOT\my_models\yolo11m-pose.engine"
if (!(Test-Path $BALL_MODEL)) { $BALL_MODEL = "$PROJECT_ROOT\yolo11s.engine" }
if (!(Test-Path $POSE_MODEL)) { $POSE_MODEL = "$PROJECT_ROOT\yolo11m-pose.engine" }
if (!(Test-Path $BALL_MODEL)) { $BALL_MODEL = "$PROJECT_ROOT\yolo11s.pt" }
if (!(Test-Path $POSE_MODEL)) { $POSE_MODEL = "$PROJECT_ROOT\yolo11m-pose.pt" }

$DEVICE = Use-Env "DEVICE" "0"
$HALF   = Use-Env "HALF" "1"
$BATCH  = Use-Env "BATCH" "4"
$CHUNK  = Use-Env "CHUNK" "16"

$BALL_IMGSZ  = Use-Env "BALL_IMGSZ" "640"
$POSE_IMGSZ  = Use-Env "POSE_IMGSZ" "640"
$BALL_CONF   = Use-Env "BALL_CONF" "0.16"
$PERSON_CONF = Use-Env "PERSON_CONF" "0.20"
$POSE_CONF   = Use-Env "POSE_CONF" "0.18"

$YOLO_IOU = Use-Env "YOLO_IOU" "0.50"
$BALL_CLASS_NAMES = Use-Env "BALL_CLASS_NAMES" "sports ball,ball,football,soccer ball,volleyball"
$MAX_BALL_CANDIDATES = Use-Env "MAX_BALL_CANDIDATES" "8"
$HAND_CONF = Use-Env "HAND_CONF" "0.20"
$CONTACT_PERCENTILE = Use-Env "CONTACT_PERCENTILE" "35"
$MOTION_PERCENTILE = Use-Env "MOTION_PERCENTILE" "85"
$DIRECTION_COS_THRESH = Use-Env "DIRECTION_COS_THRESH" "0.15"
$MOTION_WINDOW_SEC = Use-Env "MOTION_WINDOW_SEC" "0.24"
$MIN_VISIBLE_STEPS = Use-Env "MIN_VISIBLE_STEPS" "2"
$LOSS_REAPPEAR_SEC = Use-Env "LOSS_REAPPEAR_SEC" "0.70"
$ONLINE_WARMUP_SEC = Use-Env "ONLINE_WARMUP_SEC" "0.80"
$ONLINE_WAIT_SEC = Use-Env "ONLINE_WAIT_SEC" "0.55"
$STABLE_CHUNKS = Use-Env "STABLE_CHUNKS" "2"

$HalfArgs = @()
if ($HALF -eq "1" -and $DEVICE -ne "cpu") { $HalfArgs += "--half" }

& $PYTHON "$SCRIPT_DIR\service_kick_detector_tcp.py" `
  --tcp-host $BIND_HOST `
  --tcp-port $TCP_PORT `
  --default-max-seconds $DEFAULT_MAX_SECONDS `
  --socket-timeout $SOCKET_TIMEOUT `
  --ball-model $BALL_MODEL `
  --pose-model $POSE_MODEL `
  --device $DEVICE `
  @HalfArgs `
  --batch $BATCH `
  --online-chunk $CHUNK `
  --pad-last-batch `
  --ball-imgsz $BALL_IMGSZ `
  --pose-imgsz $POSE_IMGSZ `
  --ball-conf $BALL_CONF `
  --person-conf $PERSON_CONF `
  --pose-conf $POSE_CONF `
  --yolo-iou $YOLO_IOU `
  --ball-class-names $BALL_CLASS_NAMES `
  --max-ball-candidates $MAX_BALL_CANDIDATES `
  --hand-conf $HAND_CONF `
  --contact-percentile $CONTACT_PERCENTILE `
  --motion-percentile $MOTION_PERCENTILE `
  --direction-cos-thresh $DIRECTION_COS_THRESH `
  --motion-window-sec $MOTION_WINDOW_SEC `
  --min-visible-steps $MIN_VISIBLE_STEPS `
  --loss-reappear-sec $LOSS_REAPPEAR_SEC `
  --online-warmup-sec $ONLINE_WARMUP_SEC `
  --online-wait-sec $ONLINE_WAIT_SEC `
  --stable-chunks $STABLE_CHUNKS
