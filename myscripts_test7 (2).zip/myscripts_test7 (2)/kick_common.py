#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

# =============================================================================
# 这个文件只放“公共基础能力”，不直接决定踢球帧：
#   1. 收集视频路径；
#   2. 调用 YOLO 球检测模型和 YOLO pose 模型；
#   3. 从模型输出中解析球框、球心、半径、脚点、手点；
#   4. 将每一帧整理成 FrameObs；
#   5. 构造 offline/online 共用的 numpy 数组特征。
#
# 重要原则：
#   - 这里不要写“事件判断策略”。事件判断放在 kick_offline.py / kick_online.py。
#   - 普通推理和 detail 推理都共用这里，避免两套解析逻辑不一致。
#   - 尽量只计算两种模式都需要的基础量；CSV/标注视频专用字段放在 detail 分支里。
# =============================================================================
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from ultralytics import YOLO

# 支持递归处理这些视频格式。
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v"}

# 默认球类别名。实际运行时可通过 --ball-class-names / BALL_CLASS_NAMES 覆盖。
# 如果模型只有一个类别，则 _ball_candidates() 会自动 accept_all，不强依赖类别名。
DEFAULT_BALL_CLASS_NAMES = "sports ball,ball,football,soccer ball,volleyball"

# COCO pose 关键点编号：手腕、膝盖、脚踝。
# 这是模型格式约定，不属于可调检测参数。
LEFT_WRIST, RIGHT_WRIST, LEFT_KNEE, RIGHT_KNEE, LEFT_ANKLE, RIGHT_ANKLE = 9, 10, 13, 14, 15, 16

# 下面保留在 Python 文件头部的是“小影响/模型几何/工程保护”常量。
# 真正影响鲁棒性的阈值已经放到 argparse 和 .sh 中。
DEFAULT_YOLO_IOU = 0.50              # YOLO NMS IoU，bash 可覆盖
DEFAULT_MAX_BALL_CANDIDATES = 8      # 每帧最多球候选数，bash 可覆盖
DEFAULT_HAND_CONF = 0.20             # 手腕关键点最低置信度，bash 可覆盖
TOE_EXTEND_RATIO = 0.35              # 脚尖外推比例，模型几何常量，通常不改
MAX_BALL_AREA_RATIO = 0.25           # 球框最大占画面比例，极近景才可能需要改
MAD_SCALE = 1.4826                   # MAD 转近似标准差的鲁棒统计系数


# 单个身体关键点。这里只保留坐标、置信度和可读标签。
@dataclass
class BodyPoint:
    x: float; y: float; conf: float; label: str


# 一帧的观测结果。
# 注意：FrameObs 只表示“检测结果”，不表示事件判断。
# ball_center_raw 为 None 表示该帧没有可靠球框。后续 build_arrays() 会插值出 centers。
@dataclass
class FrameObs:
    frame_idx: int; time_sec: float
    ball_box: Optional[Tuple[float, float, float, float]]
    ball_center_raw: Optional[Tuple[float, float]]
    ball_conf: float; ball_radius: float; ball_class: str
    foot_points: List[BodyPoint]; hand_points: List[BodyPoint]


# 最终事件结果。frame_idx 是 0-based，frame_id 是用户更常用的 1-based。
# evidence 字段专门用于 detail 模式排查：说明为什么选中这一帧。
@dataclass
class Event:
    event_id: int; frame_idx: int; frame_id: int; time_sec: float
    kind: str; confidence: float; dist_norm: float; min_foot_dist: float
    motion_hps: float; motion_gate: float; progress_px: float
    nearest_foot_label: str; evidence: str


# 单个视频的完整处理结果。
# observations/arrays/detail_rows 方便 detail 脚本输出 CSV/标注视频；
# 普通脚本只用 events 和 timings。
@dataclass
class VideoResult:
    video: Path; fps: float; width: int; height: int; frame_count: int
    processed_frames: int; mode: str; early_stopped: bool
    events: List[Event]; observations: List[FrameObs]
    arrays: Dict[str, np.ndarray]; detail_rows: List[Dict]
    stats: Dict[str, float]; timings: Dict[str, float]


# 每帧可能有多个球框，先保存成候选，再结合上一帧轨迹选最合理的一个。
@dataclass
class BallCandidate:
    xyxy: Tuple[float, float, float, float]
    center: np.ndarray; radius: float; conf: float; cls_name: str


# 收集输入视频。支持传单个视频，也支持传文件夹递归处理。
def collect_videos(input_path: Path) -> List[Path]:
    p = input_path.resolve()
    if p.is_file():
        if p.suffix.lower() not in VIDEO_EXTS:
            raise ValueError(f"unsupported video file: {p}")
        return [p]
    if not p.is_dir():
        raise FileNotFoundError(p)
    out = sorted(x for x in p.rglob("*") if x.is_file() and x.suffix.lower() in VIDEO_EXTS)
    if not out:
        raise RuntimeError(f"no videos found under: {p}")
    return out


# 输出 detail 文件时保持相对目录结构：
#   input/a/b.mp4 -> out/frame_scores/a/b.csv
def safe_rel_path(video_path: Path, input_root: Path) -> Path:
    v, r = video_path.resolve(), input_root.resolve()
    return Path(v.name) if r.is_file() else v.relative_to(r)


# 把“秒”转换成“帧数”。
# 这样 25fps/30fps/60fps 下窗口长度含义一致，不再写死固定帧数。
def frames(sec: float, fps: float, minimum: int = 1) -> int:
    return max(minimum, int(round(float(sec) * max(float(fps), 1.0))))


# dataclass 转 dict，主要用于 JSON 输出。
def event_to_dict(e: Event) -> Dict:
    return asdict(e)


# 当前策略每个视频只返回第一个物理成立的事件。
def best_event(result: VideoResult) -> Optional[Event]:
    return result.events[0] if result.events else None


# 判断是否 CPU。CPU 下不能强行 half，否则 ONNX/TensorRT/torch 后端容易报错。
def _is_cpu(device: str) -> bool:
    s = str(device).lower().strip()
    return s == "cpu" or s.startswith("cpu:")


def _cfg(args, name: str, default):
    """读取可配置参数；兼容旧 argparse 没有新增字段的情况。"""
    return getattr(args, name, default)


def _ball_name_set(args) -> set:
    """解析逗号分隔的球类别名，全部转小写。"""
    text = str(_cfg(args, "ball_class_names", DEFAULT_BALL_CLASS_NAMES))
    return {x.strip().lower() for x in text.split(",") if x.strip()}


# 把点限制在图像范围内，避免关键点/框略微越界影响后续距离计算。
def _clamp(x: float, y: float, w: int, h: int) -> Tuple[float, float]:
    return float(np.clip(x, 0, max(w - 1, 0))), float(np.clip(y, 0, max(h - 1, 0)))


# BodyPoint 转 numpy 向量，方便做距离/方向计算。
def point_np(p: BodyPoint) -> np.ndarray:
    return np.asarray([p.x, p.y], dtype=float)


# 找离球心最近的脚点。
# offline/online 只关心最近脚，因为“触球”首先表现为某只脚接近球。
def nearest_foot(points: List[BodyPoint], center: np.ndarray) -> Tuple[Optional[BodyPoint], float]:
    if not points:
        return None, float("inf")
    q = min(points, key=lambda p: float(np.linalg.norm(center - point_np(p))))
    return q, float(np.linalg.norm(center - point_np(q)))


# 批量推理。
# pad_last_batch=True 时，把最后不足 batch 的帧补齐到 batch 大小。
# 这样 TensorRT engine 如果是固定 batch，也能稳定运行；返回时只取真实帧数量。
def predict_batch(model: YOLO, frames_bgr: List[np.ndarray], *, imgsz: int, conf: float, args) -> List:
    if not frames_bgr:
        return []
    batch, out = max(1, int(args.batch)), []
    half = bool(args.half) and not _is_cpu(args.device)
    for s in range(0, len(frames_bgr), batch):
        sub = frames_bgr[s:s + batch]
        real_n = len(sub)
        src = sub + [sub[-1]] * (batch - real_n) if bool(args.pad_last_batch) and batch > 1 and real_n < batch else sub
        res = model.predict(source=src, imgsz=int(imgsz), conf=float(conf),
                            iou=float(_cfg(args, "yolo_iou", DEFAULT_YOLO_IOU)),
                            device=args.device, half=half, batch=batch, stream=False, verbose=False)
        out.extend(list(res)[:real_n]) #只取真实帧数量的结果，丢弃补齐帧的结果,extend 是把列表元素逐个添加到 out 中，而不是把整个列表作为一个元素添加到 out 中
    return out


# 从 YOLO detect 输出中解析球候选。
# 这里做三类过滤：置信度、类别名、面积比例。
# 面积比例过滤主要防止把很大的背景/人体误检当成球。
def _ball_candidates(result, model_names, args, w: int, h: int) -> List[BallCandidate]:
    if result.boxes is None:
        return []
    names = model_names if isinstance(model_names, dict) else dict(enumerate(model_names))
    accept_all, area = len(names) == 1, max(float(w * h), 1.0) # 只有一个类别
    ball_names = _ball_name_set(args)
    cands: List[BallCandidate] = []
    for b in result.boxes:
        score = float(b.conf[0].item())
        if score < float(args.ball_conf): #过滤低置信度框
            continue
        cls_name = str(names.get(int(b.cls[0].item()), int(b.cls[0].item()))).lower()
        if not accept_all and cls_name not in ball_names: #过滤类别名不在 ball_names 里的框
            continue
        x1, y1, x2, y2 = b.xyxy[0].detach().cpu().numpy().astype(float).tolist()
        x1, y1 = _clamp(x1, y1, w, h); x2, y2 = _clamp(x2, y2, w, h)
        if x2 <= x1 or y2 <= y1 or ((x2 - x1) * (y2 - y1)) / area > MAX_BALL_AREA_RATIO: #无效框与过滤面积过大的框 
            continue
        center = np.asarray([(x1 + x2) * 0.5, (y1 + y2) * 0.5], dtype=float) #计算框中心坐标
        cands.append(BallCandidate((x1, y1, x2, y2), center, max(max(x2 - x1, y2 - y1) * 0.5, 1.0), score, cls_name))
    # 按置信度排序，最多保留固定个数
    return sorted(cands, key=lambda x: x.conf, reverse=True)[:max(1, int(_cfg(args, "max_ball_candidates", DEFAULT_MAX_BALL_CANDIDATES)))]


# 多个球候选时，优先选择“置信度高且离预测轨迹近”的框。
# 这一步只做弱跟踪，不做复杂卡尔曼滤波，目的是避免偶发误检导致球心跳变。
def _select_ball(cands: List[BallCandidate], track: Dict[str, object], w: int, h: int) -> Optional[BallCandidate]:
    if not cands:
        return None
    last = track.get("last_center")
    if last is None: #没有上一帧轨迹可参考，直接选置信度最高的那个
        return cands[0]
    pred = np.asarray(last, dtype=float).copy()
    if track.get("last_velocity") is not None: #有上一帧速度信息时，做简单线性预测，假设球以恒速运动，预测当前帧球心位置
        pred = pred + np.asarray(track["last_velocity"], dtype=float) * (int(track.get("miss", 0)) + 1)
    diag = max(math.hypot(w, h), 1.0)
    return max(cands, key=lambda c: c.conf * (1.0 - min(float(np.linalg.norm(c.center - pred)) / diag, 1.0))) # 选择置信度高且离预测轨迹近的框


# 从 YOLO pose 结果中解析脚点和手点。
# 脚点包括 ankle 和外推 toe；手点用于过滤“手比脚更近”的误触发。
def _pose_points(result, args, w: int, h: int) -> Tuple[List[BodyPoint], List[BodyPoint]]:
    feet: List[BodyPoint] = []; hands: List[BodyPoint] = []
    if result.keypoints is None or result.keypoints.xy is None:
        return feet, hands
    xy = result.keypoints.xy.detach().cpu().numpy() #读取所有人的关键点坐标和置信度
    cf = result.keypoints.conf
    conf = np.ones(xy.shape[:2], dtype=np.float32) if cf is None else cf.detach().cpu().numpy()
    pconf = float(args.pose_conf)
    for pi in range(xy.shape[0]): #遍历每个人，解析脚点和手点
        for side, ankle, knee in (("left", LEFT_ANKLE, LEFT_KNEE), ("right", RIGHT_ANKLE, RIGHT_KNEE)):
            ac = float(conf[pi, ankle])
            if ac < pconf: #过滤低置信度脚踝点
                continue
            ax, ay = _clamp(float(xy[pi, ankle, 0]), float(xy[pi, ankle, 1]), w, h)
            feet.append(BodyPoint(ax, ay, ac, f"p{pi}_{side}_ankle")) #把脚踝点加入脚点列表
            kc = float(conf[pi, knee])
            if kc >= pconf: #如果对应的膝盖点置信度足够，就做脚尖外推，增加一个脚尖点到脚点列表
                vx, vy = ax - float(xy[pi, knee, 0]), ay - float(xy[pi, knee, 1]) #计算从膝盖到脚踝的向量
                if math.hypot(vx, vy) > 1e-6: #如果向量长度足够，就按 TOE_EXTEND_RATIO 的比例外推出脚尖位置，并加入脚点列表
                    tx, ty = _clamp(ax + TOE_EXTEND_RATIO * vx, ay + TOE_EXTEND_RATIO * vy, w, h)
                    feet.append(BodyPoint(tx, ty, min(ac, kc), f"p{pi}_{side}_toe"))
        for side, wrist in (("left", LEFT_WRIST), ("right", RIGHT_WRIST)):
            wc = float(conf[pi, wrist]) #过滤低置信度手腕点，避免误触发
            if wc >= max(float(_cfg(args, "hand_conf", DEFAULT_HAND_CONF)), pconf):
                wx, wy = _clamp(float(xy[pi, wrist, 0]), float(xy[pi, wrist, 1]), w, h)
                hands.append(BodyPoint(wx, wy, wc, f"p{pi}_{side}_wrist"))
    return feet, hands


# 轻量球轨迹状态：上一帧球心、速度、连续丢失帧数。
def new_track() -> Dict[str, object]:
    return {"last_center": None, "prev_center": None, "last_velocity": None, "miss": 0}


# 将一个 batch 的模型输出追加到 observations。
# offline 一次处理完整视频；online 分 chunk 处理，但二者都会调用这个函数，因此基础观测完全一致。
def append_observations(obs: List[FrameObs], ball_results: List, pose_results: List,
                        ball_model: YOLO, fps: float, w: int, h: int, track: Dict[str, object], args) -> None:
    names = getattr(ball_model, "names", {})
    for br, pr in zip(ball_results, pose_results):
        idx = len(obs) #当前帧号，0-based
        cands = _ball_candidates(br, names, args, w, h) #从球检测结果中塞选出球候选
        sel = _select_ball(cands, track, w, h) #从球候选中选择一个最合理的作为当前帧的球检测结果
        box, center, score, radius, cls_name = None, None, 0.0, 8.0, ""
        if sel is None:
            track["miss"] = int(track.get("miss", 0)) + 1  # track 里 miss 的含义是“连续丢失帧数”，每帧没选中球就加一，选中球就重置为0
        else:
            box, center, score, radius, cls_name = sel.xyxy, (float(sel.center[0]), float(sel.center[1])), float(sel.conf), float(sel.radius), sel.cls_name
            if track.get("prev_center") is not None:
                track["last_velocity"] = sel.center - np.asarray(track["prev_center"], dtype=float) # 计算当前帧球心相对于上一帧球心的速度向量，单位是像素/帧
            track.update(prev_center=sel.center.copy(), last_center=sel.center.copy(), miss=0)
        if bool(_cfg(args, "debug_detections", False)):
            if sel is None:
                print(f"[DEBUG_BALL] frame={idx} valid=0 candidates={len(cands)}", flush=True)
            else:
                x1, y1, x2, y2 = box
                print(
                    f"[DEBUG_BALL] frame={idx} valid=1 "
                    f"center=({center[0]:.1f},{center[1]:.1f}) "
                    f"bbox=({x1:.1f},{y1:.1f},{x2:.1f},{y2:.1f}) "
                    f"conf={score:.3f} cls={cls_name} candidates={len(cands)}",
                    flush=True,
                )
        # 从姿态检测结果中解析脚点和手点
        feet, hands = _pose_points(pr, args, w, h)
        obs.append(FrameObs(idx, idx / max(float(fps), 1e-6), box, center, score, radius, cls_name, feet, hands))


# 对球心做线性插值。
# valid 表示该帧是否真实检测到球；centers 用于连续运动计算。
# 注意：事件判断仍会区分 valid/invalid，不会把插值点误当成真实检测。
def interpolate_centers(obs: List[FrameObs]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(obs)
    raw = np.full((n, 2), np.nan, dtype=float)
    radii = np.full(n, np.nan, dtype=float)
    for i, o in enumerate(obs):
        if o.ball_center_raw is not None:
            raw[i] = o.ball_center_raw
            radii[i] = max(float(o.ball_radius), 1.0)
    valid = np.isfinite(raw[:, 0]) & np.isfinite(raw[:, 1])
    centers = raw.copy()
    if valid.sum() == 0:
        centers[:] = 0.0
    elif valid.sum() == 1:
        centers[:] = raw[valid][0]
    else:
        xs = np.arange(n)
        centers[:, 0] = np.interp(xs, xs[valid], raw[valid, 0])
        centers[:, 1] = np.interp(xs, xs[valid], raw[valid, 1])
    ref = float(np.nanmedian(radii)) if np.isfinite(radii).any() else 8.0
    return centers, valid, np.where(np.isfinite(radii), radii, max(ref, 1.0))


# 把 FrameObs 列表转换成向量化数组。
# 关键量：
#   abs_step_hps: 球自身相邻帧位移，单位为 frame-height per second。
#   rel_step_hps: 球相对脚的相邻帧位移，同样按画面高度和 fps 归一化。
# 同时看 abs 和 rel，可以过滤单纯脚运动或相机整体运动造成的假速度。
def build_arrays(obs: List[FrameObs], fps: float, frame_h: int, frame_w: int = 0) -> Dict[str, np.ndarray]:
    n = len(obs)
    centers, valid, radii = interpolate_centers(obs) #对球心坐标进行插值，得到每帧的球心位置、有效性和半径,同时标记出哪些帧是真实检测到球的，哪些是插值点
    foot_xy = np.full((n, 2), np.nan, dtype=float)
    foot_dist = np.full(n, np.inf, dtype=float)
    foot_label = np.asarray([""] * n, dtype=object)
    hand_dist = np.full(n, np.inf, dtype=float)
    for i, o in enumerate(obs): #遍历每一帧的观测结果，计算球心到最近脚点的距离和标签，以及球心到手点的最小距离
        q, d = nearest_foot(o.foot_points, centers[i]) #找到离球心最近的脚点 q 和距离 d
        if q is not None:
            foot_xy[i], foot_dist[i], foot_label[i] = point_np(q), d, q.label #如果找到最近脚点，就记录该脚点的坐标、距离和标签
        if o.hand_points: #如果有手点，就计算球心到所有手点的距离，取最小值作为 hand_dist
            hand_dist[i] = min(float(np.linalg.norm(centers[i] - point_np(h))) for h in o.hand_points)
    foot_valid = np.isfinite(foot_xy[:, 0]) & np.isfinite(foot_xy[:, 1]) #判断哪些帧有有效的脚点信息
    rel = centers - foot_xy #计算球心相对于最近脚点的向量
    rel_vec = np.zeros((n, 2), dtype=float); rel_step = np.zeros(n, dtype=float); abs_step = np.zeros(n, dtype=float) #初始化球相对脚的运动向量、相对运动幅度和绝对运动幅度
    for i in range(1, n):
        if valid[i] and valid[i - 1]: #如果当前帧和上一帧都检测到球，就计算绝对运动幅度
            abs_step[i] = float(np.linalg.norm(centers[i] - centers[i - 1]))
        if valid[i] and valid[i - 1] and foot_valid[i] and foot_valid[i - 1]: #如果当前帧和上一帧都检测到球，并且都有有效的脚点信息，就计算相对运动向量和相对运动幅度
            rel_vec[i] = rel[i] - rel[i - 1]
            rel_step[i] = float(np.linalg.norm(rel_vec[i]))
    scale = float(fps) / max(float(frame_h), 1.0) #把像素/帧的运动幅度转换成 frame-height per second，减少分辨率和 fps 影响
    return dict(centers=centers, valid=valid, radii=radii, foot_xy=foot_xy, foot_valid=foot_valid,
                foot_dist=foot_dist, foot_label=foot_label, hand_dist=hand_dist,
                dist_norm=foot_dist / np.maximum(radii, 1.0), rel=rel, rel_vec=rel_vec,
                rel_step_hps=rel_step * scale, abs_step_hps=abs_step * scale,
                frame_w=float(frame_w or frame_h or 1), frame_h=float(frame_h or 1))


# 从当前视频自己的运动分布中估计“明显运动”的门槛。
# 使用 85 分位数和 median + MAD，避免被极端离群值完全带偏。
def robust_motion_gate(v: np.ndarray, percentile: float = 85.0) -> float:
    x = np.asarray(v, dtype=float)
    x = x[np.isfinite(x) & (x > 0)]
    if len(x) < 4:
        return float(np.max(x)) if len(x) else float("inf")
    med = float(np.median(x)); mad = float(np.median(np.abs(x - med))) * MAD_SCALE
    return max(float(np.percentile(x, float(percentile))), med + mad)


# 从当前视频里的脚球距离分布估计“接近”的门槛。
# dist_norm = 脚球距离 / 球半径，减少分辨率、远近景影响。
def contact_gate(dist_norm: np.ndarray, percentile: float = 35.0) -> float:
    x = np.asarray(dist_norm, dtype=float)
    x = x[np.isfinite(x)]
    return float("inf") if len(x) == 0 else float(np.percentile(x, float(percentile)) if len(x) >= 4 else np.min(x) + 1e-6)


# 判断球的运动方向是否大致符合“从脚指向球”的方向。
# rel0 是接触候选帧的 ball - foot 向量；move 是之后球的运动向量。
# 如果球被脚踢走，move 应该大体沿 rel0 方向，也就是球远离脚。
def direction_ok(rel0: np.ndarray, move: np.ndarray, min_cos: float = 0.15) -> Tuple[bool, float, float]:
    rn, mn = float(np.linalg.norm(rel0)), float(np.linalg.norm(move))
    if mn <= 1e-9:
        return False, 0.0, 0.0
    if rn <= 1e-9:
        return True, 1.0, mn
    cos = float(np.dot(rel0, move) / (rn * mn))
    progress = float(np.dot(move, rel0 / rn))
    return cos >= float(min_cos) and progress > 0.0, cos, progress


# 统一构造 VideoResult，补齐 processed_frames/detail_rows 等字段。
def make_result(**kw) -> VideoResult:
    kw["video"] = Path(kw["video"])
    kw["processed_frames"] = len(kw["observations"])
    kw["detail_rows"] = kw.get("detail_rows") or []
    return VideoResult(**kw)
