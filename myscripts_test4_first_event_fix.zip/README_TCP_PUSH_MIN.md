# TCP push-stream demo, persistent connection

Use two windows:

1. `service_kick_detector_tcp_win.bat`
2. `mock_sender_tcp_win.bat`

Protocol:

- The detector service loads ball/pose models once at startup.
- The sender creates one TCP connection and keeps it open.
- Every Enter sends one JSON `start` packet, then JPEG frame packets.
- Once the detector finds the kick frame, it sends a JSON result back but does not close the connection.
- The sender receives the result, sends an empty end packet for the current round, stops sending that video, then waits for the next Enter.
- The detector discards remaining packets from the current round until the end marker, then waits for the next `start` packet on the same connection.

No RTSP, MediaMTX, or ffmpeg is needed for this TCP push demo.
