$ErrorActionPreference = "Stop"

$SCRIPT_DIR = $PSScriptRoot
$PROJECT_ROOT = Split-Path -Parent $SCRIPT_DIR
$PYTHON = "D:\anaconda3\envs\football\python.exe"

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

# 本地摄像头实时推流发送端。检测端 service 不用改。
$HOST_IP = "127.0.0.1"
$PORT = "19090"
$CAMERA_INDEX = "0"
$WIDTH = "1280"
$HEIGHT = "720"
$FPS = "30"
$JPEG_QUALITY = "85"
$MAX_SECONDS = "0"
$MAX_FRAMES = "0"
$SHOW = "1"
$ONCE = "0"
$DEBUG_SAVE_VIDEO = "0"
$DEBUG_SAVE_DIR = "$PROJECT_ROOT\debug_runs"

Write-Host "[CAMERA PS1] PROJECT_ROOT=$PROJECT_ROOT"
Write-Host "[CAMERA PS1] DETECTOR=$HOST_IP`:$PORT"
Write-Host "[CAMERA PS1] CAMERA_INDEX=$CAMERA_INDEX SIZE=$WIDTH x $HEIGHT FPS=$FPS"

$ArgsList = @(
  "$SCRIPT_DIR\mock_camera_sender_tcp.py",
  "--host", "$HOST_IP",
  "--port", "$PORT",
  "--camera-index", "$CAMERA_INDEX",
  "--backend", "dshow",
  "--width", "$WIDTH",
  "--height", "$HEIGHT",
  "--fps", "$FPS",
  "--jpeg-quality", "$JPEG_QUALITY",
  "--max-seconds", "$MAX_SECONDS",
  "--max-frames", "$MAX_FRAMES"
)

if ($DEBUG_SAVE_VIDEO -eq "1") {
  $ArgsList += @("--debug-save-video", "--debug-save-dir", "$DEBUG_SAVE_DIR")
}


if ($SHOW -eq "1") { $ArgsList += "--show" }
if ($ONCE -eq "1") { $ArgsList += "--once" }

& "$PYTHON" @ArgsList
