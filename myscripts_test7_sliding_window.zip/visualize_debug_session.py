#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2


def load_jsonl(path: Path) -> List[Dict]:
    rows: List[Dict] = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def read_first_jsonl_row(path: Path) -> Optional[Dict]:
    try:
        with Path(path).open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    return json.loads(line)
    except Exception:
        return None
    return None


def find_pairs(debug_dir: Path, session_id: str = "", latest: bool = False) -> List[Tuple[str, Path, Path]]:
    """Return (session_id, send_video, det_log) pairs with basic consistency checks."""
    if session_id:
        det = debug_dir / f"det_{session_id}.jsonl"
        vid = debug_dir / f"send_{session_id}.mp4"
        if not det.is_file():
            raise FileNotFoundError(det)
        if not vid.is_file():
            raise FileNotFoundError(vid)
        return [(session_id, vid, det)]

    pairs: List[Tuple[str, Path, Path]] = []
    dets = sorted(debug_dir.glob("det_*.jsonl"), key=lambda p: p.stat().st_mtime)
    if latest and dets:
        dets = [dets[-1]]

    for det in dets:
        sid = det.stem[len("det_"):]
        vid = debug_dir / f"send_{sid}.mp4"
        meta_path = debug_dir / f"send_{sid}.json"
        if not vid.is_file():
            print(f"[SKIP] no matched video for {det.name}: expected {vid.name}")
            continue

        first = read_first_jsonl_row(det)
        if first and str(first.get("session_id", sid)) != sid:
            print(f"[WARN] det name/session mismatch: file={det.name}, json_session={first.get('session_id')}")

        if meta_path.is_file():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                if str(meta.get("session_id", sid)) != sid:
                    print(f"[WARN] send meta/session mismatch: file={meta_path.name}, json_session={meta.get('session_id')}")
            except Exception as exc:
                print(f"[WARN] cannot read sender meta {meta_path.name}: {exc}")
        else:
            print(f"[WARN] no sender meta for {sid}: expected {meta_path.name}")

        pairs.append((sid, vid, det))
    return pairs

def to_int_pt(p):
    return int(round(float(p[0]))), int(round(float(p[1])))


def draw_text(img, text, xy, scale=0.55, color=(255, 255, 255), bg=(0, 0, 0)):
    x, y = int(xy[0]), int(xy[1])
    h, w = img.shape[:2]
    x = max(0, min(w - 1, x))
    y = max(15, min(h - 1, y))
    (tw, th), base = cv2.getTextSize(str(text), cv2.FONT_HERSHEY_SIMPLEX, scale, 1)
    cv2.rectangle(img, (x, max(0, y - th - base - 3)), (min(w - 1, x + tw + 4), min(h - 1, y + 3)), bg, -1)
    cv2.putText(img, str(text), (x + 2, y - base), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


def draw_frame(img, row: Optional[Dict], result: Optional[Dict], frame_idx: int):
    if row is None:
        draw_text(img, f"frame={frame_idx} no detector row", (10, 25), color=(0, 255, 255))
        return img

    ball = row.get("ball") or {}
    if ball.get("detected"):
        bbox = ball.get("bbox")
        center = ball.get("center")
        conf = ball.get("conf")
        if bbox:
            x1, y1, x2, y2 = [int(round(float(v))) for v in bbox]
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"ball {float(conf):.3f}" if isinstance(conf, (int, float)) else "ball"
            draw_text(img, label, (x1, max(20, y1 - 5)), color=(0, 255, 0))
        if center:
            cv2.circle(img, to_int_pt(center), 5, (0, 255, 0), -1)
    else:
        draw_text(img, "ball: none", (10, 50), color=(0, 0, 255))

    for p in row.get("feet") or []:
        if "x" not in p or "y" not in p:
            continue
        xy = (int(round(float(p["x"]))), int(round(float(p["y"]))))
        cv2.circle(img, xy, 4, (255, 0, 0), -1)
        cv2.putText(img, p.get("label", "foot"), (xy[0] + 4, xy[1] - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 0, 0), 1)

    for p in row.get("hands") or []:
        if "x" not in p or "y" not in p:
            continue
        xy = (int(round(float(p["x"]))), int(round(float(p["y"]))))
        cv2.circle(img, xy, 4, (0, 165, 255), -1)

    kick = (result or {}).get("kick") if result else None
    if kick:
        kidx = int(kick.get("frame_idx", -1))
        if frame_idx == kidx:
            cv2.rectangle(img, (2, 2), (img.shape[1] - 3, img.shape[0] - 3), (0, 0, 255), 4)
            kp = ((kick.get("kick_point") or {}).get("px"))
            if kp:
                cv2.circle(img, to_int_pt(kp), 9, (0, 0, 255), -1)
            draw_text(img, f"KICK frame={kidx} conf={float(kick.get('confidence',0.0)):.3f} kind={kick.get('kind','')}", (10, 28), color=(0, 0, 255))
        else:
            draw_text(img, f"frame={frame_idx} kick={kidx}", (10, 28), color=(255, 255, 255))
    else:
        draw_text(img, f"frame={frame_idx} no kick", (10, 28), color=(255, 255, 255))
    return img


def render_one(session_id: str, video_path: Path, det_path: Path, out_video: Path, frames_dir: Path, overwrite: bool = False) -> bool:
    if out_video.exists() and not overwrite:
        print(f"[SKIP] {session_id}: result video exists: {out_video}")
        return False

    if overwrite and frames_dir.exists():
        shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True, exist_ok=True)
    out_video.parent.mkdir(parents=True, exist_ok=True)

    rows = load_jsonl(det_path)
    frame_rows = {int(r["frame_idx"]): r for r in rows if r.get("type") == "frame" and "frame_idx" in r}
    result = None
    for r in rows:
        if r.get("type") == "result":
            result = r.get("result")

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    if w <= 0 or h <= 0:
        raise RuntimeError(f"bad video size: {video_path}")

    writer = cv2.VideoWriter(str(out_video), cv2.VideoWriter_fourcc(*"mp4v"), float(fps), (w, h))
    if not writer.isOpened():
        raise RuntimeError(f"cannot open writer: {out_video}")

    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        vis = draw_frame(frame, frame_rows.get(idx), result, idx)
        writer.write(vis)
        cv2.imwrite(str(frames_dir / f"{idx:06d}.jpg"), vis)
        idx += 1

    cap.release()
    writer.release()
    print(f"[DONE] {session_id}: video={out_video}, frames={frames_dir}, frames_count={idx}")
    return True


def main():
    ap = argparse.ArgumentParser("Batch visualize detector debug jsonl on sender debug videos")
    ap.add_argument("--debug-dir", default="debug_runs", help="folder containing det_*.jsonl and send_*.mp4")
    ap.add_argument("--session-id", default="", help="optional single session id; default processes all matched sessions")
    ap.add_argument("--out-dir", default="", help="output folder; default is debug-dir")
    ap.add_argument("--overwrite", action="store_true", help="regenerate even if vis_<session>.mp4 exists")
    ap.add_argument("--latest", action="store_true", help="only visualize the newest det_*.jsonl pair")
    args = ap.parse_args()

    debug_dir = Path(args.debug_dir).resolve()
    if not debug_dir.is_dir():
        raise FileNotFoundError(debug_dir)
    out_dir = Path(args.out_dir).resolve() if args.out_dir else debug_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = find_pairs(debug_dir, args.session_id, latest=bool(args.latest))
    if not pairs:
        print(f"[WARN] no det_*.jsonl + send_*.mp4 pairs found in {debug_dir}")
        return

    made = 0
    skipped = 0
    for sid, video_path, det_path in pairs:
        print(f"[PAIR] session={sid} video={video_path.name} det={det_path.name}")
        out_video = out_dir / f"vis_{sid}.mp4"
        frames_dir = out_dir / f"vis_{sid}_frames"
        ok = render_one(sid, video_path, det_path, out_video, frames_dir, overwrite=args.overwrite)
        if ok:
            made += 1
        else:
            skipped += 1

    print(f"[SUMMARY] made={made}, skipped={skipped}, total={len(pairs)}")


if __name__ == "__main__":
    main()
