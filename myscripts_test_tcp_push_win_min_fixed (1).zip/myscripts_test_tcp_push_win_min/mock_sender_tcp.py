#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mock sender for TCP push-stream detector.

按 Enter 后读取本地视频，逐帧 JPEG 编码后主动推给检测端；
检测端返回 JSON 后立即停止发送并打印结果，然后等待下一次 Enter。
"""
from __future__ import annotations

import argparse
import json
import select
import socket
import struct
import time
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

import cv2

VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v"}
MAX_PACKET_BYTES = 64 * 1024 * 1024


def collect_videos(video_dir: Path, video: str = "") -> List[Path]:
    if video:
        p = Path(video).resolve()
        if not p.is_file():
            raise FileNotFoundError(p)
        return [p]
    root = video_dir.resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    xs = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in VIDEO_EXTS)
    if not xs:
        raise RuntimeError(f"no videos found under: {root}")
    return xs


def send_packet(sock: socket.socket, payload: bytes) -> None:
    if len(payload) > MAX_PACKET_BYTES:
        raise ValueError(f"packet too large: {len(payload)} bytes")
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def send_json(sock: socket.socket, data: Dict) -> None:
    send_packet(sock, json.dumps(data, ensure_ascii=False).encode("utf-8"))


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks = []
    left = int(n)
    while left > 0:
        b = sock.recv(left)
        if not b:
            raise EOFError("socket closed while receiving")
        chunks.append(b)
        left -= len(b)
    return b"".join(chunks)


def recv_result_blocking(sock: socket.socket) -> Dict:
    raw_len = recv_exact(sock, 4)
    n = struct.unpack("!I", raw_len)[0]
    if n <= 0 or n > MAX_PACKET_BYTES:
        raise RuntimeError(f"invalid result packet length: {n}")
    raw = recv_exact(sock, n)
    return json.loads(raw.decode("utf-8", errors="replace"))


class NonBlockingResultReader:
    def __init__(self):
        self.buf = bytearray()
        self.need: Optional[int] = None

    def try_recv(self, sock: socket.socket) -> Optional[Dict]:
        readable, _, _ = select.select([sock], [], [], 0)
        if not readable:
            return None
        b = sock.recv(65536)
        if not b:
            return None
        self.buf.extend(b)

        if self.need is None:
            if len(self.buf) < 4:
                return None
            self.need = struct.unpack("!I", bytes(self.buf[:4]))[0]
            del self.buf[:4]
            if self.need <= 0 or self.need > MAX_PACKET_BYTES:
                raise RuntimeError(f"invalid result packet length: {self.need}")

        if len(self.buf) < self.need:
            return None
        raw = bytes(self.buf[:self.need])
        del self.buf[:self.need]
        self.need = None
        return json.loads(raw.decode("utf-8", errors="replace"))


def send_video(args, video_path: Path) -> Dict:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")

    fps = float(cap.get(cv2.CAP_PROP_FPS) or args.fps or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = float(args.fps or 25.0)
    delay = (1.0 / fps) if args.realtime else 0.0

    session_id = uuid4().hex[:12]
    header = {
        "session_id": session_id,
        "source": str(video_path.name),
        "fps": fps,
        "max_seconds": float(args.max_seconds),
        "max_frames": int(args.max_frames),
        "params": {},
    }

    print(f"[SENDER] connect {args.host}:{args.port}")
    with socket.create_connection((args.host, int(args.port)), timeout=float(args.connect_timeout)) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        send_json(sock, header)
        reader = NonBlockingResultReader()
        frame_id = 0
        t0 = time.time()

        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_id += 1
            if args.max_frames > 0 and frame_id > args.max_frames:
                break
            if args.max_seconds > 0 and (frame_id / max(fps, 1.0)) > args.max_seconds:
                break

            ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(args.jpeg_quality)])
            if not ok:
                continue
            send_packet(sock, enc.tobytes())

            result = reader.try_recv(sock)
            if result is not None:
                print(f"[SENDER] result received early at sent_frame={frame_id}")
                cap.release()
                return result

            if delay > 0:
                time.sleep(delay)

        # 发送结束标记，然后等待检测端最终结果。
        send_packet(sock, b"")
        print(f"[SENDER] video sent, frames={frame_id}, wait result...")
        result = recv_result_blocking(sock)
        cap.release()
        result.setdefault("sender", {})
        result["sender"].update({
            "sent_frames": frame_id,
            "send_time_sec": time.time() - t0,
            "video": str(video_path),
        })
        return result


def build_argparser():
    p = argparse.ArgumentParser("Mock TCP push sender")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=19090)
    p.add_argument("--video", default="", help="single video path; if empty, use --video-dir")
    p.add_argument("--video-dir", default="videos")
    p.add_argument("--jpeg-quality", type=int, default=85)
    p.add_argument("--fps", type=float, default=25.0, help="fallback fps if video fps is invalid")
    p.add_argument("--max-seconds", type=float, default=20.0)
    p.add_argument("--max-frames", type=int, default=0)
    p.add_argument("--connect-timeout", type=float, default=10.0)
    p.add_argument("--realtime", action="store_true", help="send frames according to original fps; default sends as fast as possible")
    p.add_argument("--once", action="store_true", help="send one video and exit")
    return p


def main():
    args = build_argparser().parse_args()
    videos = collect_videos(Path(args.video_dir), args.video)
    print(f"[SENDER] videos={len(videos)}")
    for i, v in enumerate(videos):
        print(f"  [{i}] {v}")

    idx = 0
    while True:
        video_path = videos[idx % len(videos)]
        if not args.once:
            cmd = input(f"\nPress Enter to send [{idx % len(videos)}] {video_path.name}, or q to quit: ").strip().lower()
            if cmd in {"q", "quit", "exit"}:
                break

        try:
            result = send_video(args, video_path)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except Exception as exc:
            print(f"[SENDER][ERROR] {exc}")

        idx += 1
        if args.once:
            break


if __name__ == "__main__":
    main()
