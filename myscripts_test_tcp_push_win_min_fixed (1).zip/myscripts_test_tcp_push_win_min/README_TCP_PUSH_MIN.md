# TCP Push Windows Demo 最小版

## 逻辑

- 检测端常驻：`service_kick_detector_tcp_win.bat`
- 发送端模拟：`mock_sender_tcp_win.bat`
- 不使用 RTSP、不使用 MediaMTX、不使用 ffmpeg。
- 发送端按回车后读取本地视频，逐帧 JPEG 编码，通过 TCP 推给检测端。
- 检测端检测到踢球帧后返回 JSON，发送端停止发送并等待下一次回车。

## 启动

1. 启动检测端：

```bat
service_kick_detector_tcp_win.bat
```

2. 启动发送端：

```bat
mock_sender_tcp_win.bat
```

3. 在发送端窗口按回车。

## 常改参数

检测端参数改：`service_kick_detector_tcp_win.ps1`

```powershell
$PYTHON = "D:\anaconda3\envs\football\python.exe"
$BALL_MODEL = "$PROJECT_ROOT\my_models\yolo11s.engine"
$POSE_MODEL = "$PROJECT_ROOT\my_models\yolo11m-pose.engine"
$BIND_HOST = "0.0.0.0"
$TCP_PORT = "19090"
```

发送端参数改：`mock_sender_tcp_win.ps1`

```powershell
$DETECTOR_HOST = "127.0.0.1"
$DETECTOR_PORT = "19090"
$VIDEO_DIR = "$PROJECT_ROOT\videos"
```

## 这版修复点

- 不再用反引号长命令拼接 Python 参数。
- 统一用 PowerShell 参数数组 `@ArgsList` 调用 Python，避免 `--tcp-host` 后面变成空值。
- 对空环境变量做 Trim 检查。
- 启动时打印实际监听地址、模型路径、视频目录，方便排错。
