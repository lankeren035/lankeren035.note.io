$ErrorActionPreference = "Stop"

function Use-Env($Name, $Default) {
  $v = [Environment]::GetEnvironmentVariable($Name)
  if ($null -ne $v) {
    $s = [string]$v
    if ($s.Trim() -ne "") { return $s.Trim() }
  }
  return [string]$Default
}

function Add-Opt([System.Collections.ArrayList]$ArgsList, [string]$Name, $Value) {
  $s = [string]$Value
  if ($null -eq $Value -or $s.Trim() -eq "") {
    throw "Missing value for $Name"
  }
  [void]$ArgsList.Add($Name)
  [void]$ArgsList.Add($s)
}

$SCRIPT_DIR   = $PSScriptRoot
$PROJECT_ROOT = Use-Env "PROJECT_ROOT" (Split-Path -Parent $SCRIPT_DIR)
$PYTHON       = Use-Env "PYTHON" "D:\anaconda3\envs\football\python.exe"

if (!(Test-Path $PYTHON)) {
  throw "Python not found: $PYTHON. Edit PYTHON in this ps1 or set environment variable PYTHON."
}

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

# TCP 推帧检测服务：发送端主动连接这个端口并逐帧发送 JPEG 帧。
# 不使用 RTSP，不需要 MediaMTX，不需要 ffmpeg。

$BIND_HOST = Use-Env "TCP_HOST" "0.0.0.0"
$TCP_PORT  = Use-Env "TCP_PORT" "19090"
$BACKLOG   = Use-Env "BACKLOG" "16"
$SOCKET_TIMEOUT = Use-Env "SOCKET_TIMEOUT" "0"

$BALL_MODEL = Use-Env "BALL_MODEL" "$PROJECT_ROOT\my_models\yolo11s.engine"
$POSE_MODEL = Use-Env "POSE_MODEL" "$PROJECT_ROOT\my_models\yolo11m-pose.engine"
if (!(Test-Path $BALL_MODEL)) { $BALL_MODEL = "$PROJECT_ROOT\yolo11s.engine" }
if (!(Test-Path $POSE_MODEL)) { $POSE_MODEL = "$PROJECT_ROOT\yolo11m-pose.engine" }
if (!(Test-Path $BALL_MODEL)) { $BALL_MODEL = "$PROJECT_ROOT\yolo11s.pt" }
if (!(Test-Path $POSE_MODEL)) { $POSE_MODEL = "$PROJECT_ROOT\yolo11m-pose.pt" }

if (!(Test-Path $BALL_MODEL)) { throw "Ball model not found: $BALL_MODEL" }
if (!(Test-Path $POSE_MODEL)) { throw "Pose model not found: $POSE_MODEL" }

$DEVICE = Use-Env "DEVICE" "0"
$HALF   = Use-Env "HALF" "1"
$BATCH  = Use-Env "BATCH" "4"
$CHUNK  = Use-Env "CHUNK" "4"

$BALL_IMGSZ  = Use-Env "BALL_IMGSZ" "640"
$POSE_IMGSZ  = Use-Env "POSE_IMGSZ" "640"
$BALL_CONF   = Use-Env "BALL_CONF" "0.16"
$PERSON_CONF = Use-Env "PERSON_CONF" "0.20"
$POSE_CONF   = Use-Env "POSE_CONF" "0.18"

$YOLO_IOU = Use-Env "YOLO_IOU" "0.50"
$BALL_CLASS_NAMES = Use-Env "BALL_CLASS_NAMES" "sports ball,ball,football,soccer ball,volleyball"
$MAX_BALL_CANDIDATES = Use-Env "MAX_BALL_CANDIDATES" "8"
$HAND_CONF = Use-Env "HAND_CONF" "0.20"

# 球真实移动硬门槛：事件必须满足球心累计位移 >= max(px, ratio * image_width)。
# 摄像头距球约 1 米时，球大概率可见，建议优先调这两个参数过滤静止球误报。

$MIN_BALL_MOVE_PX = Use-Env "MIN_BALL_MOVE_PX" "35"
$MIN_BALL_MOVE_RATIO = Use-Env "MIN_BALL_MOVE_RATIO" "0.03"

# 首选逻辑：球可见高速大位移 + 脚与球同向移动；脚球距离不作为主触发门槛。

$MIN_BALL_SPEED_PXPF = Use-Env "MIN_BALL_SPEED_PXPF" "0"
$FOOT_BALL_SAME_DIR_COS = Use-Env "FOOT_BALL_SAME_DIR_COS" "0.35"
$MIN_FOOT_MOVE_PX = Use-Env "MIN_FOOT_MOVE_PX" "15"
$CONTACT_SUPPORT_DIST_NORM = Use-Env "CONTACT_SUPPORT_DIST_NORM" "3.2"
$BALL_SPEED_LOOKBACK = Use-Env "BALL_SPEED_LOOKBACK" "3"
$BALL_SPEED_JUMP_RATIO = Use-Env "BALL_SPEED_JUMP_RATIO" "1.6"
$DEBUG_DETECTIONS = Use-Env "DEBUG_DETECTIONS" "1"
$DEBUG_LOG_DIR = Use-Env "DEBUG_LOG_DIR" "$PROJECT_ROOT\debug_runs"
$DEBUG_FULL_SESSION = Use-Env "DEBUG_FULL_SESSION" "0"
$DEBUG_DECISION = Use-Env "DEBUG_DECISION" "1"
$DEBUG_CANDIDATE_LIMIT = Use-Env "DEBUG_CANDIDATE_LIMIT" "20"
$LOSS_REAPPEAR_SEC = Use-Env "LOSS_REAPPEAR_SEC" "0.70"
$ENABLE_LOSS_FALLBACK = Use-Env "ENABLE_LOSS_FALLBACK" "1"
$LOSS_FALLBACK_APPROACH_LOOKBACK = Use-Env "LOSS_FALLBACK_APPROACH_LOOKBACK" "4"
$ONLINE_WARMUP_SEC = Use-Env "ONLINE_WARMUP_SEC" "0.80"
$ONLINE_WAIT_SEC = Use-Env "ONLINE_WAIT_SEC" "0.12"
$STABLE_CHUNKS = Use-Env "STABLE_CHUNKS" "1"

Write-Host "[TCP SERVICE PS1] PROJECT_ROOT=$PROJECT_ROOT"
Write-Host "[TCP SERVICE PS1] LISTEN=$BIND_HOST`:$TCP_PORT"
Write-Host "[TCP SERVICE PS1] BALL_MODEL=$BALL_MODEL"
Write-Host "[TCP SERVICE PS1] POSE_MODEL=$POSE_MODEL"

$ArgsList = New-Object System.Collections.ArrayList
[void]$ArgsList.Add("$SCRIPT_DIR\service_kick_detector_tcp.py")
Add-Opt $ArgsList "--tcp-host" $BIND_HOST
Add-Opt $ArgsList "--tcp-port" $TCP_PORT
Add-Opt $ArgsList "--backlog" $BACKLOG
Add-Opt $ArgsList "--socket-timeout" $SOCKET_TIMEOUT
Add-Opt $ArgsList "--ball-model" $BALL_MODEL
Add-Opt $ArgsList "--pose-model" $POSE_MODEL
Add-Opt $ArgsList "--device" $DEVICE
if ($HALF -eq "1" -and $DEVICE -ne "cpu") { [void]$ArgsList.Add("--half") }
Add-Opt $ArgsList "--batch" $BATCH
Add-Opt $ArgsList "--online-chunk" $CHUNK
[void]$ArgsList.Add("--pad-last-batch")
Add-Opt $ArgsList "--ball-imgsz" $BALL_IMGSZ
Add-Opt $ArgsList "--pose-imgsz" $POSE_IMGSZ
Add-Opt $ArgsList "--ball-conf" $BALL_CONF
Add-Opt $ArgsList "--person-conf" $PERSON_CONF
Add-Opt $ArgsList "--pose-conf" $POSE_CONF
Add-Opt $ArgsList "--yolo-iou" $YOLO_IOU
Add-Opt $ArgsList "--ball-class-names" $BALL_CLASS_NAMES
Add-Opt $ArgsList "--max-ball-candidates" $MAX_BALL_CANDIDATES
Add-Opt $ArgsList "--hand-conf" $HAND_CONF
Add-Opt $ArgsList "--min-ball-move-px" $MIN_BALL_MOVE_PX
Add-Opt $ArgsList "--min-ball-move-ratio" $MIN_BALL_MOVE_RATIO
Add-Opt $ArgsList "--min-ball-speed-pxpf" $MIN_BALL_SPEED_PXPF
Add-Opt $ArgsList "--foot-ball-same-dir-cos" $FOOT_BALL_SAME_DIR_COS
Add-Opt $ArgsList "--min-foot-move-px" $MIN_FOOT_MOVE_PX
Add-Opt $ArgsList "--contact-support-dist-norm" $CONTACT_SUPPORT_DIST_NORM
Add-Opt $ArgsList "--ball-speed-lookback" $BALL_SPEED_LOOKBACK
Add-Opt $ArgsList "--ball-speed-jump-ratio" $BALL_SPEED_JUMP_RATIO
if ($DEBUG_DETECTIONS -eq "1") {
  [void]$ArgsList.Add("--debug-detections")
  Add-Opt $ArgsList "--debug-log-dir" $DEBUG_LOG_DIR
  if ($DEBUG_FULL_SESSION -eq "1") { [void]$ArgsList.Add("--debug-full-session") }
  if ($DEBUG_DECISION -eq "1") {
    [void]$ArgsList.Add("--debug-decision")
    Add-Opt $ArgsList "--debug-candidate-limit" $DEBUG_CANDIDATE_LIMIT
  }
}
Add-Opt $ArgsList "--loss-reappear-sec" $LOSS_REAPPEAR_SEC
Add-Opt $ArgsList "--enable-loss-fallback" $ENABLE_LOSS_FALLBACK
Add-Opt $ArgsList "--loss-fallback-approach-lookback" $LOSS_FALLBACK_APPROACH_LOOKBACK
Add-Opt $ArgsList "--online-warmup-sec" $ONLINE_WARMUP_SEC
Add-Opt $ArgsList "--online-wait-sec" $ONLINE_WAIT_SEC
Add-Opt $ArgsList "--stable-chunks" $STABLE_CHUNKS

& $PYTHON @ArgsList
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
