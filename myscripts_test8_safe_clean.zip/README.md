# 足球踢球检测代码使用说明（clean-safe 版）

本版本以 `myscripts_test7` 为基线，保留原 TCP 通信、发送端、服务端收帧逻辑不变；清理检测逻辑中的旧 `blur_loss/direct_motion` 分支。当前在线检测只保留两层：

1. **主逻辑 visible_ball_speed**：球突然大位移 + 球速度突增 + 脚与球同方向运动 + 脚大致在球附近。
2. **loss_only_fallback**：球在脚附近后突然长期丢失，用于处理高速踢出导致球检测不到的情况。

## 一、推荐启动方式

### 1. 启动检测服务端

Windows：

```powershell
.\service_kick_detector_tcp_win.bat
```

正式在线检测建议：

```powershell
$env:DEBUG_FULL_SESSION="0"
$env:CONTACT_SUPPORT_DIST_NORM="3.2"
$env:ENABLE_LOSS_FALLBACK="1"
.\service_kick_detector_tcp_win.bat
```

### 2. 本地视频发送端

```powershell
.\mock_sender_tcp_win.bat
```

交互：

- 回车：处理下一个视频。
- 空格 + 回车：继续当前视频后续帧。
- q：退出。

### 3. 摄像头发送端

```powershell
.\mock_camera_sender_tcp_win.bat
```

检测到 kick 后发送端暂停；回车或空格继续下一次检测，q 退出。

## 二、服务端核心参数

### 模型和推理参数

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `BALL_MODEL` | `D:\football\yolo11s.engine` | 球检测 TensorRT engine 路径 |
| `POSE_MODEL` | `D:\football\yolo11m-pose.engine` | 人体姿态 TensorRT engine 路径 |
| `DEVICE` | `0` | GPU 编号 |
| `HALF` | `1` | 是否使用半精度 |
| `BATCH` | `4` | 模型推理 batch size |
| `ONLINE_CHUNK` | `4` | 服务端每攒多少帧处理一次，单位是帧 |
| `BALL_IMGSZ` | `1280` | 球检测输入尺寸 |
| `POSE_IMGSZ` | `960` | 姿态检测输入尺寸 |
| `BALL_CONF` | `0.16` | 球检测置信度阈值 |
| `PERSON_CONF` | `0.20` | 人检测置信度阈值 |
| `POSE_CONF` | `0.18` | 姿态关键点置信度阈值 |
| `YOLO_IOU` | `0.45` | YOLO NMS IoU 阈值 |
| `MAX_BALL_CANDIDATES` | `8` | 每帧最多保留多少个球候选 |
| `HAND_CONF` | `0.20` | 手部关键点有效阈值，用于过滤手比脚更近的情况 |

### 主逻辑参数

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `MIN_BALL_MOVE_PX` | `35` | 球单步大位移的最小像素阈值 |
| `MIN_BALL_MOVE_RATIO` | `0.03` | 球单步大位移相对图像宽度的比例阈值 |
| `MIN_BALL_SPEED_PXPF` | `0` | 球每帧速度下限；0 表示不额外启用 |
| `BALL_SPEED_LOOKBACK` | `3` | 判断球速度突增时，向前看几帧速度中值 |
| `BALL_SPEED_JUMP_RATIO` | `1.6` | 当前球速至少是前序速度中值的多少倍 |
| `FOOT_BALL_SAME_DIR_COS` | `0.35` | 脚运动方向和球运动方向的余弦阈值 |
| `MIN_FOOT_MOVE_PX` | `15` | 脚至少移动多少像素才算有效动作 |
| `CONTACT_SUPPORT_DIST_NORM` | `3.2` | 脚踝到球心距离上限，单位是球半径倍数。脚尖踢球建议用 3.2。 |
| `BALL_GAP_LOOKBACK` | `3` | 球短暂漏检后重现时，最多回看几帧 |
| `EVENT_SEARCH_START_SEC` | `0.80` | 视频/会话开头多少秒内不允许报事件，防止启动抖动 |
| `MIN_EVENT_GAP_SEC` | `1.20` | 多事件之间的最小间隔，避免一次踢飞重复报 |

### loss fallback 参数

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `ENABLE_LOSS_FALLBACK` | `1` | 是否启用球贴脚后突然长期丢失的兜底逻辑 |
| `LOSS_REAPPEAR_SEC` | `0.70` | 球消失后连续多少秒没回来，认为是长期丢球 |
| `LOSS_FALLBACK_APPROACH_LOOKBACK` | `4` | 检查丢球前几帧脚是否在靠近球 |

### 在线返回控制

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `ONLINE_WARMUP_SEC` | `0.8` | 在线检测开始后先积累多少秒再允许判断 |
| `ONLINE_WAIT_SEC` | `0.12` | 候选事件后至少再看多少秒未来证据 |
| `STABLE_CHUNKS` | `1` | 连续几次 chunk 判断结果一致才返回 |
| `DEBUG_FULL_SESSION` | `0` | 1 表示即使检测到也继续跑完整段；正式在线必须设 0 |
| `DEBUG_DETECTIONS` | `1` | 是否保存检测日志 |
| `DEBUG_DECISION` | `1` | 是否保存候选拒绝原因 |

## 三、已不再暴露的旧参数

以下旧参数不再建议调，也不在启动脚本中暴露：

```text
CONTACT_PERCENTILE
MOTION_PERCENTILE
DIRECTION_COS_THRESH
MOTION_WINDOW_SEC
MIN_VISIBLE_STEPS
BALL_MOVE_LOOKAHEAD_SEC
BALL_MOVE_CONTACT_GATE
STRONG_BALL_MOVE_MULT
ALLOW_BLUR_FALLBACK_EARLY
```

原因：当前主路径已经统一为“球大位移 + 脚同方向 + 脚大致在球附近”，这些参数属于旧 `blur_loss/direct_motion` 体系，容易造成理解混乱。
