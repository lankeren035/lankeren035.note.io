#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Camera sender for TCP push-stream detector.

协议与 myscripts_test2 保持一致：
1) start JSON: uint32_be length + JSON bytes
2) frame:      uint32_be length + JPEG bytes
3) end:        uint32_be(0)

本文件只替换视频来源：
- 原 mock_sender_tcp.py 从 mp4 读帧；
- 本文件从本地摄像头实时读取帧。
"""
from __future__ import annotations

import argparse
import json
import select
import socket
import struct
import time
from typing import Dict, Optional
from uuid import uuid4

import cv2

MAX_PACKET_BYTES = 64 * 1024 * 1024


def send_packet(sock: socket.socket, payload: bytes) -> None:
    if len(payload) > MAX_PACKET_BYTES:
        raise ValueError(f"packet too large: {len(payload)} bytes")
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def send_json(sock: socket.socket, data: Dict) -> None:
    send_packet(sock, json.dumps(data, ensure_ascii=False).encode("utf-8"))


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks = []
    left = int(n)
    while left > 0:
        b = sock.recv(left)
        if not b:
            raise EOFError("socket closed while receiving")
        chunks.append(b)
        left -= len(b)
    return b"".join(chunks)


def recv_result_blocking(sock: socket.socket) -> Dict:
    raw_len = recv_exact(sock, 4)
    n = struct.unpack("!I", raw_len)[0]
    if n <= 0 or n > MAX_PACKET_BYTES:
        raise RuntimeError(f"invalid result packet length: {n}")
    raw = recv_exact(sock, n)
    return json.loads(raw.decode("utf-8", errors="replace"))


class NonBlockingResultReader:
    def __init__(self):
        self.buf = bytearray()
        self.need: Optional[int] = None

    def try_recv(self, sock: socket.socket) -> Optional[Dict]:
        readable, _, _ = select.select([sock], [], [], 0)
        if not readable:
            return None
        b = sock.recv(65536)
        if not b:
            return None
        self.buf.extend(b)

        if self.need is None:
            if len(self.buf) < 4:
                return None
            self.need = struct.unpack("!I", bytes(self.buf[:4]))[0]
            del self.buf[:4]
            if self.need <= 0 or self.need > MAX_PACKET_BYTES:
                raise RuntimeError(f"invalid result packet length: {self.need}")

        if len(self.buf) < self.need:
            return None
        raw = bytes(self.buf[:self.need])
        del self.buf[:self.need]
        self.need = None
        return json.loads(raw.decode("utf-8", errors="replace"))


def open_camera(args) -> cv2.VideoCapture:
    # Windows 下 CAP_DSHOW 通常启动更快、延迟更低；失败则退回默认后端。
    if args.backend == "dshow":
        cap = cv2.VideoCapture(int(args.camera_index), cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap.release()
            cap = cv2.VideoCapture(int(args.camera_index))
    else:
        cap = cv2.VideoCapture(int(args.camera_index))

    if not cap.isOpened():
        raise RuntimeError(f"cannot open camera index: {args.camera_index}")

    if args.width > 0:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(args.width))
    if args.height > 0:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(args.height))
    if args.fps > 0:
        cap.set(cv2.CAP_PROP_FPS, float(args.fps))

    return cap


def send_camera_session(args, sock: socket.socket, cap: cv2.VideoCapture) -> Dict:
    fps = float(args.fps or cap.get(cv2.CAP_PROP_FPS) or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = 25.0

    session_id = uuid4().hex[:12]
    source = f"camera_{args.camera_index}"
    header = {
        "type": "start",
        "session_id": session_id,
        "source": source,
        "fps": fps,
        "max_seconds": float(args.max_seconds),
        "max_frames": int(args.max_frames),
        "params": {},
    }
    send_json(sock, header)

    print(f"[CAMERA] start session={session_id}, source={source}, fps={fps:.3f}", flush=True)

    reader = NonBlockingResultReader()
    t0 = time.time()
    frame_id = 0
    sent_frames = 0
    got_result = None

    while True:
        result = reader.try_recv(sock)
        if result is not None:
            got_result = result
            print(f"[CAMERA] result received before next frame, sent_frames={sent_frames}", flush=True)
            break

        ok, frame = cap.read()
        if not ok or frame is None:
            print("[CAMERA][WARN] read camera frame failed", flush=True)
            time.sleep(0.01)
            continue

        frame_id += 1
        if args.max_frames > 0 and frame_id > args.max_frames:
            break
        if args.max_seconds > 0 and (time.time() - t0) > args.max_seconds:
            break

        ok, enc = cv2.imencode(
            ".jpg",
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), int(args.jpeg_quality)],
        )
        if not ok:
            continue

        send_packet(sock, enc.tobytes())
        sent_frames += 1

        if sent_frames % int(args.print_every) == 0:
            print(f"[CAMERA] sent frame={sent_frames}", flush=True)

        result = reader.try_recv(sock)
        if result is not None:
            got_result = result
            print(f"[CAMERA] result received at sent_frame={sent_frames}", flush=True)
            break

        if args.show:
            cv2.imshow("camera sender", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                print("[CAMERA] manual stop", flush=True)
                break

    # 本轮结束。连接不断，检测端回到等待下一次 start。
    send_packet(sock, b"")

    if got_result is None:
        print(f"[CAMERA] session ended, sent_frames={sent_frames}, wait result...", flush=True)
        got_result = recv_result_blocking(sock)

    got_result.setdefault("sender", {})
    got_result["sender"].update({
        "sent_frames": sent_frames,
        "send_time_sec": time.time() - t0,
        "source": source,
    })
    return got_result


def build_argparser():
    p = argparse.ArgumentParser("Camera TCP push sender")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=19090)
    p.add_argument("--camera-index", type=int, default=0)
    p.add_argument("--backend", choices=["default", "dshow"], default="dshow")
    p.add_argument("--width", type=int, default=1280)
    p.add_argument("--height", type=int, default=720)
    p.add_argument("--fps", type=float, default=30.0)
    p.add_argument("--jpeg-quality", type=int, default=85)
    p.add_argument("--max-seconds", type=float, default=0.0, help="0 means no time limit")
    p.add_argument("--max-frames", type=int, default=0, help="0 means no frame limit")
    p.add_argument("--connect-timeout", type=float, default=10.0)
    p.add_argument("--show", action="store_true", help="show camera preview; press q/ESC to stop current session")
    p.add_argument("--print-every", type=int, default=10)
    p.add_argument("--once", action="store_true", help="send one camera session and exit")
    return p


def main():
    args = build_argparser().parse_args()
    args.print_every = max(1, int(args.print_every))

    cap = open_camera(args)
    actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    actual_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    print(f"[CAMERA] opened camera={args.camera_index}, size={actual_w}x{actual_h}, cap_fps={actual_fps:.3f}")

    print(f"[CAMERA] connect {args.host}:{args.port}")
    try:
        with socket.create_connection((args.host, int(args.port)), timeout=float(args.connect_timeout)) as sock:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            print("[CAMERA] connected; press Enter to start camera streaming")

            while True:
                if not args.once:
                    cmd = input("\nPress Enter to start camera detection, or q to quit: ").strip().lower()
                    if cmd in {"q", "quit", "exit"}:
                        break
                try:
                    result = send_camera_session(args, sock, cap)
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                except Exception as exc:
                    print(f"[CAMERA][ERROR] {exc}", flush=True)
                    break
                if args.once:
                    break
    finally:
        cap.release()
        if args.show:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
