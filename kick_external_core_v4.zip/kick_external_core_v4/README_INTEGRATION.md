# 足球踢球检测 TCP 帧流对接说明

本说明针对 `myscripts_test6.zip`。

服务端仍然使用 `myscripts_test6.zip` 里的现有启动方式，例如：

- `service_kick_detector_tcp_win.bat`
- `service_kick_detector_tcp_win.ps1`
- 或直接运行 `service_kick_detector_tcp.py`

本接口文件只负责第三方程序把视频帧发送给检测端，并在检测端返回结果后停止当前 session。

---

## 1. 文件放置

对接方至少需要同目录下有：

```text
external_core_sender.py      # 本接口文件
tcp_packet.py                # myscripts_test6.zip 里已有，不需要重写
```

`external_core_sender.py` 是从 `mock_camera_sender_tcp.py` 的核心发送逻辑裁剪出来的：

- 保留 `encode_and_send_frame()`；
- 保留 `NonBlockingJsonReader.try_recv()` 的“发送前/发送后检查返回结果”逻辑；
- 保留“收到检测结果后立即停止传输当前 session”的逻辑；
- 删除摄像头读取、debug 保存、预览窗口、命令行交互等额外逻辑。

---

## 2. 输入帧格式

第三方系统传入的每一帧必须是：

```text
类型：numpy.ndarray
颜色：OpenCV BGR
dtype：uint8
shape：(H, W, 3)
```

如果第三方拿到的是 RGB，需要转换：

```python
frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
```

如果第三方拿到的是 PIL Image，也需要转成 BGR：

```python
import numpy as np
import cv2

frame_rgb = np.array(pil_image)
frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
```

---

## 3. 发送给检测端的数据形式

每一帧都会被编码成 JPEG，然后通过 `tcp_packet.py` 发送。

底层包格式是：

```text
4字节大端整数 payload_len
+ JSON header
+ 两个换行符 b"\n\n"
+ JPEG bytes
```

JSON header 示例：

```json
{
  "session_id": "20260525_153012_external_camera_0_000",
  "source": "external_camera_0",
  "fps": 30.0,
  "frame_idx": 0,
  "global_frame_idx": 0,
  "is_last": false,
  "params": {}
}
```

字段说明：

| 字段 | 说明 |
|---|---|
| `session_id` | 当前检测片段 ID。一次检测一个 session。检测到结果后应开启下一个 session。 |
| `source` | 来源名称，例如 `external_camera_0`。 |
| `fps` | 帧率。检测端会用它把秒参数换算成帧数。 |
| `frame_idx` | 当前 session 内的 0-based 帧号。 |
| `global_frame_idx` | 第三方系统里的全局 0-based 帧号，可选但建议传。 |
| `is_last` | 是否是当前 session 最后一帧。实时流一般填 `False`。 |
| `params` | 可选参数。通常留 `{}`，主要参数由服务端启动脚本控制。 |

---

## 4. 最小调用示例

```python
import cv2

from external_core_sender import connect_detector, send_external_frame_session


def your_frame_generator():
    while True:
        # 替换成第三方自己的取帧逻辑
        frame_bgr = get_one_frame_from_your_system()

        if frame_bgr is None:
            break

        # 必须 yield OpenCV BGR uint8, shape=(H,W,3)
        yield frame_bgr


with connect_detector("127.0.0.1", 19090) as sock:
    result = send_external_frame_session(
        sock,
        your_frame_generator(),
        fps=30.0,
        source="external_camera_0",
        start_frame_idx=0,
        start_global_frame_idx=0,
        jpeg_quality=85,
    )

print(result)
```

`send_external_frame_session()` 会持续发送帧；每发送一帧前后都会尝试接收检测端返回。如果检测端返回结果，函数立即返回，调用方就应该停止当前 session 的帧传输。

---

## 5. 有限帧流如何结束

实时摄像头通常持续产出帧，直到检测端返回结果。

如果对接方传的是有限帧流，建议最后一帧传 `(frame_bgr, True)`，表示 `is_last=True`：

```python
def finite_frame_generator(frames):
    n = len(frames)
    for i, frame_bgr in enumerate(frames):
        is_last = (i == n - 1)
        yield frame_bgr, is_last
```

否则如果整个片段没有检测到 kick，客户端最后可能会等待服务端最终结果。

---

## 6. 返回结果

检测到事件后服务端返回 JSON。常用字段：

```python
result["status"]
result["kick"]["frame_idx"]
result["kick"]["frame_id"]
result["kick"]["kind"]
result["kick"]["score"]
```

其中：

```text
frame_idx = 当前 session 内 0-based 帧号
frame_id  = 当前 session 内 1-based 帧号
```

如果发送时传了 `global_frame_idx`，服务端/发送端结果里也可能包含全局帧号字段，方便和第三方原始视频流对齐。

---

## 7. 和 mock_camera_sender_tcp.py 的对应关系

原来的 `mock_camera_sender_tcp.py` 关键流程是：

```text
cap.read() 取一帧
encode_and_send_frame() 编码并发送
reader.try_recv() 检查检测端返回
收到 result 后 break 停止当前 session
```

本接口只是把：

```python
ok, frame = cap.read()
```

替换成：

```python
for frame in frame_iter:
```

其他核心网络逻辑保持一致。
