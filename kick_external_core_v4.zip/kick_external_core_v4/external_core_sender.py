#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Core external-frame sender for myscripts_test6 TCP kick detector.

This file is cut from the structure of mock_camera_sender_tcp.py:
- keep encode_and_send_frame()
- keep NonBlockingJsonReader + try_recv before/after sending each frame
- stop sending immediately after detector returns a result
- remove camera reading, debug saving, preview, and interactive input

Dependency:
    Put this file in the same directory as myscripts_test6/tcp_packet.py,
    or make sure tcp_packet.py is on PYTHONPATH.
"""
from __future__ import annotations

import re
import socket
import time
from datetime import datetime
from typing import Dict, Iterable, Optional, Tuple, Union, Any

import cv2
import numpy as np

from tcp_packet import NonBlockingJsonReader, make_frame_packet, recv_json, send_packet


FrameItem = Union[np.ndarray, Tuple[np.ndarray, bool]]

_LAST_SESSION_STAMP = ""
_LAST_SESSION_SEQ = 0


def safe_token(s: str, max_len: int = 40) -> str:
    s = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fa5]+", "_", str(s)).strip("_")
    return (s or "session")[:max_len]


def make_session_id(source: str = "external_camera_0") -> str:
    """Readable session id, same style as mock_camera_sender_tcp.py without debug-file checking."""
    global _LAST_SESSION_STAMP, _LAST_SESSION_SEQ
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if stamp == _LAST_SESSION_STAMP:
        _LAST_SESSION_SEQ += 1
    else:
        _LAST_SESSION_STAMP = stamp
        _LAST_SESSION_SEQ = 0
    return f"{stamp}_{safe_token(source)}_{_LAST_SESSION_SEQ:03d}"


def encode_and_send_frame(sock: socket.socket, frame, meta: Dict[str, Any], jpeg_quality: int = 85) -> None:
    """Same core sending function as mock_camera_sender_tcp.py."""
    ok, enc = cv2.imencode(
        ".jpg",
        frame,
        [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)],
    )
    if not ok:
        raise RuntimeError("JPEG encode failed")
    send_packet(sock, make_frame_packet(meta, enc.tobytes()))


def _parse_frame_item(item: FrameItem) -> Tuple[np.ndarray, bool]:
    """
    Accepted frame_iter item formats:
      1) frame_bgr
      2) (frame_bgr, is_last)

    For real-time streams, use format 1 and keep yielding frames until detector returns.
    For finite streams, mark the final frame as (frame_bgr, True), otherwise recv_json()
    may block if no kick is detected before the stream ends.
    """
    if isinstance(item, tuple) and len(item) == 2:
        frame, is_last = item
        return frame, bool(is_last)
    return item, False


def send_external_frame_session(
    sock: socket.socket,
    frame_iter: Iterable[FrameItem],
    *,
    fps: float = 30.0,
    source: str = "external_camera_0",
    session_id: Optional[str] = None,
    start_frame_idx: int = 0,
    start_global_frame_idx: Optional[int] = None,
    jpeg_quality: int = 85,
    params: Optional[Dict[str, Any]] = None,
    wait_final_result: bool = True,
) -> Dict[str, Any]:
    """
    Send frames to the detector and stop immediately when result is received.

    This is the external-frame version of mock_camera_sender_tcp.py::send_camera_session().
    The only difference is that cap.read() is replaced by frame_iter.

    Parameters
    ----------
    sock:
        Connected TCP socket to service_kick_detector_tcp.py.
    frame_iter:
        Iterable yielding OpenCV BGR uint8 frames, or (frame, is_last).
    fps:
        FPS of the incoming frame stream. Used by detector for time-window thresholds.
    source:
        Source name written into meta, e.g. "external_camera_0".
    session_id:
        Optional session id. If None, a readable id is generated.
    start_frame_idx:
        Frame index inside this session. Usually 0.
    start_global_frame_idx:
        Optional global frame index in the upstream system. If None, same as frame_idx.
    jpeg_quality:
        JPEG quality for transmission.
    params:
        Optional per-session params. Usually leave {} because service-side startup args are primary.
    wait_final_result:
        If True, call recv_json(sock) after frame_iter ends without result.
        For endless real-time streams this branch is normally not reached.

    Returns
    -------
    dict:
        Detector result JSON. Once this function returns, caller should stop sending the
        current session. To detect the next kick, call this function again with a new session.
    """
    fps = float(fps)
    if fps <= 1e-6 or fps > 240:
        fps = 30.0

    if session_id is None:
        session_id = make_session_id(source)
    if start_global_frame_idx is None:
        start_global_frame_idx = start_frame_idx
    if params is None:
        params = {}

    reader = NonBlockingJsonReader()
    t0 = time.time()
    frame_idx = int(start_frame_idx)
    global_frame_idx = int(start_global_frame_idx)
    sent_frames = 0

    for item in frame_iter:
        # Same as mock_camera_sender_tcp.py: check result before sending next frame.
        result = reader.try_recv(sock)
        if result is not None:
            result.setdefault("sender", {})
            result["sender"].update({
                "session_id": session_id,
                "source": source,
                "sent_frames": sent_frames,
                "send_time_sec": time.time() - t0,
            })
            return result

        frame_bgr, is_last = _parse_frame_item(item)
        if frame_bgr is None:
            break
        if not isinstance(frame_bgr, np.ndarray):
            raise TypeError("frame must be numpy.ndarray")
        if frame_bgr.ndim != 3 or frame_bgr.shape[2] != 3:
            raise ValueError("frame must have shape (H, W, 3)")
        if frame_bgr.dtype != np.uint8:
            raise ValueError("frame dtype must be uint8")

        meta = {
            "session_id": session_id,
            "source": source,
            "fps": fps,
            "frame_idx": frame_idx,
            "global_frame_idx": global_frame_idx,
            "is_last": bool(is_last),
            "params": params,
        }
        encode_and_send_frame(sock, frame_bgr, meta, jpeg_quality)
        sent_frames += 1
        frame_idx += 1
        global_frame_idx += 1

        # Same as mock_camera_sender_tcp.py: check result right after sending one frame.
        result = reader.try_recv(sock)
        if result is not None:
            result.setdefault("sender", {})
            result["sender"].update({
                "session_id": session_id,
                "source": source,
                "sent_frames": sent_frames,
                "send_time_sec": time.time() - t0,
            })
            return result

        if is_last:
            break

    if not wait_final_result:
        return {
            "status": "no_result_yet",
            "sender": {
                "session_id": session_id,
                "source": source,
                "sent_frames": sent_frames,
                "send_time_sec": time.time() - t0,
            },
        }

    result = recv_json(sock)
    result.setdefault("sender", {})
    result["sender"].update({
        "session_id": session_id,
        "source": source,
        "sent_frames": sent_frames,
        "send_time_sec": time.time() - t0,
    })
    return result


def connect_detector(host: str = "127.0.0.1", port: int = 19090, timeout: float = 10.0) -> socket.socket:
    """Small helper matching the socket creation style in mock_camera_sender_tcp.py."""
    sock = socket.create_connection((host, int(port)), timeout=float(timeout))
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sock
