# 足球踢球点 TCP 检测对接说明

## 1. 目录文件

核心文件：

- `service_kick_detector_tcp.py`：检测服务端，加载球检测模型和人体姿态模型，监听 TCP 帧流，检测到第一次有效踢球点后返回结果。
- `mock_sender_tcp.py`：本地视频发送端，用于测试视频文件。
- `mock_camera_sender_tcp.py`：摄像头发送端，用于真实摄像头输入。
- `tcp_packet.py`：TCP 包收发工具，协议为 `长度头 + JSON header + JPEG image`。
- `kick_common.py`、`kick_offline.py`、`debug_trace.py`：检测逻辑与调试记录。
- `visualize_debug_session.py`：把调试视频和检测 jsonl 合成为可视化视频。

Windows 启动脚本：

- `service_kick_detector_tcp_win.ps1` / `.bat`：启动检测服务端。
- `mock_sender_tcp_win.ps1` / `.bat`：启动本地视频发送端。
- `mock_camera_sender_tcp_win.ps1` / `.bat`：启动摄像头发送端。
- `visualize_debug_all_win.ps1` / `.bat`：批量生成 debug 可视化视频。

## 2. TCP 交互协议

当前版本只有一种输入包，不再有 start 包和 end 包。

每个客户端输入包都是：

```text
4字节长度头 + JSON header + \n\n + JPEG图片二进制
```

JSON header 常用字段：

```json
{
  "session_id": "20260522_153012",
  "source": "video.mp4@frame0",
  "fps": 30.0,
  "frame_idx": 0,
  "global_frame_idx": 0,
  "is_last": false,
  "params": {}
}
```

服务端收到第一帧就自动开始一次 session；检测到 event 后立即返回 JSON 结果，然后清空当前 session，继续监听下一次帧输入。

## 3. 检测结果

服务端返回示例：

```json
{
  "status": "hit",
  "event": "kick",
  "frame_idx": 130,
  "frame_id": 131,
  "time_sec": 4.333,
  "kind": "ball_speed_foot_dir",
  "kick": {
    "frame_idx": 130,
    "frame_id": 131,
    "kind": "ball_speed_foot_dir"
  }
}
```

说明：

- `frame_idx`：0-based 帧号。
- `frame_id`：1-based 帧号。
- 本地视频发送端会额外写入：
  - `sender.global_start_frame`
  - `sender.global_next_frame`
  - `sender.global_event_frame_idx`
  - `sender.global_event_frame_id`

如果处理同一个视频中的多个踢球点，应优先看 `sender.global_event_frame_idx`。

## 4. 默认在线参数

当前默认值：

```text
online_chunk = 4
online_wait_sec = 0.12
stable_chunks = 1
batch = 4
```

含义：

- `online_chunk`：每收到多少帧做一次检测判断，单位是帧。
- `batch`：模型推理 batch size，不等于 chunk。
- `online_wait_sec`：候选事件后需要看多少未来帧证据；代码里不再强制最少 6 帧。
- `stable_chunks`：候选结果需要连续几次 chunk 判断一致才输出。

## 5. 本地视频发送端交互

运行 `mock_sender_tcp_win.bat` 后：

```text
回车：处理下一个视频
空格 + 回车：继续当前视频后续帧
q：退出
```

适合一个视频中有多个踢球点的情况。

## 6. 摄像头发送端交互

运行 `mock_camera_sender_tcp_win.bat` 后：

```text
回车 / 空格 + 回车：继续摄像头检测
q：退出
```

检测到一次 event 后发送端会暂停，等待人工继续。

## 7. Debug 文件命名

Debug 文件统一使用年月日时分秒命名，便于排序和人工查看，例如：

```text
debug_runs/send_20260522_153012.mp4
debug_runs/send_20260522_153012.json
debug_runs/det_20260522_153012.jsonl
debug_runs/vis_20260522_153012.mp4
```

如果同一秒内连续启动多个 session，会追加 `_01`、`_02` 作为后缀。

启用检测日志：

```powershell
$env:DEBUG_DETECTIONS="1"
```

启用摄像头发送端保存原始调试视频：

```powershell
$env:DEBUG_SAVE_VIDEO="1"
```

生成可视化视频：

```powershell
.\visualize_debug_all_win.bat
```

## 8. 当前检测逻辑概要

主逻辑优先看球：

```text
球发生明显大位移
+ event 附近有真实脚点
+ 脚在前几帧到当前帧之间朝球飞出方向运动
+ 时序和距离支持
```

只有主逻辑完全没有命中时，才使用丢球/模糊 fallback。服务端默认只返回第一次有效踢球事件。
