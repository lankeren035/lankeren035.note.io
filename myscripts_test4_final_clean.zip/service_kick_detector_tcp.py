#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TCP push-frame kick-contact detection service.

Simplified protocol:
- No start packet, no end packet.
- Each client->server packet is one frame packet: JSON header + JPEG image.
- The first frame packet starts a new session automatically.
- The server returns one JSON result as soon as an event is confirmed, then resets
  and waits for the next frame packet/session on the same TCP connection.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import socket
import threading
import time
import traceback
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from datetime import datetime


import cv2
import numpy as np
from ultralytics import YOLO

from kick_common import (
    Event,
    FrameObs,
    VideoResult,
    append_observations,
    best_event,
    event_to_dict,
    frames,
    make_result,
    new_track,
    predict_batch,
)
from kick_offline import detect_events
from debug_trace import DebugJsonlWriter, obs_to_debug_row
from tcp_packet import recv_frame_packet, send_json

_LAST_SESSION_STAMP = ""
_LAST_SESSION_SEQ = 0


def make_session_id() -> str:
    global _LAST_SESSION_STAMP, _LAST_SESSION_SEQ
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if stamp == _LAST_SESSION_STAMP:
        _LAST_SESSION_SEQ += 1
    else:
        _LAST_SESSION_STAMP = stamp
        _LAST_SESSION_SEQ = 0
    return stamp if _LAST_SESSION_SEQ == 0 else f"{stamp}_{_LAST_SESSION_SEQ:02d}"


DEFAULT_ONLINE_WARMUP_SEC = 0.80
DEFAULT_ONLINE_WAIT_SEC = 0.12
DEFAULT_STABLE_CHUNKS = 1

OVERRIDABLE_FIELDS = {
    "ball_conf", "person_conf", "pose_conf", "yolo_iou", "max_ball_candidates", "hand_conf",
    "contact_percentile", "motion_percentile", "direction_cos_thresh", "motion_window_sec",
    "min_visible_steps", "loss_reappear_sec", "online_warmup_sec", "online_wait_sec",
    "stable_chunks", "online_chunk", "batch", "ball_imgsz", "pose_imgsz",
    "min_ball_move_px", "min_ball_move_ratio", "ball_move_lookahead_sec", "ball_move_contact_gate",
    "min_ball_speed_pxpf", "foot_ball_same_dir_cos", "min_foot_move_px", "strong_ball_move_mult",
    "ball_speed_lookback", "ball_speed_jump_ratio", "min_event_gap_sec", "return_all_events",
    "allow_blur_fallback_early", "debug_detections", "debug_full_session",
    "event_search_start_sec", "contact_support_dist_norm", "ball_gap_lookback", "debug_decision", "debug_candidate_limit",
}


def _cfg(args: argparse.Namespace, name: str, default):
    return getattr(args, name, default)


def _finite_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        v = float(x)
    except Exception:
        return default
    return v if math.isfinite(v) else default


def _json_safe(x: Any) -> Any:
    if x is None or isinstance(x, (str, bool, int)):
        return x
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, Path):
        return str(x)
    if isinstance(x, np.ndarray):
        return _json_safe(x.tolist())
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        v = float(x)
        return v if math.isfinite(v) else None
    if isinstance(x, dict):
        return {str(k): _json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_json_safe(v) for v in x]
    if hasattr(x, "__dataclass_fields__"):
        return _json_safe(asdict(x))
    return str(x)


def make_session_args(base_args: argparse.Namespace, meta: Dict[str, Any]) -> argparse.Namespace:
    args = copy.copy(base_args)
    params = meta.get("params") or {}
    if not isinstance(params, dict):
        params = {}
    for k, v in params.items():
        kk = str(k).replace("-", "_")
        if kk in OVERRIDABLE_FIELDS and hasattr(args, kk):
            current = getattr(args, kk)
            if isinstance(current, bool):
                setattr(args, kk, bool(v))
            elif isinstance(current, int) and not isinstance(current, bool):
                setattr(args, kk, int(v))
            elif isinstance(current, float):
                setattr(args, kk, float(v))
            else:
                setattr(args, kk, v)
    return args


def _confirm(
    obs: List[FrameObs],
    fps: float,
    height: int,
    width: int,
    state: Dict[str, object],
    args: argparse.Namespace,
    *,
    final: bool = False,
) -> Optional[Event]:
    if len(obs) < frames(float(_cfg(args, "online_warmup_sec", DEFAULT_ONLINE_WARMUP_SEC)), fps, 12):
        return None

    detect_args = copy.copy(args)
    if not final and not bool(getattr(args, "allow_blur_fallback_early", False)):
        setattr(detect_args, "disable_blur_fallback", True)
    setattr(detect_args, "return_all_events", False)

    events, _, _, _ = detect_events(obs, fps, height, width=width, detail=False, args=detect_args)
    if not events:
        state.clear()
        return None

    e = events[0]
    if final:
        return e

    # minimum=0: latency is controlled by --online-wait-sec only.
    wait_frames = frames(float(_cfg(args, "online_wait_sec", DEFAULT_ONLINE_WAIT_SEC)), fps, 0)
    if len(obs) - 1 - e.frame_idx < wait_frames:
        return None

    if state.get("kind") == e.kind and abs(int(state.get("frame_idx", -9999)) - e.frame_idx) <= 2:
        state["count"] = int(state.get("count", 1)) + 1
    else:
        state.update(kind=e.kind, frame_idx=e.frame_idx, count=1)

    return e if int(state["count"]) >= int(_cfg(args, "stable_chunks", DEFAULT_STABLE_CHUNKS)) else None


def iter_session_frames(sock: socket.socket, first_meta: Dict[str, Any], first_frame: np.ndarray):
    """Yield frames for one session. A session ends only when a packet has is_last=1 or the socket closes."""
    yield first_frame
    if bool(first_meta.get("is_last", False)):
        return
    while True:
        meta, frame = recv_frame_packet(sock)
        yield frame
        if bool(meta.get("is_last", False)):
            return


def drain_available_frame_packets(sock: socket.socket, max_sec: float = 0.20) -> int:
    """Discard residual frame packets already sent before the client received the result."""
    old_timeout = sock.gettimeout()
    deadline = time.time() + float(max_sec)
    dropped = 0
    try:
        sock.settimeout(0.02)
        while time.time() < deadline:
            try:
                recv_frame_packet(sock)
                dropped += 1
            except socket.timeout:
                break
            except EOFError:
                break
            except Exception:
                break
    finally:
        try:
            sock.settimeout(old_timeout)
        except Exception:
            pass
    return dropped


def process_frames_online(
    frame_iter: Iterable[np.ndarray],
    *,
    fps: float,
    ball_model: YOLO,
    pose_model: YOLO,
    args: argparse.Namespace,
    source_name: str,
    debug_writer: Optional[DebugJsonlWriter] = None,
) -> VideoResult:
    fps = float(fps or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = 25.0

    chunk = max(1, int(args.online_chunk))
    obs: List[FrameObs] = []
    track = new_track()
    state: Dict[str, object] = {}
    ball_t = pose_t = logic_t = 0.0
    early = False
    t0 = time.time()
    w = h = 0
    batch: List[np.ndarray] = []
    debug_full_session = bool(getattr(args, "debug_full_session", False))

    def flush_batch(final_flush: bool = False) -> bool:
        nonlocal batch, w, h, ball_t, pose_t, logic_t, early
        if not batch:
            return False
        if w <= 0 or h <= 0:
            h, w = batch[0].shape[:2]

        tb = time.time()
        br = predict_batch(ball_model, batch, imgsz=args.ball_imgsz, conf=args.ball_conf, args=args)
        tp = time.time()
        pr = predict_batch(pose_model, batch, imgsz=args.pose_imgsz, conf=args.person_conf, args=args)
        te = time.time()
        ball_t += tp - tb
        pose_t += te - tp

        start_idx = len(obs)
        append_observations(obs, br, pr, ball_model, fps, w, h, track, args)
        if debug_writer is not None:
            for o in obs[start_idx:]:
                debug_writer.write(obs_to_debug_row(o))
        batch = []

        tl = time.time()
        would_event = _confirm(obs, fps, h, w, state, args, final=False)
        early = False if debug_full_session else (would_event is not None)

        if debug_writer is not None and bool(getattr(args, "debug_decision", False)):
            try:
                dbg_args = copy.copy(args)
                if not bool(getattr(args, "allow_blur_fallback_early", False)):
                    setattr(dbg_args, "disable_blur_fallback", True)
                setattr(dbg_args, "return_all_events", False)
                setattr(dbg_args, "debug_decision", True)
                dbg_events, _, _, dbg_stats = detect_events(obs, fps, h, width=w, detail=False, args=dbg_args)
                debug_writer.write({
                    "type": "decision",
                    "prefix_frames": len(obs),
                    "final_flush": bool(final_flush),
                    "debug_full_session": bool(debug_full_session),
                    "would_early_stop": bool(would_event is not None),
                    "stable_state": dict(state),
                    "candidate_event": event_to_dict(dbg_events[0]) if dbg_events else None,
                    "candidate_debug_top": dbg_stats.get("candidate_debug_top", []),
                })
            except Exception as exc:
                debug_writer.write({"type": "decision_error", "prefix_frames": len(obs), "error": str(exc)})
        logic_t += time.time() - tl
        return early

    for frame in frame_iter:
        if w <= 0 or h <= 0:
            h, w = frame.shape[:2]
        batch.append(frame)
        if len(batch) >= chunk and flush_batch(False):
            break

    if not early:
        flush_batch(True)

    tl = time.time()
    final_args = copy.copy(args)
    setattr(final_args, "return_all_events", False)
    if bool(getattr(args, "debug_detections", False)):
        setattr(final_args, "debug_decision", True)
    events, arr, rows, stats = detect_events(obs, fps, h, width=w, detail=False, args=final_args)
    logic_t += time.time() - tl

    stats = dict(stats)
    stats["decision_policy"] = "tcp_frame_packet_online_stable_prefix_" + stats.get("decision_policy", "")
    stats["online_warmup_sec"] = float(_cfg(args, "online_warmup_sec", DEFAULT_ONLINE_WARMUP_SEC))
    stats["online_wait_sec"] = float(_cfg(args, "online_wait_sec", DEFAULT_ONLINE_WAIT_SEC))
    stats["stable_chunks"] = int(_cfg(args, "stable_chunks", DEFAULT_STABLE_CHUNKS))
    stats["source"] = str(source_name)

    return make_result(
        video=Path(str(source_name or "tcp_frame_stream")),
        fps=fps,
        width=w,
        height=h,
        frame_count=0,
        mode="online_tcp_frame_packet",
        early_stopped=early,
        observations=obs,
        events=events,
        arrays=arr,
        detail_rows=rows,
        stats=stats,
        timings={"ball_sec": ball_t, "pose_sec": pose_t, "logic_sec": logic_t, "total_sec": time.time() - t0},
    )


def build_result_packet(session_id: str, source: str, result: VideoResult, status: str) -> Dict[str, Any]:
    event = best_event(result)
    packet: Dict[str, Any] = {
        "session_id": session_id,
        "status": status,
        "event": "kick_detected" if event else "no_event",
        "source": source,
        "mode": result.mode,
        "early_stopped": bool(result.early_stopped),
        "processed_frames": int(result.processed_frames),
        "video": {"fps": _finite_float(result.fps, 0.0), "width": int(result.width or 0), "height": int(result.height or 0)},
        "timings": result.timings,
        "stats": result.stats,
        "kicks": [event_to_dict(e) for e in (result.events or [])],
    }
    if event is None:
        packet["kick"] = None
        return _json_safe(packet)

    idx = int(event.frame_idx)
    obs = result.observations[idx] if 0 <= idx < len(result.observations) else None
    arr = result.arrays or {}

    center = None
    if obs is not None and obs.ball_center_raw is not None:
        center = [float(obs.ball_center_raw[0]), float(obs.ball_center_raw[1])]
    elif "centers" in arr and idx < len(arr["centers"]):
        center = [float(arr["centers"][idx][0]), float(arr["centers"][idx][1])]

    foot_xy = None
    foot_label = event.nearest_foot_label
    if "foot_xy" in arr and idx < len(arr["foot_xy"]):
        fx, fy = arr["foot_xy"][idx]
        if np.isfinite(fx) and np.isfinite(fy):
            foot_xy = [float(fx), float(fy)]
    if "foot_label" in arr and idx < len(arr["foot_label"]):
        foot_label = str(arr["foot_label"][idx])

    kick_point = [(center[0] + foot_xy[0]) * 0.5, (center[1] + foot_xy[1]) * 0.5] if center and foot_xy else center
    packet["kick"] = {
        "frame_idx": int(event.frame_idx),
        "frame_id": int(event.frame_id),
        "time_sec": _finite_float(event.time_sec, 0.0),
        "timestamp_ms": int(round(float(event.time_sec) * 1000.0)),
        "kind": event.kind,
        "confidence": _finite_float(event.confidence, 0.0),
        "evidence": event.evidence,
        "dist_norm": _finite_float(event.dist_norm),
        "min_foot_dist_px": _finite_float(event.min_foot_dist),
        "motion_hps": _finite_float(event.motion_hps),
        "motion_gate": _finite_float(event.motion_gate),
        "progress_px": _finite_float(event.progress_px),
        "ball": {
            "center_px": center,
            "bbox_xyxy": list(obs.ball_box) if obs is not None and obs.ball_box is not None else None,
            "conf": _finite_float(obs.ball_conf, 0.0) if obs is not None else None,
            "class": obs.ball_class if obs is not None else "",
        },
        "foot": {"point_px": foot_xy, "label": foot_label, "dist_px": _finite_float(event.min_foot_dist)},
        "kick_point": {"px": kick_point, "definition": "midpoint_between_ball_center_and_nearest_foot_when_available_else_ball_center"},
        "event_raw": event_to_dict(event),
    }
    return _json_safe(packet)


def warmup_model(model: YOLO, *, imgsz: int, conf: float, args: argparse.Namespace, name: str) -> None:
    dummy = np.zeros((int(imgsz), int(imgsz), 3), dtype=np.uint8)
    print(f"[TCP SERVICE] warmup {name}: imgsz={imgsz}", flush=True)
    predict_batch(model, [dummy], imgsz=int(imgsz), conf=float(conf), args=args)
    print(f"[TCP SERVICE] warmup {name} done", flush=True)


class KickTCPServer:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.model_lock = threading.Lock()
        self.stop_event = threading.Event()

        print(f"[TCP SERVICE] loading ball model: {args.ball_model}", flush=True)
        self.ball_model = YOLO(args.ball_model, task="detect")
        print(f"[TCP SERVICE] loading pose model: {args.pose_model}", flush=True)
        self.pose_model = YOLO(args.pose_model, task="pose")

        warmup_model(self.ball_model, imgsz=args.ball_imgsz, conf=args.ball_conf, args=args, name="ball")
        warmup_model(self.pose_model, imgsz=args.pose_imgsz, conf=args.person_conf, args=args, name="pose")
        print("[TCP SERVICE] models loaded and warmed up; ready", flush=True)

    def handle_client(self, conn: socket.socket, addr: Tuple[str, int]) -> None:
        print(f"[TCP SERVICE] client connected from={addr}", flush=True)
        try:
            conn.settimeout(None)
            while not self.stop_event.is_set():
                session_id = make_session_id()
                source = "tcp_frame_stream"
                debug_writer = None
                try:
                    first_meta, first_frame = recv_frame_packet(conn)
                    session_id = str(first_meta.get("session_id") or session_id)
                    source = str(first_meta.get("source") or source)
                    fps = float(first_meta.get("fps") or 25.0)
                    session_args = make_session_args(self.args, first_meta)

                    print(f"[TCP SERVICE] session={session_id} source={source} fps={fps:.3f}", flush=True)

                    active_timeout = float(self.args.socket_timeout or 0.0)
                    conn.settimeout(active_timeout if active_timeout > 0 else None)

                    if bool(getattr(session_args, "debug_detections", False)):
                        debug_dir = Path(str(getattr(session_args, "debug_log_dir", "debug_runs")))
                        debug_path = debug_dir / f"det_{session_id}.jsonl"
                        debug_writer = DebugJsonlWriter(debug_path)
                        debug_writer.write({
                            "type": "start",
                            "session_id": session_id,
                            "source": source,
                            "fps": fps,
                            "protocol": "single frame packet: JSON header + JPEG image",
                        })
                        print(f"[TCP SERVICE][DEBUG] write detections: {debug_path}", flush=True)

                    with self.model_lock:
                        result = process_frames_online(
                            iter_session_frames(conn, first_meta, first_frame),
                            fps=fps,
                            ball_model=self.ball_model,
                            pose_model=self.pose_model,
                            args=session_args,
                            source_name=source,
                            debug_writer=debug_writer,
                        )

                    event = best_event(result)
                    status = "detected" if event is not None else "no_event"
                    packet = build_result_packet(session_id, source, result, status)
                    if debug_writer is not None:
                        debug_writer.write({"type": "result", "result": packet})
                        debug_writer.close()
                    send_json(conn, packet)
                    dropped = drain_available_frame_packets(conn) if result.early_stopped else 0
                    print(
                        f"[TCP SERVICE] result session={session_id} status={status} "
                        f"processed={result.processed_frames} early={result.early_stopped} dropped_after_result={dropped}",
                        flush=True,
                    )
                    conn.settimeout(None)

                except EOFError:
                    print(f"[TCP SERVICE] client disconnected from={addr}", flush=True)
                    break
                except Exception as exc:
                    if debug_writer is not None:
                        try:
                            debug_writer.write({"type": "error", "error": str(exc)})
                            debug_writer.close()
                        except Exception:
                            pass
                    err = {"session_id": session_id, "status": "error", "event": "error", "source": source, "error": str(exc), "traceback": traceback.format_exc(limit=20)}
                    try:
                        send_json(conn, err)
                    except Exception:
                        pass
                    print(f"[TCP SERVICE] error session={session_id}: {exc}", flush=True)
                    conn.settimeout(None)
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def serve_forever(self) -> None:
        host = str(self.args.tcp_host)
        port = int(self.args.tcp_port)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            s.listen(int(self.args.backlog))
            s.settimeout(0.5)
            print(f"[TCP SERVICE] listening on tcp://{host}:{port}", flush=True)
            print("[TCP SERVICE] protocol: one frame packet = JSON header + JPEG image", flush=True)
            while not self.stop_event.is_set():
                try:
                    conn, addr = s.accept()
                except socket.timeout:
                    continue
                self.handle_client(conn, addr)


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("TCP push-frame kick-contact detector")

    p.add_argument("--tcp-host", default="0.0.0.0")
    p.add_argument("--tcp-port", type=int, default=19090)
    p.add_argument("--backlog", type=int, default=16)
    p.add_argument("--socket-timeout", type=float, default=0.0, help="active receive timeout in seconds; <=0 means no timeout")

    p.add_argument("--ball-model", default="yolo11s.pt")
    p.add_argument("--pose-model", default="yolo11m-pose.pt")
    p.add_argument("--device", default="0")
    p.add_argument("--half", action="store_true", help="use FP16 on CUDA/TensorRT; ignored on CPU")
    p.add_argument("--batch", type=int, default=4)
    p.add_argument("--online-chunk", type=int, default=4)
    p.add_argument("--pad-last-batch", action="store_true", default=True)
    p.add_argument("--no-pad-last-batch", dest="pad_last_batch", action="store_false")
    p.add_argument("--ball-imgsz", type=int, default=640)
    p.add_argument("--pose-imgsz", type=int, default=640)
    p.add_argument("--ball-conf", type=float, default=0.16)
    p.add_argument("--person-conf", type=float, default=0.20)
    p.add_argument("--pose-conf", type=float, default=0.18)

    p.add_argument("--yolo-iou", type=float, default=0.50)
    p.add_argument("--ball-class-names", default="sports ball,ball,football,soccer ball,volleyball")
    p.add_argument("--max-ball-candidates", type=int, default=8)
    p.add_argument("--hand-conf", type=float, default=0.20)
    p.add_argument("--contact-percentile", type=float, default=35.0)
    p.add_argument("--motion-percentile", type=float, default=85.0)
    p.add_argument("--direction-cos-thresh", type=float, default=0.15)
    p.add_argument("--motion-window-sec", type=float, default=0.24)
    p.add_argument("--min-visible-steps", type=int, default=2)
    p.add_argument("--min-ball-move-px", type=float, default=35.0)
    p.add_argument("--min-ball-move-ratio", type=float, default=0.03)
    p.add_argument("--ball-move-lookahead-sec", type=float, default=0.20)
    p.add_argument("--ball-move-contact-gate", type=float, default=1.50)
    p.add_argument("--min-ball-speed-pxpf", type=float, default=0.0)
    p.add_argument("--foot-ball-same-dir-cos", type=float, default=0.35)
    p.add_argument("--min-foot-move-px", type=float, default=15.0)
    p.add_argument("--strong-ball-move-mult", type=float, default=2.0)
    p.add_argument("--ball-speed-lookback", type=int, default=3)
    p.add_argument("--ball-speed-jump-ratio", type=float, default=1.6)
    p.add_argument("--min-event-gap-sec", type=float, default=1.20)
    p.add_argument("--event-search-start-sec", type=float, default=0.80)
    p.add_argument("--contact-support-dist-norm", type=float, default=2.25)
    p.add_argument("--ball-gap-lookback", type=int, default=3)
    p.add_argument("--return-all-events", action="store_true")
    p.add_argument("--allow-blur-fallback-early", action="store_true")
    p.add_argument("--debug-detections", action="store_true")
    p.add_argument("--debyg", dest="debug_detections", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--debug-log-dir", default="debug_runs")
    p.add_argument("--debug-full-session", action="store_true")
    p.add_argument("--debug-decision", action="store_true")
    p.add_argument("--debug-candidate-limit", type=int, default=20)
    p.add_argument("--loss-reappear-sec", type=float, default=0.70)
    p.add_argument("--online-warmup-sec", type=float, default=0.80)
    p.add_argument("--online-wait-sec", type=float, default=0.12)
    p.add_argument("--stable-chunks", type=int, default=1)
    return p


def main() -> None:
    args = build_argparser().parse_args()
    server = KickTCPServer(args)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[TCP SERVICE] stopping", flush=True)
        server.stop_event.set()


if __name__ == "__main__":
    main()
