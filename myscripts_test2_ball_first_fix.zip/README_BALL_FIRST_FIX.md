# Ball-first kick trigger fix

This version keeps the existing TCP/service/debug code and changes only the event trigger priority.

## Why this fix was added

For close camera scenes, the ball is usually visible. The core evidence should be ball movement, not foot movement.
The previous rule still relied heavily on relative foot-ball motion and multi-step visible motion. If a foot moved very fast, the relative-motion threshold could become too high, and real kicks where the ball jumps in 1-2 frames could be missed.

## New logic

For each contact run, the detector now tries this order:

1. `ball_motion`: ball-first trigger.
   - a foot is close to the ball;
   - the ball center moves by at least `max(min_ball_move_px, min_ball_move_ratio * image_width)`;
   - the movement occurs within `ball_move_lookahead_sec` seconds;
   - the movement direction is roughly away from the foot.

2. `direct_motion`: original visible continuous motion rule.
3. `blur_loss`: original loss-and-reappear fallback.

## New adjustable parameters

In `service_kick_detector_tcp_win.ps1`:

```powershell
$MIN_BALL_MOVE_PX = "35"
$MIN_BALL_MOVE_RATIO = "0.03"
$BALL_MOVE_LOOKAHEAD_SEC = "0.20"
$BALL_MOVE_CONTACT_GATE = "1.50"
```

Recommended starting values for 1280x720 close camera:

```powershell
$MIN_BALL_MOVE_PX = "35"
$MIN_BALL_MOVE_RATIO = "0.03"
$BALL_MOVE_LOOKAHEAD_SEC = "0.20"
$BALL_MOVE_CONTACT_GATE = "1.50"
```

If false positives still appear, increase `MIN_BALL_MOVE_PX` or `MIN_BALL_MOVE_RATIO`.
If true kicks are missed, reduce `MIN_BALL_MOVE_RATIO` to `0.02`, or increase `BALL_MOVE_LOOKAHEAD_SEC` to `0.30`.

## Note

The detector still returns the first physically valid kick event in one start-end session. For the normal app/demo workflow, the sender stops after the first result and starts a new session when continuing playback.
