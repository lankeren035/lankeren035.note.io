# TCP JPEG 推帧检测协议（精简版）

本项目采用 **TCP 长连接 + 长度前缀包 + JPEG 单帧推送**。发送方不传 MP4 文件，不使用 RTSP/WebRTC/ffmpeg；发送方把视频逐帧读出、JPEG 编码后发给检测端。

检测端常驻启动，启动时加载并 warmup TensorRT/YOLO 模型。每次发送方发 `start` 后，检测端开始本轮 online 检测；检测到踢球帧后返回结果 JSON，但连接不断开，继续等待下一次 `start`。

---

## 1. 统一包格式

所有包都使用：

```text
[4 bytes payload_length][payload bytes]
```

- `payload_length`：uint32 big-endian。
- `payload_length == 0`：表示本轮视频结束，相当于 `end`。
- `payload bytes` 可以是 JSON，也可以是 FRM1 JPEG 帧包。

Python 发送函数：

```python
import struct

def send_packet(sock, payload: bytes):
    sock.sendall(struct.pack("!I", len(payload)) + payload)
```

Python 接收函数：

```python
import struct

def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        b = sock.recv(n - len(buf))
        if not b:
            raise EOFError("socket closed")
        buf.extend(b)
    return bytes(buf)

def recv_packet(sock):
    raw_len = recv_exact(sock, 4)
    n = struct.unpack("!I", raw_len)[0]
    if n == 0:
        return None
    return recv_exact(sock, n)
```

---

## 2. 发送方需要发送的包

一轮检测只需要三类包：

```text
start JSON 包
多个 FRM1 JPEG 帧包
stop/end 包
```

顺序：

```text
connect 检测端
  -> send start JSON
  -> send frame packet 0
  -> send frame packet 1
  -> ...
  -> 收到检测端 result JSON 后停止发送
  -> send stop JSON 或长度为 0 的 end 包
  -> 连接保持，等待下一轮 start
```

---

## 3. start JSON 包

最小推荐格式：

```json
{"type":"start","session_id":"abc123","source":"camera01","fps":30.0}
```

字段说明：

| 字段 | 必需 | 含义 |
|---|---|---|
| `type` | 是 | 固定为 `start` |
| `session_id` | 建议 | 本轮检测 ID，检测端会原样返回 |
| `source` | 建议 | 视频名、摄像头 ID 或业务片段 ID |
| `fps` | 强烈建议 | 发送端视频帧率；没有逐帧 timestamp 时用于估算时间 |

可选字段：

| 字段 | 含义 |
|---|---|
| `max_seconds` | 大于 0 时限制本轮最多检测秒数；0 或不传表示不限制 |
| `max_frames` | 大于 0 时限制本轮最多检测帧数；0 或不传表示不限制 |
| `params` | 临时覆盖检测参数；一般不用 |

发送代码：

```python
import json, uuid

def send_start(sock, source: str, fps: float):
    msg = {
        "type": "start",
        "session_id": uuid.uuid4().hex[:12],
        "source": source,
        "fps": float(fps),
    }
    send_packet(sock, json.dumps(msg, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
```

---

## 4. 视频帧怎么打包

每帧是一个 FRM1 包：

```text
FRM1 + [4 bytes header_length] + [header_json] + [jpeg_bytes]
```

header 精简为两个字段：

```json
{"frame_idx":102,"timestamp_ms":3400}
```

字段说明：

| 字段 | 含义 |
|---|---|
| `frame_idx` | 发送端视频中的 0-based 帧序号 |
| `timestamp_ms` | 发送端该帧对应的时间戳，单位毫秒 |

注意：

- 不再传 `frame_id`，需要时对方自己用 `frame_idx + 1`。
- 不再传 `timestamp_sec`，需要时对方自己用 `timestamp_ms / 1000.0`。
- 不再传 `image_format`，FRM1 后面的图像默认就是 JPEG。

从 MP4 到发送 payload：

```python
import cv2, json, struct

FRAME_MAGIC = b"FRM1"

def encode_frame_packet(frame, frame_idx: int, timestamp_ms: int, jpeg_quality: int = 85) -> bytes:
    # frame 是 cv2.VideoCapture.read() 得到的 BGR uint8 图像
    ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
    if not ok:
        raise RuntimeError("jpeg encode failed")

    header = {"frame_idx": int(frame_idx), "timestamp_ms": int(timestamp_ms)}
    raw_header = json.dumps(header, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

    return FRAME_MAGIC + struct.pack("!I", len(raw_header)) + raw_header + enc.tobytes()
```

发送一个视频的核心逻辑：

```python
import cv2, time

def send_video_frames(sock, video_path: str, jpeg_quality: int = 85, realtime: bool = True):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")

    fps = float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    if fps <= 1e-6 or fps > 240:
        fps = 25.0

    delay = 1.0 / fps if realtime else 0.0
    frame_idx = 0

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        pos_ms = float(cap.get(cv2.CAP_PROP_POS_MSEC) or 0.0)
        if pos_ms <= 0:
            pos_ms = frame_idx * 1000.0 / fps
        timestamp_ms = int(round(pos_ms))

        payload = encode_frame_packet(frame, frame_idx, timestamp_ms, jpeg_quality)
        send_packet(sock, payload)

        frame_idx += 1
        if delay > 0:
            time.sleep(delay)

    cap.release()
```

---

## 5. stop/end 包

手动暂停、关闭视频、本轮结束时发送 stop：

```json
{"type":"stop"}
```

代码：

```python
def send_stop(sock):
    send_packet(sock, b'{"type":"stop"}')
```

也支持发送空包作为 end：

```python
def send_end(sock):
    send_packet(sock, b"")
```

---

## 6. 检测端如何接收帧

检测端收到 payload 后：

1. 如果是 JSON，按 `type` 处理 `start/stop/close`。
2. 如果以 `FRM1` 开头，解析 frame header 和 JPEG bytes。
3. JPEG bytes 用 `cv2.imdecode` 解成 OpenCV BGR 帧。
4. 送入检测模型。

核心接收解码代码：

```python
import cv2, json, struct
import numpy as np

FRAME_MAGIC = b"FRM1"

def decode_frame_packet(payload: bytes):
    if payload.startswith(FRAME_MAGIC):
        header_len = struct.unpack("!I", payload[4:8])[0]
        header_start = 8
        header_end = header_start + header_len
        header = json.loads(payload[header_start:header_end].decode("utf-8"))
        jpeg_bytes = payload[header_end:]
    else:
        # 兼容旧版：payload 直接是 JPEG bytes
        header = {}
        jpeg_bytes = payload

    arr = np.frombuffer(jpeg_bytes, dtype=np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return frame, header
```

---

## 7. 检测端返回结果

检测端返回一个精简 JSON 包，仍然是：

```text
[4 bytes length][result JSON bytes]
```

检测成功示例：

```json
{
  "session_id": "abc123",
  "status": "detected",
  "event": "kick_detected",
  "source": "camera01",
  "processed_frames": 144,
  "kick": {
    "frame_idx": 102,
    "timestamp_ms": 3400,
    "confidence": 0.972,
    "kind": "blur_loss",
    "ball": {
      "center_px": [399.6, 305.0],
      "bbox_xyxy": [380.0, 290.0, 420.0, 330.0],
      "conf": 0.31
    },
    "foot": {
      "point_px": [295.2, 359.0],
      "label": "p0_right_toe"
    },
    "kick_point": {
      "px": [347.4, 332.0]
    }
  }
}
```

无事件示例：

```json
{
  "session_id": "abc123",
  "status": "no_event",
  "event": "no_event",
  "source": "camera01",
  "processed_frames": 300,
  "kick": null
}
```

发送方解析：

```python
import json, struct

def recv_result(sock):
    raw_len = recv_exact(sock, 4)
    n = struct.unpack("!I", raw_len)[0]
    raw = recv_exact(sock, n)
    return json.loads(raw.decode("utf-8"))
```

对接方重点使用：

```text
kick.frame_idx
kick.timestamp_ms
kick.ball.center_px
kick.ball.bbox_xyxy
kick.foot.point_px
kick.kick_point.px
```

---

## 8. 最小发送端示例

```python
import socket

with socket.create_connection(("127.0.0.1", 19090)) as sock:
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    send_start(sock, source="1.mp4", fps=30.0)
    send_video_frames(sock, "D:/football/videos/1.mp4", jpeg_quality=85, realtime=True)
    send_end(sock)

    result = recv_result(sock)
    print(result)
```

真实业务端建议边发送边监听结果；一旦收到 `status=detected`，立即停止本轮发送并发送 `stop/end`。

---

## 9. 推荐参数

```text
分辨率：960x540 或 1280x720
JPEG_QUALITY：80~85
帧率：25~30fps
连接：TCP 长连接
start：每次开始检测前发送
stop/end：暂停、关闭、检测结果返回后发送
```
