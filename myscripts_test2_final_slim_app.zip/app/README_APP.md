# App 可视化发送端

启动检测服务后，运行：

```bat
app\run_app_win.bat
```

使用流程：

1. 点击 `Open Video` 选择视频。选择后不会自动播放。
2. 点击 `Play / Continue` 后：
   - 发送 start 包；
   - 视频正常播放；
   - App 逐帧把当前帧 JPEG 编码，并发送 FRM1 帧包。
3. 检测端返回结果后：
   - App 停止本轮发送；
   - 发送 stop 包；
   - 视频暂停在当前位置；
   - 状态栏提示已收到结果。
4. 点击 `Show Result`：
   - 跳到返回的目标帧；
   - 画出球框、球心、最近脚点、踢球点；
   - 显示 frame_idx、timestamp_ms、confidence、kind。
5. 点击 `Play / Continue` 可从当前帧继续播放并开始下一轮检测。
6. 点击 `Pause` 或 `Close Video` 会发送 stop 包。

App 使用的协议与根目录 `README_TCP_JPEG_FINAL_PROTOCOL.md` 一致。
