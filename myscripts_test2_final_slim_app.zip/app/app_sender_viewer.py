#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GUI sender for the TCP JPEG kick detector.

行为：
- 选择视频后不自动播放；
- 点击 Play / Continue：发送 start 包，视频正常播放，同时逐帧发送 FRM1+JPEG 帧包；
- 检测端返回结果：停止本轮发送，但不自动跳帧；
- 点击 Show Result：跳到目标帧，并画出球框、球心、脚点、踢球点和关键信息；
- 手动 Pause / Close Video / Open new video：发送 stop 包；
- 再次点击 Play / Continue：从当前帧继续播放，并发送新的 start 包开始下一轮检测。
"""
from __future__ import annotations

import argparse
import json
import select
import socket
import struct
from pathlib import Path
from typing import Dict, Optional
from uuid import uuid4

import cv2
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import filedialog, messagebox

MAX_PACKET_BYTES = 64 * 1024 * 1024
FRAME_MAGIC = b"FRM1"


def send_packet(sock: socket.socket, payload: bytes) -> None:
    if len(payload) > MAX_PACKET_BYTES:
        raise ValueError(f"packet too large: {len(payload)} bytes")
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def send_json(sock: socket.socket, data: Dict) -> None:
    send_packet(sock, json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def encode_frame_packet(frame, *, frame_idx: int, timestamp_ms: int, jpeg_quality: int) -> bytes:
    ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
    if not ok:
        raise RuntimeError("cv2.imencode(.jpg) failed")
    header = {"frame_idx": int(frame_idx), "timestamp_ms": int(timestamp_ms)}
    raw_header = json.dumps(header, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return FRAME_MAGIC + struct.pack("!I", len(raw_header)) + raw_header + enc.tobytes()


class ResultReader:
    def __init__(self):
        self.buf = bytearray()
        self.need: Optional[int] = None

    def reset(self):
        self.buf.clear()
        self.need = None

    def try_recv(self, sock: socket.socket) -> Optional[Dict]:
        readable, _, _ = select.select([sock], [], [], 0)
        if not readable:
            return None
        b = sock.recv(65536)
        if not b:
            raise EOFError("detector closed socket")
        self.buf.extend(b)

        if self.need is None:
            if len(self.buf) < 4:
                return None
            self.need = struct.unpack("!I", bytes(self.buf[:4]))[0]
            del self.buf[:4]
            if self.need <= 0 or self.need > MAX_PACKET_BYTES:
                raise RuntimeError(f"invalid result packet length: {self.need}")

        if len(self.buf) < self.need:
            return None
        raw = bytes(self.buf[:self.need])
        del self.buf[:self.need]
        self.need = None
        return json.loads(raw.decode("utf-8", errors="replace"))


class SenderViewerApp:
    def __init__(self, root: tk.Tk, args):
        self.root = root
        self.args = args
        self.root.title("Kick Detector TCP JPEG Sender")

        self.sock: Optional[socket.socket] = None
        self.reader = ResultReader()
        self.cap: Optional[cv2.VideoCapture] = None
        self.video_path: Optional[Path] = None
        self.fps = 25.0
        self.total_frames = 0
        self.current_frame_idx = 0
        self.playing = False
        self.streaming = False
        self.session_id = ""
        self.last_result: Optional[Dict] = None
        self.photo = None

        self.video_label = tk.Label(root, text="Open a video, then click Play.", bg="black", fg="white", width=96, height=32)
        self.video_label.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        bar = tk.Frame(root)
        bar.pack(fill=tk.X, padx=8, pady=4)
        tk.Button(bar, text="Open Video", command=self.open_video).pack(side=tk.LEFT, padx=4)
        tk.Button(bar, text="Play / Continue", command=self.play).pack(side=tk.LEFT, padx=4)
        tk.Button(bar, text="Pause", command=self.pause).pack(side=tk.LEFT, padx=4)
        tk.Button(bar, text="Show Result", command=self.show_result).pack(side=tk.LEFT, padx=4)
        tk.Button(bar, text="Close Video", command=self.close_video).pack(side=tk.LEFT, padx=4)

        self.status = tk.StringVar(value=f"Detector: {args.host}:{args.port}")
        tk.Label(root, textvariable=self.status, anchor="w").pack(fill=tk.X, padx=8, pady=4)

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def connect(self):
        if self.sock is not None:
            return
        self.sock = socket.create_connection((self.args.host, int(self.args.port)), timeout=float(self.args.connect_timeout))
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.status.set(f"Connected: {self.args.host}:{self.args.port}")

    def send_stop(self, reason: str):
        if self.sock is None:
            return
        try:
            send_json(self.sock, {"type": "stop"})
        except Exception:
            pass
        self.streaming = False
        self.reader.reset()

    def open_video(self):
        path = filedialog.askopenfilename(
            title="Select video",
            filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv *.webm *.m4v"), ("All files", "*.*")],
        )
        if not path:
            return
        self.send_stop("open_new_video")
        self._release_cap()

        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            messagebox.showerror("Open failed", f"Cannot open video:\n{path}")
            return
        self.cap = cap
        self.video_path = Path(path)
        self.fps = float(cap.get(cv2.CAP_PROP_FPS) or self.args.fps or 25.0)
        if self.fps <= 1e-6 or self.fps > 240:
            self.fps = float(self.args.fps or 25.0)
        self.total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        self.current_frame_idx = 0
        self.playing = False
        self.streaming = False
        self.last_result = None
        self.show_frame_at(0)
        self.status.set(f"Loaded: {self.video_path.name}, fps={self.fps:.3f}, frames={self.total_frames}. Click Play.")

    def play(self):
        if self.cap is None or self.video_path is None:
            messagebox.showinfo("No video", "Open a video first.")
            return
        try:
            self.connect()
            self.session_id = uuid4().hex[:12]
            self.reader.reset()
            send_json(self.sock, {
                "type": "start",
                "session_id": self.session_id,
                "source": self.video_path.name,
                "fps": float(self.fps),
            })
            self.playing = True
            self.streaming = True
            self.status.set(f"Playing + streaming: {self.video_path.name}, session={self.session_id}")
            self.tick()
        except Exception as exc:
            messagebox.showerror("Play failed", str(exc))

    def pause(self):
        self.playing = False
        self.send_stop("manual_pause")
        self.status.set("Paused; stop packet sent.")

    def close_video(self):
        self.playing = False
        self.send_stop("close_video")
        self._release_cap()
        self.video_label.configure(image="", text="Video closed.")
        self.photo = None
        self.last_result = None
        self.status.set("Video closed; stop packet sent.")

    def _release_cap(self):
        if self.cap is not None:
            try:
                self.cap.release()
            except Exception:
                pass
        self.cap = None

    def show_frame_at(self, frame_idx: int, result: Optional[Dict] = None):
        if self.cap is None:
            return
        idx = max(0, int(frame_idx))
        if self.total_frames > 0:
            idx = min(idx, max(0, self.total_frames - 1))
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, frame = self.cap.read()
        if not ok:
            return
        if result is not None:
            frame = self.draw_result_overlay(frame, result)
        self.display_frame(frame)
        self.current_frame_idx = idx + 1

    def draw_result_overlay(self, frame, result: Dict):
        vis = frame.copy()
        kick = result.get("kick") or {}
        ball = kick.get("ball") or {}
        foot = kick.get("foot") or {}
        kp = kick.get("kick_point") or {}

        bbox = ball.get("bbox_xyxy")
        if bbox and len(bbox) == 4:
            x1, y1, x2, y2 = [int(round(float(v))) for v in bbox]
            cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), 2)

        center = ball.get("center_px")
        if center and len(center) >= 2:
            cx, cy = [int(round(float(v))) for v in center[:2]]
            cv2.circle(vis, (cx, cy), 5, (0, 255, 0), -1)
            cv2.putText(vis, "ball", (cx + 6, cy - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        foot_pt = foot.get("point_px")
        if foot_pt and len(foot_pt) >= 2:
            fx, fy = [int(round(float(v))) for v in foot_pt[:2]]
            cv2.circle(vis, (fx, fy), 5, (255, 0, 0), -1)
            cv2.putText(vis, str(foot.get("label") or "foot"), (fx + 6, fy - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

        kick_pt = kp.get("px")
        if kick_pt and len(kick_pt) >= 2:
            kx, ky = [int(round(float(v))) for v in kick_pt[:2]]
            cv2.circle(vis, (kx, ky), 7, (0, 0, 255), -1)
            cv2.putText(vis, "kick", (kx + 6, ky - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        info = [
            f"frame={kick.get('frame_idx')}",
            f"timestamp_ms={kick.get('timestamp_ms')}",
            f"conf={kick.get('confidence')}",
            f"kind={kick.get('kind')}",
        ]
        y = 28
        for line in info:
            cv2.putText(vis, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 4)
            cv2.putText(vis, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            y += 28
        return vis

    def show_result(self):
        if not self.last_result:
            messagebox.showinfo("No result", "No detection result has been received yet.")
            return
        kick = self.last_result.get("kick") or {}
        target = kick.get("frame_idx")
        if target is None:
            messagebox.showinfo("No event", "The last result has no kick event.")
            return
        self.playing = False
        self.streaming = False
        self.show_frame_at(int(target), result=self.last_result)
        self.status.set(f"Result shown: frame={target}, timestamp_ms={kick.get('timestamp_ms')}")

    def display_frame(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        max_w, max_h = 1280, 720
        scale = min(max_w / max(w, 1), max_h / max(h, 1), 1.0)
        if scale < 1.0:
            rgb = cv2.resize(rgb, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
        im = Image.fromarray(rgb)
        self.photo = ImageTk.PhotoImage(image=im)
        self.video_label.configure(image=self.photo, text="")

    def poll_result(self) -> Optional[Dict]:
        if self.sock is None:
            return None
        try:
            return self.reader.try_recv(self.sock)
        except Exception as exc:
            self.status.set(f"Receive error: {exc}")
            return None

    def is_current_result(self, result: Dict) -> bool:
        sid = str(result.get("session_id") or "")
        if sid and self.session_id and sid != self.session_id:
            print(f"[APP] ignore stale result: result_session={sid}, current_session={self.session_id}")
            return False
        return True

    def handle_result(self, result: Dict):
        if not self.is_current_result(result):
            return
        self.last_result = result
        self.playing = False
        self.streaming = False
        self.send_stop("result_received")

        kick = result.get("kick") or {}
        self.status.set(
            "Result received. Click Show Result. "
            f"frame={kick.get('frame_idx')}, timestamp_ms={kick.get('timestamp_ms')}, status={result.get('status')}"
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))

    def tick(self):
        if not self.playing or self.cap is None:
            return

        result = self.poll_result()
        if result is not None:
            if self.is_current_result(result):
                self.handle_result(result)
                return

        ok, frame = self.cap.read()
        if not ok:
            self.playing = False
            self.send_stop("video_ended")
            self.status.set("Video ended; stop packet sent.")
            return

        abs_idx = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES)) - 1
        if abs_idx < 0:
            abs_idx = self.current_frame_idx
        pos_ms = float(self.cap.get(cv2.CAP_PROP_POS_MSEC) or 0.0)
        if pos_ms <= 0:
            pos_ms = abs_idx * 1000.0 / max(self.fps, 1e-6)
        timestamp_ms = int(round(pos_ms))

        self.display_frame(frame)
        self.current_frame_idx = abs_idx + 1

        if self.streaming and self.sock is not None:
            try:
                payload = encode_frame_packet(
                    frame,
                    frame_idx=abs_idx,
                    timestamp_ms=timestamp_ms,
                    jpeg_quality=int(self.args.jpeg_quality),
                )
                send_packet(self.sock, payload)
            except Exception as exc:
                self.playing = False
                self.streaming = False
                self.status.set(f"Send error: {exc}")
                return

        result = self.poll_result()
        if result is not None:
            if self.is_current_result(result):
                self.handle_result(result)
                return

        delay_ms = max(1, int(round(1000.0 / max(self.fps, 1e-6))))
        self.root.after(delay_ms, self.tick)

    def on_close(self):
        self.playing = False
        self.send_stop("app_close")
        self._release_cap()
        if self.sock is not None:
            try:
                send_json(self.sock, {"type": "close"})
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        self.root.destroy()


def build_argparser():
    p = argparse.ArgumentParser("GUI TCP JPEG sender")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=19090)
    p.add_argument("--jpeg-quality", type=int, default=85)
    p.add_argument("--fps", type=float, default=25.0)
    p.add_argument("--connect-timeout", type=float, default=10.0)
    return p


def main():
    args = build_argparser().parse_args()
    root = tk.Tk()
    root.geometry("1100x760")
    SenderViewerApp(root, args)
    root.mainloop()


if __name__ == "__main__":
    main()
