$ErrorActionPreference = "Stop"

$SCRIPT_DIR = $PSScriptRoot
$PROJECT_ROOT = Split-Path -Parent $SCRIPT_DIR
$PYTHON = "D:\anaconda3\envs\football\python.exe"

$HOST_IP = "127.0.0.1"
$PORT = "19090"
$JPEG_QUALITY = "85"

cd $PROJECT_ROOT
$env:PYTHONPATH = "$PROJECT_ROOT;$SCRIPT_DIR;$env:PYTHONPATH"

& $PYTHON "$SCRIPT_DIR\app_sender_viewer.py" --host "$HOST_IP" --port "$PORT" --jpeg-quality "$JPEG_QUALITY"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
