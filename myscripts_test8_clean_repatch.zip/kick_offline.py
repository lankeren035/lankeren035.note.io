#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

# =============================================================================
# 踢球事件判断逻辑。
#
# 当前版本只保留两层逻辑：
#   1. visible_ball_speed 主逻辑：球突然大位移 + 球速度突增
#      + 脚与球同方向运动 + 脚大致在球附近。
#   2. loss_only_fallback：球在脚附近后突然长期丢失，用于处理高速踢出
#      导致球运动模糊、后续球框长期检测不到的情况。
#
# 已删除旧 blur_loss/direct_motion 逻辑及其重复参数体系：
# CONTACT_PERCENTILE / MOTION_PERCENTILE / DIRECTION_COS_THRESH /
# MOTION_WINDOW_SEC / MIN_VISIBLE_STEPS / BALL_MOVE_LOOKAHEAD_SEC /
# BALL_MOVE_CONTACT_GATE / STRONG_BALL_MOVE_MULT。
# =============================================================================
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from ultralytics import YOLO

from kick_common import (
    Event, FrameObs, VideoResult, append_observations, build_arrays,
    frames, make_result, new_track, predict_batch,
)


def _cfg(args, name: str, default):
    """读取可配置参数；兼容旧脚本未传新增字段的情况。"""
    return getattr(args, name, default)

# 以下是默认值。实际运行时可通过启动脚本 / argparse 覆盖。
DEFAULT_MIN_BALL_MOVE_PX = 35.0          # 球单步/累计大位移至少多少像素
DEFAULT_MIN_BALL_MOVE_RATIO = 0.03       # 球大位移至少达到图像宽度的比例
DEFAULT_MIN_BALL_SPEED_PXPF = 0.0        # 每帧球心位移硬门槛；0 表示复用 min_ball_move_px/ratio
DEFAULT_FOOT_BALL_SAME_DIR_COS = 0.35    # 脚位移和球位移同向的最低余弦
DEFAULT_MIN_FOOT_MOVE_PX = 15.0          # 脚部至少移动多少像素才作为同向证据
DEFAULT_BALL_SPEED_LOOKBACK = 3          # 判断速度突增时向前看几帧
DEFAULT_BALL_SPEED_JUMP_RATIO = 1.6      # 当前球速至少是前序中值速度的多少倍
DEFAULT_MIN_EVENT_GAP_SEC = 1.20         # 多次踢球之间的最小间隔
DEFAULT_EVENT_SEARCH_START_SEC = 0.80    # 忽略视频开头启动阶段，防止第一二帧检测框跳变误报
DEFAULT_CONTACT_SUPPORT_DIST_NORM = 3.2  # 脚踝点到球心距离上限，单位=球半径倍数
DEFAULT_BALL_GAP_LOOKBACK = 3            # 球中间漏检几帧时，允许用最近可见帧到当前帧的大位移作为主证据
DEFAULT_DEBUG_CANDIDATE_LIMIT = 20        # debug_decision 输出多少个候选/拒绝原因
DEFAULT_LOSS_REAPPEAR_SEC = 0.70         # loss fallback 长期丢球确认窗口
DEFAULT_ENABLE_LOSS_FALLBACK = 1         # 0/1：是否启用“球贴脚后突然长期丢失”的兜底
DEFAULT_LOSS_FALLBACK_APPROACH_LOOKBACK = 4  # loss fallback 检查丢球前几帧脚是否持续靠近球


# 创建 Event 对象。
# idx 传入 0-based 帧号，输出里同时保存 1-based frame_id，便于和标注答案对齐。
def _event(idx: int, kind: str, conf: float, evidence: str, obs: List[FrameObs],
           arr: Dict[str, np.ndarray], gate: float, progress: float) -> Event:
    idx = int(np.clip(idx, 0, len(obs) - 1))
    dn, fd = arr["dist_norm"][idx], arr["foot_dist"][idx]
    return Event(0, idx, idx + 1, float(obs[idx].time_sec), kind, float(np.clip(conf, 0, 1)),
                 float(dn) if np.isfinite(dn) else float("inf"),
                 float(fd) if np.isfinite(fd) else float("inf"),
                 float(gate), float(gate), float(progress), str(arr["foot_label"][idx]), evidence)




def _min_ball_move_px(arr: Dict[str, np.ndarray], args=None) -> float:
    """球必须真实移动的硬门槛：max(像素阈值, 图像宽度比例阈值)。"""
    px = max(0.0, float(_cfg(args, "min_ball_move_px", DEFAULT_MIN_BALL_MOVE_PX)))
    ratio = max(0.0, float(_cfg(args, "min_ball_move_ratio", DEFAULT_MIN_BALL_MOVE_RATIO)))
    frame_w = max(float(arr.get("frame_w", arr.get("frame_h", 1.0))), 1.0)
    return max(px, ratio * frame_w)


def _ball_move_ok(arr: Dict[str, np.ndarray], c: int, j: int, args=None) -> Tuple[bool, float, float]:
    """判断 c 到 j 的球心累计位移是否超过硬门槛。"""
    if c < 0 or j < 0 or c >= len(arr["valid"]) or j >= len(arr["valid"]):
        return False, 0.0, _min_ball_move_px(arr, args)
    if not (arr["valid"][c] and arr["valid"][j]):
        return False, 0.0, _min_ball_move_px(arr, args)
    dist = float(np.linalg.norm(arr["centers"][j] - arr["centers"][c]))
    gate = _min_ball_move_px(arr, args)
    return dist >= gate, dist, gate

def _ball_step_gate_px(arr: Dict[str, np.ndarray], args=None) -> float:
    """单帧球心位移门槛。默认复用 max(px, ratio*width)。"""
    base = _min_ball_move_px(arr, args)
    pxpf = max(0.0, float(_cfg(args, "min_ball_speed_pxpf", DEFAULT_MIN_BALL_SPEED_PXPF)))
    return max(base, pxpf)


def _ball_step_px(arr: Dict[str, np.ndarray], j: int) -> float:
    if j <= 0 or j >= len(arr["valid"]):
        return 0.0
    if not (arr["valid"][j] and arr["valid"][j - 1]):
        return 0.0
    return float(np.linalg.norm(arr["centers"][j] - arr["centers"][j - 1]))


def _prev_ball_step_median_px(arr: Dict[str, np.ndarray], j: int, args=None) -> float:
    """当前大位移之前的球速中值，用于判断突然加速。"""
    k = max(1, int(_cfg(args, "ball_speed_lookback", DEFAULT_BALL_SPEED_LOOKBACK)))
    vals = []
    for t in range(max(1, j - k), j):
        v = _ball_step_px(arr, t)
        if np.isfinite(v) and v > 0:
            vals.append(v)
    return float(np.median(vals)) if vals else 0.0


def _foot_same_direction_support(arr: Dict[str, np.ndarray], j: int, ball_move: np.ndarray, args=None) -> Tuple[bool, float, float, int, int]:
    """在 ball step j 之前/当前寻找脚部同向运动证据。

    j 表示球从 j-1 到 j 的运动。主逻辑必须符合：
      1) 球发生真实大位移；
      2) 在这次球大位移之前或同一瞬间，脚也朝同方向移动。

    这里故意不使用 j+1 之后的脚点，避免“球已经飞走以后人体跟随动作”倒推成触球证据。
    也不要求严格脚球距离，因为真实接触帧可能没被摄像头拍到。
    """
    n = len(arr["valid"])
    min_move = max(0.0, float(_cfg(args, "min_foot_move_px", DEFAULT_MIN_FOOT_MOVE_PX)))
    min_cos = float(_cfg(args, "foot_ball_same_dir_cos", DEFAULT_FOOT_BALL_SAME_DIR_COS))
    bm = np.asarray(ball_move, dtype=float)
    bn = float(np.linalg.norm(bm))
    if bn <= 1e-9:
        return False, 0.0, 0.0, -1, -1

    best = (False, -1.0, 0.0, -1, -1)
    # 脚可以提前几帧发力；但不能用球飞走后的未来帧来补证据。
    a0 = max(0, j - 4)
    b1 = min(n - 1, j)
    for a in range(a0, min(j + 1, n)):
        for b in range(max(a + 1, j - 3), b1 + 1):
            if a < 0 or b >= n or not (arr["foot_valid"][a] and arr["foot_valid"][b]):
                continue
            fm = arr["foot_xy"][b] - arr["foot_xy"][a]
            fn = float(np.linalg.norm(fm))
            if fn < min_move:
                continue
            cos = float(np.dot(fm, bm) / max(fn * bn, 1e-9))
            if cos > best[1]:
                best = (cos >= min_cos, cos, fn, a, b)
    return best

def _event_idx_for_ball_step(arr: Dict[str, np.ndarray], j: int) -> int:
    """高球速 step 对应的事件帧。

    j 是球从 j-1 到 j 的大位移。若两帧都有脚点，则选择脚球距离更近的那一帧；
    这能兼容“相机没有拍到正好触球帧，只拍到前后相邻帧”的情况。
    """
    if j <= 0:
        return 0
    a, b = j - 1, j
    da = arr["dist_norm"][a] if a < len(arr["dist_norm"]) else np.inf
    db = arr["dist_norm"][b] if b < len(arr["dist_norm"]) else np.inf
    if np.isfinite(da) and np.isfinite(db):
        return int(b if db < da else a)
    if np.isfinite(db):
        return int(b)
    return int(a)




def _event_search_start_frame(fps: float, args=None) -> int:
    sec = max(0.0, float(_cfg(args, "event_search_start_sec", DEFAULT_EVENT_SEARCH_START_SEC)))
    return frames(sec, fps, 0)


def _contact_support_for_event(arr: Dict[str, np.ndarray], event_idx: int, args=None) -> Tuple[bool, float, int, str]:
    """主判定的“附近有脚证据”门槛。

    这不是旧版的“先找 contact candidate”。主证据仍然是球的大位移。
    这里仅用于排除明显不可能的情况：球在画面另一边跳变，脚点缺失或距离过远。

    允许检查 event_idx 前后极短窗口，是为了兼容：
      - 球被踢后当前帧脚点稍有遮挡；
      - 正好接触那帧没有球框，但前/后一帧有球框。
    """
    n = len(arr["valid"])
    gate = float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM))
    best_dn = float("inf")
    best_i = -1
    best_label = ""
    # 只看 event 帧和它的前一帧，且该帧必须真实检测到球。
    # 不允许用插值球心 + 较早脚点来凑“接近”，否则视频4开头 73/74 的假跳变会误报。
    for t in range(max(0, int(event_idx) - 1), min(n, int(event_idx) + 1)):
        dn = float(arr["dist_norm"][t]) if t < n else float("inf")
        if not (arr["valid"][t] and arr["foot_valid"][t] and np.isfinite(dn)):
            continue
        if arr["hand_dist"][t] < arr["foot_dist"][t]:
            continue
        if dn < best_dn:
            best_dn = dn
            best_i = int(t)
            best_label = str(arr["foot_label"][t])
    return bool(best_i >= 0 and best_dn <= gate), best_dn, best_i, best_label


def _contact_support_for_static_ball(arr: Dict[str, np.ndarray], k: int, args=None) -> Tuple[bool, float, int, str]:
    """gap_reappear 专用接触支持。

    对于“球静止/近脚 -> 丢一两帧 -> 重现后已经飞远”的情况，
    接触距离不能在重现帧 j 判断；那时球已经离脚很远。
    正确做法是检查最后一个可见静止球帧 k 及其前 2 帧。
    """
    n = len(arr["valid"])
    gate = float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM))
    best_dn = float("inf")
    best_i = -1
    best_label = ""
    for t in range(max(0, int(k) - 2), min(n, int(k) + 1)):
        dn = float(arr["dist_norm"][t]) if t < n else float("inf")
        if not (arr["valid"][t] and arr["foot_valid"][t] and np.isfinite(dn)):
            continue
        if arr["hand_dist"][t] < arr["foot_dist"][t]:
            continue
        if dn < best_dn:
            best_dn = dn
            best_i = int(t)
            best_label = str(arr["foot_label"][t])
    return bool(best_i >= 0 and best_dn <= gate), best_dn, best_i, best_label


def _first_missing_after(arr: Dict[str, np.ndarray], k: int, j: int) -> int:
    """k 到 j 之间第一个丢球帧；没有则返回 j。"""
    for t in range(int(k) + 1, int(j) + 1):
        if t >= 0 and t < len(arr["valid"]) and not arr["valid"][t]:
            return int(t)
    return int(j)


def _prev_visible_index(arr: Dict[str, np.ndarray], j: int, max_gap: int) -> int:
    for k in range(j - 1, max(-1, j - max_gap - 1), -1):
        if k >= 0 and arr["valid"][k]:
            return int(k)
    return -1


def _ball_motion_candidates(arr: Dict[str, np.ndarray], fps: float, args=None):
    """按时间生成球大位移候选。

    同时覆盖两种主情况：
      1. consecutive: j-1 和 j 都有球框；
      2. gap_reappear: 中间漏检 1~N 帧，最近可见球框 k 到 j 发生大位移。
    """
    n = len(arr["valid"])
    step_gate = _ball_step_gate_px(arr, args)
    max_gap = max(1, int(_cfg(args, "ball_gap_lookback", DEFAULT_BALL_GAP_LOOKBACK)))
    for j in range(1, n):
        if not arr["valid"][j]:
            continue
        k = _prev_visible_index(arr, j, max_gap=max_gap)
        if k < 0:
            continue
        # 连续可见或短暂漏检后重现。k 可以等于 j-1，也可以小于 j-1。
        move = arr["centers"][j] - arr["centers"][k]
        move_px = float(np.linalg.norm(move))
        if move_px < step_gate:
            continue
        cand_kind = "consecutive" if k == j - 1 else "gap_reappear"
        # 如果短暂漏检后刚重现，下一帧又出现更明确的连续大位移，
        # 优先把事件落在下一帧。视频3就是这种：57有球、58漏检、59重现、60才是清晰飞出帧。
        if cand_kind == "gap_reappear" and j + 1 < n and arr["valid"][j + 1]:
            next_move_px = float(np.linalg.norm(arr["centers"][j + 1] - arr["centers"][j]))
            if next_move_px >= step_gate:
                continue
        yield int(k), int(j), move, move_px, step_gate, cand_kind


def _candidate_reject_reason(arr: Dict[str, np.ndarray], fps: float, args, k: int, j: int, move: np.ndarray, move_px: float, step_gate: float, cand_kind: str) -> Tuple[bool, str, Dict]:
    start_frame = _event_search_start_frame(fps, args)
    info = {
        "kind": cand_kind,
        "from_frame": int(k),
        "event_frame": int(j),
        "move_px": round(float(move_px), 3),
        "gate_px": round(float(step_gate), 3),
    }
    if j < start_frame:
        info["search_start_frame"] = int(start_frame)
        return False, "too_early_before_warmup", info

    # consecutive：在大位移当前帧附近看脚球距离。
    # gap_reappear：优先在重现帧看；如果球已经飞远，则回到最后一个静止可见球帧 k 附近看。
    contact_ok, best_dn, best_i, best_label = _contact_support_for_event(arr, j, args)
    selected_event_frame = int(j)
    contact_mode = "event_frame"
    if (not contact_ok) and cand_kind == "gap_reappear":
        static_ok, static_dn, static_i, static_label = _contact_support_for_static_ball(arr, k, args)
        if static_ok:
            contact_ok, best_dn, best_i, best_label = static_ok, static_dn, static_i, static_label
            selected_event_frame = _first_missing_after(arr, k, j)
            contact_mode = "static_before_loss"

    info.update(contact_min_dn=None if not np.isfinite(best_dn) else round(float(best_dn), 3),
                contact_frame=int(best_i), contact_label=str(best_label),
                contact_mode=contact_mode, selected_event_frame=int(selected_event_frame))
    if not contact_ok:
        return False, "no_near_foot_contact_support", info

    prev_med = _prev_ball_step_median_px(arr, k if cand_kind == "gap_reappear" else j, args)
    jump_ratio = max(1.0, float(_cfg(args, "ball_speed_jump_ratio", DEFAULT_BALL_SPEED_JUMP_RATIO)))
    speed_jump_ok = (prev_med <= 1e-6) or (move_px >= max(step_gate, prev_med * jump_ratio))
    info["prev_med_px"] = round(float(prev_med), 3)
    if not speed_jump_ok:
        return False, "not_a_speed_jump", info

    foot_ok, foot_cos, foot_move_px, fa, fb = _foot_same_direction_support(arr, j, move, args)
    info.update(foot_cos=round(float(foot_cos), 3), foot_move_px=round(float(foot_move_px), 3), foot_pair=f"{fa}->{fb}")
    if not foot_ok:
        return False, "no_same_direction_foot_motion", info

    strength = move_px / max(step_gate, 1e-6)
    info["strength"] = round(float(strength), 3)
    return True, "accepted", info


def _debug_ball_speed_candidates(arr: Dict[str, np.ndarray], fps: float, args=None) -> List[Dict]:
    out = []
    limit = max(1, int(_cfg(args, "debug_candidate_limit", DEFAULT_DEBUG_CANDIDATE_LIMIT)))
    for k, j, move, move_px, step_gate, cand_kind in _ball_motion_candidates(arr, fps, args):
        ok, reason, info = _candidate_reject_reason(arr, fps, args, k, j, move, move_px, step_gate, cand_kind)
        info["accepted"] = bool(ok)
        info["reason"] = reason
        out.append(info)
    # 优先保留时间靠前的大候选和被接受候选，便于查为什么没提前报。
    out = sorted(out, key=lambda x: (not x.get("accepted", False), x.get("event_frame", 10**9), -x.get("move_px", 0.0)))
    return out[:limit]

def _visible_ball_speed_events(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, args=None) -> List[Event]:
    """首选逻辑：球大位移优先，但必须有脚部合理支持。

    修正点：
      - 不再允许开头第一二帧检测框跳变触发；
      - 不再允许 event 帧附近没有脚点/脚离球很远时，仅靠“脚也在动”触发；
      - 支持球中间漏检 1~N 帧后重现的大位移，例如 128 有球、129 丢球、130 球已飞出。
    """
    events: List[Event] = []
    min_gap = frames(float(_cfg(args, "min_event_gap_sec", DEFAULT_MIN_EVENT_GAP_SEC)), fps, 1)
    last_event_idx = -10 ** 9

    for k, j, ball_move, step_px, step_gate, cand_kind in _ball_motion_candidates(arr, fps, args):
        if j - last_event_idx < min_gap:
            continue

        ok, reason, info = _candidate_reject_reason(arr, fps, args, k, j, ball_move, step_px, step_gate, cand_kind)
        if not ok:
            continue

        event_idx = int(info.get("selected_event_frame", j))
        strength = float(info.get("strength", max(step_px / max(step_gate, 1e-6), 1.0)))
        evidence = (
            f"{cand_kind}=1,from={k},reappear_frame={j},event_frame={event_idx},move_px={step_px:.1f},gate_px={step_gate:.1f},"
            f"contact_dn={info.get('contact_min_dn')},contact_frame={info.get('contact_frame')},contact_mode={info.get('contact_mode')},"
            f"prev_med_px={info.get('prev_med_px')},foot_cos={info.get('foot_cos')},"
            f"foot_move_px={info.get('foot_move_px')},foot_pair={info.get('foot_pair')},strength={strength:.3f}"
        )
        ev = _event(
            event_idx,
            "ball_speed_foot_dir" if cand_kind == "consecutive" else "ball_gap_reappear_foot_dir",
            min(1.0, 0.76 + 0.12 * min(strength, 2.0)),
            evidence,
            obs,
            arr,
            step_gate,
            step_px,
        )
        ev.motion_hps = float(arr["abs_step_hps"][j])
        events.append(ev)
        last_event_idx = event_idx

    return events


def _visible_ball_speed_event(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, args=None) -> Optional[Event]:
    events = _visible_ball_speed_events(obs, arr, fps, args)
    return events[0] if events else None



def _foot_closing_to_ball_before_loss(arr: Dict[str, np.ndarray], c: int, args=None) -> Tuple[bool, float, int, int]:
    """loss_only_fallback: 检查丢球前脚是否在靠近球。"""
    look = max(1, int(_cfg(args, "loss_fallback_approach_lookback", DEFAULT_LOSS_FALLBACK_APPROACH_LOOKBACK)))
    valid_ts = []
    for t in range(max(0, int(c) - look), int(c) + 1):
        if arr["valid"][t] and arr["foot_valid"][t] and np.isfinite(arr["dist_norm"][t]):
            valid_ts.append(t)
    if len(valid_ts) < 2:
        return False, 0.0, -1, -1

    first, last = valid_ts[0], valid_ts[-1]
    d0 = float(arr["dist_norm"][first])
    d1 = float(arr["dist_norm"][last])
    closing = d0 - d1
    foot_move = float(np.linalg.norm(arr["foot_xy"][last] - arr["foot_xy"][first]))

    # closing 只设很小门槛，避免纯抖动；主要约束仍是 c 帧脚球距离要近。
    ok = bool(closing >= 0.10 and foot_move >= max(5.0, 0.35 * float(_cfg(args, "min_foot_move_px", DEFAULT_MIN_FOOT_MOVE_PX))))
    return ok, closing, int(first), int(last)


def _loss_only_after_contact(arr: Dict[str, np.ndarray], c: int, fps: float, args=None) -> Optional[Tuple[float, int, int, float, str]]:
    """球贴脚后突然长期丢失的兜底。

    处理：触球后一两帧内球因为速度/运动模糊直接检测不到，
    且后续一段时间没有重现，因此看不到“可见大位移”的情况。
    """
    n = len(arr["valid"])
    if c < 0 or c + 1 >= n:
        return None
    if not (arr["valid"][c] and arr["foot_valid"][c] and np.isfinite(arr["dist_norm"][c])):
        return None

    gate = float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM))
    if float(arr["dist_norm"][c]) > gate:
        return None
    if arr["hand_dist"][c] < arr["foot_dist"][c]:
        return None

    miss = c + 1
    if arr["valid"][miss]:
        return None

    # loss_reappear_sec 作为“长期丢球”的确认窗口。
    loss_sec = float(_cfg(args, "loss_reappear_sec", DEFAULT_LOSS_REAPPEAR_SEC))
    min_miss = frames(loss_sec, fps, 1)
    max_check = min(n, miss + min_miss)

    loss_end = miss
    while loss_end < max_check and not arr["valid"][loss_end]:
        loss_end += 1
    miss_count = loss_end - miss
    if miss_count < min_miss:
        return None

    closing_ok, closing_dn, fa, fb = _foot_closing_to_ball_before_loss(arr, c, args)
    if not closing_ok:
        return None

    strength = min(2.5, 1.0 + miss_count / max(float(min_miss), 1.0) * 0.35 + max(0.0, closing_dn) * 0.25)
    evidence = (
        f"fallback=loss_only,contact={c},first_miss={miss},miss_count={miss_count},"
        f"dist_norm={float(arr['dist_norm'][c]):.3f},gate={gate:.3f},"
        f"closing_dn={closing_dn:.3f},foot_pair={fa}->{fb}"
    )
    return strength, int(c), int(miss), float(closing_dn), evidence


def _loss_only_event(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, args=None) -> Optional[Event]:
    """可选 fallback：球在脚附近后突然长期丢失。"""
    if int(_cfg(args, "enable_loss_fallback", DEFAULT_ENABLE_LOSS_FALLBACK)) != 1:
        return None
    start_frame = _event_search_start_frame(fps, args)
    gate = float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM))
    for c in range(max(1, start_frame), len(arr["valid"]) - 1):
        got = _loss_only_after_contact(arr, c, fps, args)
        if not got:
            continue
        strength, event_idx, miss, progress, evidence = got
        ev = _event(event_idx, "loss_only_fallback", min(1.0, 0.66 + 0.13 * min(strength, 2.5)),
                    evidence, obs, arr, gate, progress)
        ev.motion_hps = float(strength)
        return ev
    return None


# 生成 CSV 诊断行。
# 只在 detail=True 时调用，普通推理不会计算这些字符串/字典，避免无谓开销。
def _detail_rows(obs: List[FrameObs], arr: Dict[str, np.ndarray], events: List[Event], args=None) -> List[Dict]:
    """生成逐帧诊断行。"""
    event_map = {e.frame_idx: e for e in events}
    gate = float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM))
    close = arr["valid"] & arr["foot_valid"] & np.isfinite(arr["dist_norm"]) & (arr["dist_norm"] <= gate) & ~(arr["hand_dist"] < arr["foot_dist"])
    rows = []
    for i, o in enumerate(obs):
        e = event_map.get(i)
        rows.append({
            "frame_idx": i, "frame_id": i + 1, "time_sec": round(o.time_sec, 4),
            "ball_detected": bool(arr["valid"][i]), "ball_x": float(arr["centers"][i, 0]), "ball_y": float(arr["centers"][i, 1]),
            "nearest_foot_label": str(arr["foot_label"][i]),
            "foot_dist": float(arr["foot_dist"][i]) if np.isfinite(arr["foot_dist"][i]) else float("inf"),
            "dist_norm": float(arr["dist_norm"][i]) if np.isfinite(arr["dist_norm"][i]) else float("inf"),
            "contact_support_dist_norm": float(gate), "is_contact_candidate": bool(close[i]),
            "abs_step_hps": float(arr["abs_step_hps"][i]),
            "event_kind": e.kind if e else "", "event_confidence": e.confidence if e else 0.0,
            "event_evidence": e.evidence if e else "",
        })
    return rows


# 给 offline/online 共用的事件判断入口.
# online 会把当前已处理的前缀 obs 传进来，offline 会传完整视频 obs。
# detail=False 时不会返回逐帧 rows。
def detect_events(obs: List[FrameObs], fps: float, height: int, *, width: int = 0, detail: bool = False, args=None) -> Tuple[List[Event], Dict[str, np.ndarray], List[Dict], Dict[str, float]]:
    arr = build_arrays(obs, fps, height, width); arr["frame_h"] = float(height); arr["frame_w"] = float(width or height)
    if len(obs) < 3:
        return [], arr, [], {"reason": "too_few_frames", "decision_policy": "v10_timeline_motion_first"}
    # 主路径：按时间线找“球大位移 + 脚同向位移”。
    # 业务要求是在线检测：第一个有效 kick 一旦成立就返回，不继续收后面的第二/第三次补踢。
    # 因此 detect_events 默认只返回第一个事件；需要离线排查多个事件时，才通过 return_all_events=True 展开。
    visible_events = _visible_ball_speed_events(obs, arr, fps, args)
    events = visible_events

    # loss_only 是可选的“球贴脚后突然长期丢失”兜底。
    # 它要和 visible_events 按时间竞争：如果它发生得更早，就应该返回它，
    # 不能等到后面第二脚的 visible ball speed 才触发。
    if int(_cfg(args, "enable_loss_fallback", DEFAULT_ENABLE_LOSS_FALLBACK)) == 1:
        loss_ev = _loss_only_event(obs, arr, fps, args)
        if loss_ev is not None and (not events or loss_ev.frame_idx < events[0].frame_idx):
            events = [loss_ev] + events


    if events and not bool(_cfg(args, "return_all_events", False)):
        events = [events[0]]

    for k, e in enumerate(events):
        e.event_id = k
    stats = {
        "decision_policy": "v14_visible_ball_speed_plus_loss_only_clean",
        "valid_ball_ratio": float(np.mean(arr["valid"])),
        "loss_reappear_frames": float(frames(float(_cfg(args, "loss_reappear_sec", DEFAULT_LOSS_REAPPEAR_SEC)), fps, 1)),
        "min_ball_move_px": float(_cfg(args, "min_ball_move_px", DEFAULT_MIN_BALL_MOVE_PX)),
        "min_ball_move_ratio": float(_cfg(args, "min_ball_move_ratio", DEFAULT_MIN_BALL_MOVE_RATIO)),
        "effective_min_ball_move_px": float(_min_ball_move_px(arr, args)),
        "min_ball_speed_pxpf": float(_cfg(args, "min_ball_speed_pxpf", DEFAULT_MIN_BALL_SPEED_PXPF)),
        "effective_ball_step_gate_px": float(_ball_step_gate_px(arr, args)),
        "foot_ball_same_dir_cos": float(_cfg(args, "foot_ball_same_dir_cos", DEFAULT_FOOT_BALL_SAME_DIR_COS)),
        "min_foot_move_px": float(_cfg(args, "min_foot_move_px", DEFAULT_MIN_FOOT_MOVE_PX)),
        "ball_speed_lookback": int(_cfg(args, "ball_speed_lookback", DEFAULT_BALL_SPEED_LOOKBACK)),
        "ball_speed_jump_ratio": float(_cfg(args, "ball_speed_jump_ratio", DEFAULT_BALL_SPEED_JUMP_RATIO)),
        "min_event_gap_sec": float(_cfg(args, "min_event_gap_sec", DEFAULT_MIN_EVENT_GAP_SEC)),
        "event_count": float(len(events)),
        "event_found": float(bool(events)),
        "event_search_start_sec": float(_cfg(args, "event_search_start_sec", DEFAULT_EVENT_SEARCH_START_SEC)),
        "event_search_start_frame": float(_event_search_start_frame(fps, args)),
        "contact_support_dist_norm": float(_cfg(args, "contact_support_dist_norm", DEFAULT_CONTACT_SUPPORT_DIST_NORM)),
        "ball_gap_lookback": int(_cfg(args, "ball_gap_lookback", DEFAULT_BALL_GAP_LOOKBACK)),
        "enable_loss_fallback": float(int(_cfg(args, "enable_loss_fallback", DEFAULT_ENABLE_LOSS_FALLBACK)) == 1),
        "loss_fallback_approach_lookback": int(_cfg(args, "loss_fallback_approach_lookback", DEFAULT_LOSS_FALLBACK_APPROACH_LOOKBACK)),
        "return_all_events": float(bool(_cfg(args, "return_all_events", False))),
    }
    if bool(_cfg(args, "debug_decision", False)):
        stats["candidate_debug_top"] = _debug_ball_speed_candidates(arr, fps, args)
        stats["selected_event_evidence"] = events[0].evidence if events else ""
    return events, arr, (_detail_rows(obs, arr, events, args) if detail else []), stats


# offline 处理完整视频。
# 流程：读全部帧 -> 批量检测球/pose -> 构造 observations -> 一次性 detect_events。
# offline 不提前停止，因此适合做最稳定的最终结果和调试基准。
def process_video_offline(video_path: Path, ball_model: YOLO, pose_model: YOLO, args, *, detail: bool = False) -> VideoResult:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count, chunk = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0), max(1, int(args.batch))
    obs: List[FrameObs] = []; track = new_track(); ball_t = pose_t = 0.0; t0 = time.time()
    while True:
        batch = []
        for _ in range(chunk):
            ok, frame = cap.read()
            if not ok: break
            batch.append(frame)
        if not batch: break
        tb = time.time(); br = predict_batch(ball_model, batch, imgsz=args.ball_imgsz, conf=args.ball_conf, args=args)
        tp = time.time(); pr = predict_batch(pose_model, batch, imgsz=args.pose_imgsz, conf=args.person_conf, args=args)
        te = time.time(); ball_t += tp - tb; pose_t += te - tp
        append_observations(obs, br, pr, ball_model, fps, w, h, track, args)
    cap.release()
    tl = time.time(); events, arr, rows, stats = detect_events(obs, fps, h, width=w, detail=detail, args=args); logic_t = time.time() - tl
    return make_result(video=Path(video_path), fps=fps, width=w, height=h, frame_count=frame_count,
                       mode="offline", early_stopped=False, observations=obs, events=events,
                       arrays=arr, detail_rows=rows, stats=stats,
                       timings={"ball_sec": ball_t, "pose_sec": pose_t, "logic_sec": logic_t, "total_sec": time.time() - t0})
