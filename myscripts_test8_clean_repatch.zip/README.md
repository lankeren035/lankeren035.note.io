# 足球踢球点 TCP 检测代码说明（clean 版）

本版本基于 `myscripts_test7` 清理而来。检测逻辑只保留两层：

1. **主逻辑 `visible_ball_speed`**：球突然大位移 + 球速度突增 + 脚与球同方向运动 + 脚大致在球附近。
2. **兜底逻辑 `loss_only_fallback`**：球在脚附近后突然长期丢失，用于处理高速踢出/运动模糊导致后续球框长期检测不到的情况。

已删除旧的 `blur_loss/direct_motion` 逻辑和对应重复参数：

```text
CONTACT_PERCENTILE
MOTION_PERCENTILE
DIRECTION_COS_THRESH
MOTION_WINDOW_SEC
MIN_VISIBLE_STEPS
BALL_MOVE_LOOKAHEAD_SEC
BALL_MOVE_CONTACT_GATE
STRONG_BALL_MOVE_MULT
ALLOW_BLUR_FALLBACK_EARLY
```

这些参数不再出现在服务端启动脚本和 Python 参数中，避免和主逻辑参数混淆。

---

## 1. 核心文件

```text
service_kick_detector_tcp.py        TCP 检测服务端
kick_offline.py                     踢球事件判断逻辑
kick_common.py                      YOLO 检测结果解析、FrameObs 构造、公共工具
tcp_packet.py                       TCP 帧包收发协议
mock_sender_tcp.py                  本地视频发送端
mock_camera_sender_tcp.py           摄像头发送端
visualize_debug_session.py          debug 可视化
```

Windows 启动脚本：

```text
service_kick_detector_tcp_win.bat / .ps1        启动检测服务端
mock_sender_tcp_win.bat / .ps1                  本地视频发送端
mock_camera_sender_tcp_win.bat / .ps1           摄像头发送端
visualize_debug_all_win.bat / .ps1              可视化 debug_runs
```

---

## 2. 服务端启动

Windows 直接运行：

```powershell
.\service_kick_detector_tcp_win.bat
```

或者先设置环境变量再启动：

```powershell
$env:CONTACT_SUPPORT_DIST_NORM="3.2"
$env:DEBUG_FULL_SESSION="0"
.\service_kick_detector_tcp_win.bat
```

`DEBUG_FULL_SESSION=0` 是正式在线检测推荐配置。否则即使已经检测到事件，也会继续处理完整 session，导致返回延迟很大。

---

## 3. 当前检测流程

服务端收到帧后不是每帧立即跑模型，而是按 `CHUNK` 攒帧：

```text
收到帧 -> 缓存
攒够 CHUNK 帧 -> 批量跑球检测和人体姿态检测
累积历史 obs -> 重新判断是否有 kick
确认 event -> 返回 JSON -> 清空当前 session -> 等待下一次输入
```

默认：

```text
CHUNK=4
BATCH=4
ONLINE_WAIT_SEC=0.12
STABLE_CHUNKS=1
```

---

## 4. 主逻辑：visible_ball_speed

主逻辑找两类候选：

```text
consecutive:
  j-1 有球，j 有球，球从 j-1 到 j 大位移。

gap_reappear:
  k 有球，中间短暂丢球，j 重新检测到球，球从 k 到 j 大位移。
```

候选需要通过：

```text
1. 不在开头 warmup 区间内；
2. 球位移 >= max(MIN_BALL_MOVE_PX, MIN_BALL_MOVE_RATIO * image_width, MIN_BALL_SPEED_PXPF)；
3. 球速度相对前几帧突增；
4. 事件帧附近脚踝点大致在球附近；
5. 脚在球飞出前/同时朝球运动方向移动。
```

---

## 5. loss_only_fallback

用于这种情况：

```text
球在脚附近
脚在丢球前持续靠近球
下一帧球突然丢失
后面连续很长时间都检测不到球
```

这类情况看不到“球飞出去后的可见大位移”，所以不能靠主逻辑判断，只能用长期丢球兜底。

默认启用：

```text
ENABLE_LOSS_FALLBACK=1
```

不需要时可关闭：

```powershell
$env:ENABLE_LOSS_FALLBACK="0"
```

---

## 6. 服务端参数说明

### 6.1 TCP / 模型参数

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `TCP_HOST` | `0.0.0.0` | 服务端监听地址 |
| `TCP_PORT` | `19090` | 服务端监听端口 |
| `BACKLOG` | `16` | TCP 等待队列大小 |
| `SOCKET_TIMEOUT` | `0` | socket 超时；0 表示不主动超时 |
| `BALL_MODEL` | 自动查找 | 球检测模型路径 |
| `POSE_MODEL` | 自动查找 | 人体姿态模型路径 |
| `DEVICE` | `0` | GPU id；CPU 用 `cpu` |
| `HALF` | `1` | CUDA/TensorRT 下使用 FP16 |
| `BATCH` | `4` | 模型推理 batch size |
| `CHUNK` | `4` | 在线每收到多少帧判断一次，单位是帧 |
| `BALL_IMGSZ` | `640` | 球检测输入尺寸 |
| `POSE_IMGSZ` | `640` | 姿态模型输入尺寸 |
| `BALL_CONF` | `0.16` | 球检测置信度阈值 |
| `PERSON_CONF` | `0.20` | 人体检测置信度阈值 |
| `POSE_CONF` | `0.18` | 姿态关键点置信度阈值 |
| `YOLO_IOU` | `0.50` | YOLO NMS IoU |
| `BALL_CLASS_NAMES` | `sports ball,...` | 可接受的球类别名 |
| `MAX_BALL_CANDIDATES` | `8` | 每帧最多保留多少个球候选 |
| `HAND_CONF` | `0.20` | 手关键点过滤阈值；手比脚更近时会排除触球候选 |

### 6.2 主逻辑参数

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `MIN_BALL_MOVE_PX` | `35` | 球大位移的最小像素门槛 |
| `MIN_BALL_MOVE_RATIO` | `0.03` | 球大位移相对图像宽度的门槛 |
| `MIN_BALL_SPEED_PXPF` | `0` | 每帧球位移硬门槛；0 表示不额外提高 |
| `FOOT_BALL_SAME_DIR_COS` | `0.35` | 脚运动方向和球运动方向的余弦阈值 |
| `MIN_FOOT_MOVE_PX` | `15` | 脚至少移动多少像素才算有效发力 |
| `CONTACT_SUPPORT_DIST_NORM` | `3.2` | 脚踝点到球心距离上限，单位是球半径倍数 |
| `BALL_SPEED_LOOKBACK` | `3` | 判断球速度突增时，回看前几帧速度 |
| `BALL_SPEED_JUMP_RATIO` | `1.6` | 当前球速至少是前序中值速度的多少倍 |
| `EVENT_SEARCH_START_SEC` | `0.80` | 开头多少秒不允许报 event，防止启动抖动 |
| `BALL_GAP_LOOKBACK` | `3` | 短暂漏检后重现时，最多回看几帧找上一帧球 |

`CONTACT_SUPPORT_DIST_NORM` 是相对阈值，不是像素阈值：

```text
dist_norm = 脚踝点到球心距离 / 球半径
```

脚尖踢球时，YOLO pose 只有脚踝点，没有脚尖点，所以该值建议用 `3.2` 起步。

### 6.3 loss fallback 参数

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `ENABLE_LOSS_FALLBACK` | `1` | 是否启用长期丢球兜底 |
| `LOSS_REAPPEAR_SEC` | `0.70` | 球连续丢失多久才认为是长期丢失；30fps 约 21 帧 |
| `LOSS_FALLBACK_APPROACH_LOOKBACK` | `4` | 丢球前回看几帧，检查脚是否持续靠近球 |

### 6.4 在线返回控制

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `ONLINE_WARMUP_SEC` | `0.80` | 在线累计多少秒后才开始允许返回事件 |
| `ONLINE_WAIT_SEC` | `0.12` | 候选 event 后需要再看多少未来帧证据 |
| `STABLE_CHUNKS` | `1` | 连续几次 chunk 判断一致才返回 |
| `DEBUG_FULL_SESSION` | `0` | 1 表示完整跑完整个 session，不提前返回；正式检测必须为 0 |

---

## 7. 本地视频发送端

运行：

```powershell
.\mock_sender_tcp_win.bat
```

交互：

```text
回车：处理下一个视频
空格 + 回车：继续当前视频后续帧
q：退出
```

适合一个视频里有多个踢球点的情况。

---

## 8. 摄像头发送端

运行：

```powershell
.\mock_camera_sender_tcp_win.bat
```

交互：

```text
回车 / 空格 + 回车：继续下一次检测
q：退出
```

检测到一次 event 后发送端会暂停，等待人工继续。

---

## 9. Debug 可视化

启用服务端检测日志：

```powershell
$env:DEBUG_DETECTIONS="1"
```

完整跑完 session 用于排查，不提前返回：

```powershell
$env:DEBUG_FULL_SESSION="1"
```

正式在线检测请使用：

```powershell
$env:DEBUG_FULL_SESSION="0"
```

生成可视化：

```powershell
.\visualize_debug_all_win.bat
```

只看最新一次：

```bash
python visualize_debug_session.py --debug-dir debug_runs --latest --overwrite
```

---

## 10. 返回结果字段

重点看：

```text
kick.frame_idx        当前 session 内 0-based 踢球帧
kick.frame_id         当前 session 内 1-based 踢球帧
kick.kind             命中类型：ball_speed_foot_dir / ball_gap_reappear_foot_dir / loss_only_fallback
sender.global_event_frame_idx   本地视频模式下的原视频 0-based 帧号
```

常见 `kind`：

```text
ball_speed_foot_dir           连续可见球大位移 + 脚同方向
ball_gap_reappear_foot_dir    短暂丢球后重现的大位移 + 脚同方向
loss_only_fallback            球在脚边后长期丢失
```
