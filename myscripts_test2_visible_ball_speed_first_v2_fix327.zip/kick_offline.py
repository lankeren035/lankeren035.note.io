#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

# =============================================================================
# offline 事件判断逻辑。
#
# 当前策略改为近距离摄像头优先：
#   1. 首选 visible_ball_speed：只要球连续可见且发生高速大位移，
#      并且脚部位移与球运动方向一致，直接判定。
#      不再先用脚球距离筛 contact candidate，因为摄像头可能没拍到正好接触的一帧。
#   2. 如果脚部姿态暂时不可用，但球位移极大，也允许 ball_only_strong 触发。
#   3. 只有 visible_ball_speed 不成立时，才使用 blur_loss fallback：
#      球前一刻可见/低速，随后连续丢失，按运动模糊处理。
#
# 这样做的原因：
#   - 你的场景摄像头距球约 1 米，球通常可见；
#   - 核心证据应是球的真实速度和位移，而不是脚球距离；
#   - 脚球距离只用于估计最终落在哪一帧，不作为主触发门槛。
# =============================================================================
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from ultralytics import YOLO

from kick_common import (
    Event, FrameObs, VideoResult, append_observations, build_arrays, contact_gate,
    direction_ok, frames, make_result, new_track, predict_batch, robust_motion_gate,
)


def _cfg(args, name: str, default):
    """读取可配置参数；兼容旧脚本未传新增字段的情况。"""
    return getattr(args, name, default)

# 以下是默认值。实际运行时可通过 .sh / argparse 覆盖。
# 放在这里是为了兼容旧脚本没有传新增参数的情况。
DEFAULT_MOTION_WINDOW_SEC = 0.24       # direct_motion 可见球运动确认窗口
DEFAULT_LOSS_REAPPEAR_SEC = 0.70      # blur_loss 丢球后重现检查窗口
DEFAULT_MIN_VISIBLE_STEPS = 2         # direct_motion 至少需要几个有效运动 step
DEFAULT_CONTACT_PERCENTILE = 35.0     # 脚球距离分布的接触候选百分位
DEFAULT_MOTION_PERCENTILE = 85.0      # 球运动分布的明显运动百分位
DEFAULT_DIRECTION_COS = 0.15          # 球运动方向与 foot->ball 的最低余弦
DEFAULT_MIN_BALL_MOVE_PX = 35.0       # 接触后球心累计位移至少多少像素，过滤静止球检测抖动
DEFAULT_MIN_BALL_MOVE_RATIO = 0.03    # 接触后球心累计位移至少达到图像宽度的比例
DEFAULT_BALL_MOVE_LOOKAHEAD_SEC = 0.20 # 从接触候选向后看多长时间寻找球的真实位移
DEFAULT_BALL_MOVE_CONTACT_GATE = 1.50  # blur_loss fallback 的脚球距离上限，单位=球半径倍数
DEFAULT_MIN_BALL_SPEED_PXPF = 0.0       # 每帧球心位移硬门槛；0 表示复用 min_ball_move_px/ratio
DEFAULT_FOOT_BALL_SAME_DIR_COS = 0.35   # 脚位移和球位移同向的最低余弦
DEFAULT_MIN_FOOT_MOVE_PX = 15.0         # 脚部至少移动多少像素才作为同向证据
DEFAULT_STRONG_BALL_MOVE_MULT = 2.0     # 保留旧参数；默认不再用于首选触发
DEFAULT_BALL_SPEED_LOOKBACK = 3         # 判断速度突增时向前看几帧
DEFAULT_BALL_SPEED_JUMP_RATIO = 1.6     # 当前球速至少是前序中值速度的多少倍
DEFAULT_VISIBLE_REQUIRE_FOOT_DIR = True # 首选可见球高速分支必须要脚和球同向，防止纯球框跳动/误检触发
DEFAULT_VISIBLE_EVENT_COOLDOWN_SEC = 0.60 # 多事件输出时，同一次踢球后的冷却时间
DEFAULT_MAX_VISIBLE_EVENT_DIST_NORM = 2.20 # 高速可见球分支的宽松脚球距离 sanity check，防止远处误检/飞行中跳变触发


# 创建 Event 对象。
# idx 传入 0-based 帧号，输出里同时保存 1-based frame_id，便于和标注答案对齐。
def _event(idx: int, kind: str, conf: float, evidence: str, obs: List[FrameObs],
           arr: Dict[str, np.ndarray], gate: float, progress: float) -> Event:
    idx = int(np.clip(idx, 0, len(obs) - 1))
    dn, fd = arr["dist_norm"][idx], arr["foot_dist"][idx]
    return Event(0, idx, idx + 1, float(obs[idx].time_sec), kind, float(np.clip(conf, 0, 1)),
                 float(dn) if np.isfinite(dn) else float("inf"),
                 float(fd) if np.isfinite(fd) else float("inf"),
                 float(gate), float(gate), float(progress), str(arr["foot_label"][idx]), evidence)


# 保护函数：如果自适应 gate 无效，就使用 fallback。
def _finite_gate(x: float, fb: float = float("inf")) -> float:
    return float(x) if np.isfinite(x) and x > 0 else float(fb)


def _min_ball_move_px(arr: Dict[str, np.ndarray], args=None) -> float:
    """接触后球必须真实移动的绝对门槛。

    使用 max(像素阈值, 图像宽度比例阈值)。
    这样静止球的检测框抖动、脚移动、短暂漏检不会轻易触发踢球事件。
    """
    px = max(0.0, float(_cfg(args, "min_ball_move_px", DEFAULT_MIN_BALL_MOVE_PX)))
    ratio = max(0.0, float(_cfg(args, "min_ball_move_ratio", DEFAULT_MIN_BALL_MOVE_RATIO)))
    frame_w = max(float(arr.get("frame_w", arr.get("frame_h", 1.0))), 1.0)
    return max(px, ratio * frame_w)


def _ball_move_ok(arr: Dict[str, np.ndarray], c: int, j: int, args=None) -> Tuple[bool, float, float]:
    """判断 c 到 j 的球心累计位移是否超过硬门槛。"""
    if c < 0 or j < 0 or c >= len(arr["valid"]) or j >= len(arr["valid"]):
        return False, 0.0, _min_ball_move_px(arr, args)
    if not (arr["valid"][c] and arr["valid"][j]):
        return False, 0.0, _min_ball_move_px(arr, args)
    dist = float(np.linalg.norm(arr["centers"][j] - arr["centers"][c]))
    gate = _min_ball_move_px(arr, args)
    return dist >= gate, dist, gate


# 计算两个运动门槛：
#   raw_gate: 球自身真实检测框的运动门槛。
#   rel_gate: 球相对最近脚点的运动门槛。
# direct_motion 必须同时满足两者，防止“脚动球不动”或“相机整体移动”误判。
def _motion_gates(arr: Dict[str, np.ndarray], args=None) -> Tuple[float, float]:
    v, fv = arr["valid"], arr["foot_valid"]
    pct = float(_cfg(args, "motion_percentile", DEFAULT_MOTION_PERCENTILE))
    raw = max(_finite_gate(robust_motion_gate(arr["abs_step_hps"][v], pct), 0.0), 1e-6)
    rel = max(_finite_gate(robust_motion_gate(arr["rel_step_hps"][v & fv], pct), raw), 1e-6)
    return raw, rel


# 接触候选 mask。
# 条件：球真实可见、脚点有效、脚球距离进入当前视频的近距离范围。
# 额外过滤：如果手比脚更近，则该帧不作为脚触球候选。
def _close_mask(arr: Dict[str, np.ndarray], gate: float) -> np.ndarray:
    close = arr["valid"] & arr["foot_valid"] & np.isfinite(arr["dist_norm"]) & (arr["dist_norm"] <= gate)
    return close & ~(arr["hand_dist"] < arr["foot_dist"])


def _loose_ball_contact_mask(arr: Dict[str, np.ndarray], cgate: float, args=None) -> np.ndarray:
    """ball-first 专用的接触候选 mask。

    原来的 _close_mask 使用 contact_percentile 得到的自适应近距离 gate。
    在近距离摄像头里，人的脚会在大量帧里非常靠近球，35 分位 gate
    可能被压得过低，导致真实触球帧反而被排除。

    ball-first 逻辑的核心证据是“球真实大位移”，所以这里用更宽松的
    max(cgate, ball_move_contact_gate) 作为脚球接近门槛。这样不会放松
    最终事件，因为后面仍然必须通过球位移硬门槛。
    """
    loose_gate = max(
        float(cgate),
        float(_cfg(args, "ball_move_contact_gate", DEFAULT_BALL_MOVE_CONTACT_GATE)),
    )
    close = arr["valid"] & arr["foot_valid"] & np.isfinite(arr["dist_norm"]) & (arr["dist_norm"] <= loose_gate)
    return close & ~(arr["hand_dist"] < arr["foot_dist"])



def _ball_step_gate_px(arr: Dict[str, np.ndarray], args=None) -> float:
    """单帧球心位移门槛。默认复用 max(px, ratio*width)。"""
    base = _min_ball_move_px(arr, args)
    pxpf = max(0.0, float(_cfg(args, "min_ball_speed_pxpf", DEFAULT_MIN_BALL_SPEED_PXPF)))
    return max(base, pxpf)


def _ball_step_px(arr: Dict[str, np.ndarray], j: int) -> float:
    if j <= 0 or j >= len(arr["valid"]):
        return 0.0
    if not (arr["valid"][j] and arr["valid"][j - 1]):
        return 0.0
    return float(np.linalg.norm(arr["centers"][j] - arr["centers"][j - 1]))


def _prev_ball_step_median_px(arr: Dict[str, np.ndarray], j: int, args=None) -> float:
    """当前大位移之前的球速中值，用于判断突然加速。"""
    k = max(1, int(_cfg(args, "ball_speed_lookback", DEFAULT_BALL_SPEED_LOOKBACK)))
    vals = []
    for t in range(max(1, j - k), j):
        v = _ball_step_px(arr, t)
        if np.isfinite(v) and v > 0:
            vals.append(v)
    return float(np.median(vals)) if vals else 0.0


def _foot_same_direction_support(arr: Dict[str, np.ndarray], j: int, ball_move: np.ndarray, args=None) -> Tuple[bool, float, float, int, int]:
    """在 ball step j 周围寻找脚部同向运动证据。

    j 表示球从 j-1 到 j 的运动。脚可能不是正好在同两帧被检测到，
    因此在 [j-2, j+1] 的小窗口内搜索脚点位移。这里不要求脚球距离，
    只要求脚部运动方向与球运动方向一致，避免接触帧没拍到时漏检。
    """
    n = len(arr["valid"])
    min_move = max(0.0, float(_cfg(args, "min_foot_move_px", DEFAULT_MIN_FOOT_MOVE_PX)))
    min_cos = float(_cfg(args, "foot_ball_same_dir_cos", DEFAULT_FOOT_BALL_SAME_DIR_COS))
    bm = np.asarray(ball_move, dtype=float)
    bn = float(np.linalg.norm(bm))
    if bn <= 1e-9:
        return False, 0.0, 0.0, -1, -1

    best = (False, -1.0, 0.0, -1, -1)
    a0 = max(0, j - 2)
    b1 = min(n - 1, j + 1)
    for a in range(a0, min(j + 1, n)):
        for b in range(max(a + 1, j - 1), b1 + 1):
            if a < 0 or b >= n or not (arr["foot_valid"][a] and arr["foot_valid"][b]):
                continue
            fm = arr["foot_xy"][b] - arr["foot_xy"][a]
            fn = float(np.linalg.norm(fm))
            if fn < min_move:
                continue
            cos = float(np.dot(fm, bm) / max(fn * bn, 1e-9))
            if cos > best[1]:
                best = (cos >= min_cos, cos, fn, a, b)
    return best


def _event_idx_for_ball_step(arr: Dict[str, np.ndarray], j: int) -> int:
    """高球速 step 对应的事件帧。

    j 是球从 j-1 到 j 的大位移。你的人工答案通常标的是“球开始明显飞出”的
    那一帧，也就是 j，而不是 j-1。之前按脚球距离在 j-1/j 中二选一，
    会把答案提前一帧或被脚球距离误导；这里固定返回 j。
    """
    return int(max(0, j))


def _visible_ball_speed_events(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, raw_gate: float, args=None) -> List[Event]:
    """首选逻辑：球连续可见，且球发生突然高速大位移。

    关键修正：
      - 不再允许默认的 ball-only strong 直接触发。
        只看球的大跳变会把远处误检、球框跳动、已经在飞行中的球再次跳动判成 kick。
      - 首选必须有“脚部位移方向与球位移方向一致”的证据。
        这不要求脚球距离很近，避免摄像头没拍到接触帧时漏检。
      - 事件帧固定取大位移后的 j 帧，更贴合你给出的 327/452/556 这类答案。
    """
    n = len(obs)
    step_gate = _ball_step_gate_px(arr, args)
    jump_ratio = max(1.0, float(_cfg(args, "ball_speed_jump_ratio", DEFAULT_BALL_SPEED_JUMP_RATIO)))
    require_foot_dir = bool(_cfg(args, "visible_require_foot_dir", DEFAULT_VISIBLE_REQUIRE_FOOT_DIR))
    cooldown = frames(float(_cfg(args, "visible_event_cooldown_sec", DEFAULT_VISIBLE_EVENT_COOLDOWN_SEC)), fps, 6)

    events: List[Event] = []
    next_allowed = 1
    for j in range(1, n):
        if j < next_allowed:
            continue
        if not (arr["valid"][j - 1] and arr["valid"][j]):
            continue

        ball_move = arr["centers"][j] - arr["centers"][j - 1]
        step_px = float(np.linalg.norm(ball_move))
        if step_px < step_gate:
            continue

        prev_med = _prev_ball_step_median_px(arr, j, args)
        speed_jump_ok = (prev_med <= 1e-6) or (step_px >= max(step_gate, prev_med * jump_ratio))
        if not speed_jump_ok:
            continue

        foot_ok, foot_cos, foot_move_px, fa, fb = _foot_same_direction_support(arr, j, ball_move, args)
        if require_foot_dir and not foot_ok:
            continue
        if (not require_foot_dir) and not foot_ok:
            # 调试/兼容模式下才允许纯球速触发，但需要非常大的位移。
            strong_mult = max(1.0, float(_cfg(args, "strong_ball_move_mult", DEFAULT_STRONG_BALL_MOVE_MULT)))
            if step_px < step_gate * strong_mult:
                continue

        event_idx = _event_idx_for_ball_step(arr, j)

        # 宽松 sanity check：不是用它找候选，而是防止“球框远处跳变/飞行中二次跳变”
        # 被脚同向运动误触发。默认 2.2 个球半径，比原 contact gate 宽很多。
        max_dn = float(_cfg(args, "max_visible_event_dist_norm", DEFAULT_MAX_VISIBLE_EVENT_DIST_NORM))
        if max_dn > 0:
            dn = arr["dist_norm"][event_idx] if 0 <= event_idx < len(arr["dist_norm"]) else np.inf
            if not (np.isfinite(dn) and float(dn) <= max_dn):
                continue

        strength = max(step_px / max(step_gate, 1e-6), float(arr["abs_step_hps"][j]) / max(raw_gate, 1e-6))
        kind = "ball_speed_foot_dir" if foot_ok else "ball_speed_strong"
        conf_base = 0.82 if foot_ok else 0.68
        evidence = (
            f"ball_step={j},event_frame={event_idx},move_px={step_px:.1f},gate_px={step_gate:.1f},"
            f"prev_med_px={prev_med:.1f},foot_ok={int(foot_ok)},foot_cos={foot_cos:.3f},"
            f"foot_move_px={foot_move_px:.1f},foot_pair={fa}->{fb},"
            f"dist_norm={float(arr['dist_norm'][event_idx]) if np.isfinite(arr['dist_norm'][event_idx]) else -1:.3f},"
            f"strength={strength:.3f}"
        )
        ev = _event(
            event_idx,
            kind,
            min(1.0, conf_base + 0.10 * min(strength, 2.0)),
            evidence,
            obs,
            arr,
            max(raw_gate, step_gate),
            step_px,
        )
        ev.motion_hps = float(arr["abs_step_hps"][j])
        events.append(ev)
        next_allowed = j + max(1, int(cooldown))

    return events


def _visible_ball_speed_event(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, raw_gate: float, args=None) -> Optional[Event]:
    events = _visible_ball_speed_events(obs, arr, fps, raw_gate, args)
    return events[0] if events else None


# 判断从 j-1 到 j 这一小步运动是否支持“c 帧是触球候选”。
# 需要同时满足：
#   1. c、j-1、j 都有可用球/脚数据；
#   2. 球自身位移 abs_step_hps 足够大；
#   3. 球相对脚位移 rel_step_hps 足够大；
#   4. 方向大致是从脚指向球，即球在远离脚。
def _step_ok(arr: Dict[str, np.ndarray], c: int, j: int, raw_gate: float, rel_gate: float, args=None) -> Tuple[bool, float, float]:
    if j <= 0 or j >= len(arr["valid"]):
        return False, 0.0, 0.0
    if not (arr["valid"][j] and arr["valid"][j - 1] and arr["foot_valid"][j] and arr["foot_valid"][j - 1] and arr["foot_valid"][c]):
        return False, 0.0, 0.0
    ok_dir, _, progress = direction_ok(arr["rel"][c], arr["rel_vec"][j], float(_cfg(args, "direction_cos_thresh", DEFAULT_DIRECTION_COS)))
    raw_v, rel_v = float(arr["abs_step_hps"][j]), float(arr["rel_step_hps"][j])
    move_ok, move_px, move_gate = _ball_move_ok(arr, c, j, args)
    ok = bool(ok_dir and raw_v >= raw_gate and rel_v >= rel_gate and move_ok)
    strength = max(raw_v / max(raw_gate, 1e-6), rel_v / max(rel_gate, 1e-6), move_px / max(move_gate, 1e-6))
    return ok, strength, progress


# direct_motion 检查。
# 对接触候选 c，向后看一个短窗口：如果有连续多个 step 满足 _step_ok，
# 说明球在接触后可见地持续远离脚，c 就是强候选。
def _visible_motion(arr: Dict[str, np.ndarray], c: int, fps: float, raw_gate: float, rel_gate: float, args=None) -> Optional[Tuple[float, int, int, float]]:
    if c + 1 < len(arr["valid"]) and not arr["valid"][c + 1]:
        return None
    first, good, strength, progress = -1, 0, 0.0, 0.0
    direct_sec = float(_cfg(args, "motion_window_sec", DEFAULT_MOTION_WINDOW_SEC))
    for j in range(c + 1, min(len(arr["valid"]), c + frames(direct_sec, fps, 3) + 1)):
        ok, s, p = _step_ok(arr, c, j, raw_gate, rel_gate, args)
        if ok:
            first = j if first < 0 else first
            good += 1; strength = max(strength, s); progress = max(progress, p)
    return (strength, first, good, progress) if good >= int(_cfg(args, "min_visible_steps", DEFAULT_MIN_VISIBLE_STEPS)) else None


# blur_loss fallback 检查。
# 只在 direct_motion 失败后使用：
#   接触候选 c 后，球先连续检测不到；
#   随后重现时，球相对 c 的位移/速度明显。
# 这对应“踢出去后球运动模糊，检测器漏检几帧”的情况。
def _loss_after_contact(arr: Dict[str, np.ndarray], c: int, fps: float, raw_gate: float, rel_gate: float, args=None) -> Optional[Tuple[float, int, int, float]]:
    loss_sec = float(_cfg(args, "loss_reappear_sec", DEFAULT_LOSS_REAPPEAR_SEC))
    end = min(len(arr["valid"]), c + frames(loss_sec, fps, 6) + 1)
    miss = next((i for i in range(c + 1, end) if not arr["valid"][i]), -1)
    if miss < 0:
        return None
    reap = miss
    while reap < end and not arr["valid"][reap]:
        reap += 1
    if reap >= len(arr["valid"]) or not arr["valid"][reap]:
        return None
    move = arr["centers"][reap] - arr["centers"][c]
    move_ok, move_px, move_gate = _ball_move_ok(arr, c, reap, args)
    if not move_ok:
        return None
    ok_dir, _, progress = direction_ok(arr["rel"][c], move, float(_cfg(args, "direction_cos_thresh", DEFAULT_DIRECTION_COS)))
    progress = progress if ok_dir else move_px
    dt = max((reap - c) / max(float(fps), 1e-6), 1e-6)
    raw_avg = float(move_px / max(float(arr.get("frame_h", 1.0)), 1.0) / dt)
    strength = max(raw_avg / max(raw_gate, 1e-6),
                   float(arr["abs_step_hps"][reap]) / max(raw_gate, 1e-6),
                   float(arr["rel_step_hps"][reap]) / max(rel_gate, 1e-6),
                   move_px / max(move_gate, 1e-6))
    return (strength, int(miss), int(reap), float(progress)) if strength >= 1.0 else None


# ball-first 触发逻辑。
# 适合近距离摄像头场景：球通常可见，核心证据应是“球从静止/低速状态发生足够大的真实位移”。
# 脚点只作为附近接触辅助，不再要求 rel_step 连续多帧满足高阈值，避免脚快速运动把 rel_gate 抬高后漏检。
def _ball_motion_after_contact(arr: Dict[str, np.ndarray], c: int, fps: float, raw_gate: float, cgate: float, args=None) -> Optional[Tuple[float, int, float, float]]:
    if c < 0 or c >= len(arr["valid"]) or not (arr["valid"][c] and arr["foot_valid"][c]):
        return None

    loose_gate = max(float(cgate), float(_cfg(args, "ball_move_contact_gate", DEFAULT_BALL_MOVE_CONTACT_GATE)))
    if not (np.isfinite(arr["dist_norm"][c]) and arr["dist_norm"][c] <= loose_gate):
        return None
    if arr["hand_dist"][c] < arr["foot_dist"][c]:
        return None

    look = frames(float(_cfg(args, "ball_move_lookahead_sec", DEFAULT_BALL_MOVE_LOOKAHEAD_SEC)), fps, 2)
    end = min(len(arr["valid"]), c + look + 1)
    best = None

    for j in range(c + 1, end):
        if not arr["valid"][j]:
            continue
        move = arr["centers"][j] - arr["centers"][c]
        move_ok, move_px, move_gate = _ball_move_ok(arr, c, j, args)
        if not move_ok:
            continue

        raw_v = float(arr["abs_step_hps"][j])
        move_ratio = move_px / max(move_gate, 1e-6)
        if raw_v < raw_gate and move_ratio < 1.5:
            continue

        ok_dir, _, progress = direction_ok(
            arr["rel"][c],
            move,
            float(_cfg(args, "direction_cos_thresh", DEFAULT_DIRECTION_COS)),
        )
        if not ok_dir:
            continue

        strength = max(raw_v / max(raw_gate, 1e-6), move_ratio)
        cand = (strength, j, move_px, progress)
        if best is None or cand[0] > best[0]:
            best = cand

    return best


# 将连续 True 的接触帧合并成区间。
# 例如 52-58 都很近时，把它们看成一个 contact run，而不是独立竞争。
def _runs(mask: np.ndarray):
    i, n = 0, len(mask)
    while i < n:
        if not mask[i]:
            i += 1; continue
        s = i
        while i + 1 < n and mask[i + 1]:
            i += 1
        yield s, i
        i += 1


# 核心事件选择函数。
# 关键点：按时间顺序扫描 contact run，找到第一个物理成立的事件就返回。
# 在同一个 contact run 内，先 direct_motion，再 blur_loss。
# 这样后面飞行阶段的强运动不会覆盖前面的首次触球。
def _select_event(obs: List[FrameObs], arr: Dict[str, np.ndarray], fps: float, cgate: float, raw_gate: float, rel_gate: float, args=None) -> Optional[Event]:
    # 1) 首选：可见球突然高速大位移。
    # 不先用脚球距离筛候选；脚只作为同向运动证据。
    ev = _visible_ball_speed_event(obs, arr, fps, raw_gate, args)
    if ev is not None:
        return ev

    # 2) fallback：visible_ball_speed 不成立时，才考虑球丢失/运动模糊。
    # 仍然需要脚球接近作为弱约束，避免静止球漏检被误当作踢飞。
    for run_s, run_e in _runs(_close_mask(arr, cgate)):
        fallback = []
        for t in range(run_e, run_s - 1, -1):
            got = _loss_after_contact(arr, t, fps, raw_gate, rel_gate, args)
            if got:
                strength, event_idx, reappear_idx, progress = got
                fallback.append((event_idx, t, strength, reappear_idx, progress))
        if fallback:
            event_idx, t, strength, reappear, progress = min(fallback, key=lambda x: (x[0], -x[1]))
            ev = _event(event_idx, "blur_loss", min(1.0, 0.62 + 0.16 * min(strength, 2.2)),
                        f"fallback=blur_loss,contact_run={run_s+1}-{run_e+1},contact={t+1},reappear={reappear+1},strength={strength:.3f}",
                        obs, arr, max(raw_gate, rel_gate), progress)
            ev.motion_hps = float(max(raw_gate, rel_gate) * strength)
            return ev
    return None


# 生成 CSV 诊断行。
# 只在 detail=True 时调用，普通推理不会计算这些字符串/字典，避免无谓开销。
def _detail_rows(obs: List[FrameObs], arr: Dict[str, np.ndarray], cgate: float, raw_gate: float, rel_gate: float, events: List[Event]) -> List[Dict]:
    event_map = {e.frame_idx: e for e in events}
    close = _close_mask(arr, cgate)
    rows = []
    for i, o in enumerate(obs):
        e = event_map.get(i)
        rows.append({
            "frame_idx": i, "frame_id": i + 1, "time_sec": round(o.time_sec, 4),
            "ball_detected": bool(arr["valid"][i]), "ball_x": float(arr["centers"][i, 0]), "ball_y": float(arr["centers"][i, 1]),
            "nearest_foot_label": str(arr["foot_label"][i]),
            "foot_dist": float(arr["foot_dist"][i]) if np.isfinite(arr["foot_dist"][i]) else float("inf"),
            "dist_norm": float(arr["dist_norm"][i]) if np.isfinite(arr["dist_norm"][i]) else float("inf"),
            "contact_gate": float(cgate), "is_contact_candidate": bool(close[i]),
            "rel_step_hps": float(arr["rel_step_hps"][i]), "abs_step_hps": float(arr["abs_step_hps"][i]),
            "rel_motion_gate": float(rel_gate), "raw_motion_gate": float(raw_gate),
            "event_kind": e.kind if e else "", "event_confidence": e.confidence if e else 0.0,
            "event_evidence": e.evidence if e else "",
        })
    return rows


# 给 offline/online 共用的事件判断入口。
# online 会把当前已处理的前缀 obs 传进来，offline 会传完整视频 obs。
# detail=False 时不会返回逐帧 rows。
def detect_events(obs: List[FrameObs], fps: float, height: int, *, width: int = 0, detail: bool = False, args=None) -> Tuple[List[Event], Dict[str, np.ndarray], List[Dict], Dict[str, float]]:
    arr = build_arrays(obs, fps, height, width); arr["frame_h"] = float(height); arr["frame_w"] = float(width or height)
    if len(obs) < 3:
        return [], arr, [], {"reason": "too_few_frames", "decision_policy": "v10_timeline_motion_first"}
    cgate = contact_gate(arr["dist_norm"], float(_cfg(args, "contact_percentile", DEFAULT_CONTACT_PERCENTILE)))
    raw_gate, rel_gate = _motion_gates(arr, args)
    # 先按可见球高速+脚同向逻辑找事件。debug/full-session 下可返回多个，
    # online 服务仍然只会取 events[0] 作为当前轮结果。
    events = _visible_ball_speed_events(obs, arr, fps, raw_gate, args)
    if not events:
        ev = _select_event(obs, arr, fps, cgate, raw_gate, rel_gate, args)
        events = [ev] if ev else []
    for k, e in enumerate(events):
        e.event_id = k
    stats = {
        "decision_policy": "v12_visible_ball_speed_first_then_blur_loss",
        "valid_ball_ratio": float(np.mean(arr["valid"])),
        "contact_gate_dist_norm": float(cgate),
        "raw_motion_gate_hps": float(raw_gate),
        "relative_motion_gate_hps": float(rel_gate),
        "direct_horizon_frames": float(frames(float(_cfg(args, "motion_window_sec", DEFAULT_MOTION_WINDOW_SEC)), fps, 3)),
        "loss_reappear_frames": float(frames(float(_cfg(args, "loss_reappear_sec", DEFAULT_LOSS_REAPPEAR_SEC)), fps, 6)),
        "contact_percentile": float(_cfg(args, "contact_percentile", DEFAULT_CONTACT_PERCENTILE)),
        "motion_percentile": float(_cfg(args, "motion_percentile", DEFAULT_MOTION_PERCENTILE)),
        "direction_cos_thresh": float(_cfg(args, "direction_cos_thresh", DEFAULT_DIRECTION_COS)),
        "min_visible_steps": int(_cfg(args, "min_visible_steps", DEFAULT_MIN_VISIBLE_STEPS)),
        "min_ball_move_px": float(_cfg(args, "min_ball_move_px", DEFAULT_MIN_BALL_MOVE_PX)),
        "min_ball_move_ratio": float(_cfg(args, "min_ball_move_ratio", DEFAULT_MIN_BALL_MOVE_RATIO)),
        "effective_min_ball_move_px": float(_min_ball_move_px(arr, args)),
        "ball_move_lookahead_sec": float(_cfg(args, "ball_move_lookahead_sec", DEFAULT_BALL_MOVE_LOOKAHEAD_SEC)),
        "ball_move_contact_gate": float(_cfg(args, "ball_move_contact_gate", DEFAULT_BALL_MOVE_CONTACT_GATE)),
        "min_ball_speed_pxpf": float(_cfg(args, "min_ball_speed_pxpf", DEFAULT_MIN_BALL_SPEED_PXPF)),
        "effective_ball_step_gate_px": float(_ball_step_gate_px(arr, args)),
        "foot_ball_same_dir_cos": float(_cfg(args, "foot_ball_same_dir_cos", DEFAULT_FOOT_BALL_SAME_DIR_COS)),
        "min_foot_move_px": float(_cfg(args, "min_foot_move_px", DEFAULT_MIN_FOOT_MOVE_PX)),
        "strong_ball_move_mult": float(_cfg(args, "strong_ball_move_mult", DEFAULT_STRONG_BALL_MOVE_MULT)),
        "visible_require_foot_dir": float(bool(_cfg(args, "visible_require_foot_dir", DEFAULT_VISIBLE_REQUIRE_FOOT_DIR))),
        "visible_event_cooldown_sec": float(_cfg(args, "visible_event_cooldown_sec", DEFAULT_VISIBLE_EVENT_COOLDOWN_SEC)),
        "max_visible_event_dist_norm": float(_cfg(args, "max_visible_event_dist_norm", DEFAULT_MAX_VISIBLE_EVENT_DIST_NORM)),
        "ball_speed_lookback": int(_cfg(args, "ball_speed_lookback", DEFAULT_BALL_SPEED_LOOKBACK)),
        "ball_speed_jump_ratio": float(_cfg(args, "ball_speed_jump_ratio", DEFAULT_BALL_SPEED_JUMP_RATIO)),
        "event_count": float(len(events)),
        "event_found": float(bool(events)),
    }
    return events, arr, (_detail_rows(obs, arr, cgate, raw_gate, rel_gate, events) if detail else []), stats


# offline 处理完整视频。
# 流程：读全部帧 -> 批量检测球/pose -> 构造 observations -> 一次性 detect_events。
# offline 不提前停止，因此适合做最稳定的最终结果和调试基准。
def process_video_offline(video_path: Path, ball_model: YOLO, pose_model: YOLO, args, *, detail: bool = False) -> VideoResult:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count, chunk = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0), max(1, int(args.batch))
    obs: List[FrameObs] = []; track = new_track(); ball_t = pose_t = 0.0; t0 = time.time()
    while True:
        batch = []
        for _ in range(chunk):
            ok, frame = cap.read()
            if not ok: break
            batch.append(frame)
        if not batch: break
        tb = time.time(); br = predict_batch(ball_model, batch, imgsz=args.ball_imgsz, conf=args.ball_conf, args=args)
        tp = time.time(); pr = predict_batch(pose_model, batch, imgsz=args.pose_imgsz, conf=args.person_conf, args=args)
        te = time.time(); ball_t += tp - tb; pose_t += te - tp
        append_observations(obs, br, pr, ball_model, fps, w, h, track, args)
    cap.release()
    tl = time.time(); events, arr, rows, stats = detect_events(obs, fps, h, width=w, detail=detail, args=args); logic_t = time.time() - tl
    return make_result(video=Path(video_path), fps=fps, width=w, height=h, frame_count=frame_count,
                       mode="offline", early_stopped=False, observations=obs, events=events,
                       arrays=arr, detail_rows=rows, stats=stats,
                       timings={"ball_sec": ball_t, "pose_sec": pose_t, "logic_sec": logic_t, "total_sec": time.time() - t0})
