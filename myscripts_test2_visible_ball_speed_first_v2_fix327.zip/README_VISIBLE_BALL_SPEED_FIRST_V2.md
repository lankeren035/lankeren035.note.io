# Visible ball speed first v2

本版修正此前漏检/误检的核心问题：首选逻辑不再依赖严格脚球距离候选，也不再默认允许纯球速跳变直接触发。

## 事件优先级

1. `ball_speed_foot_dir`
   - 球连续可见；
   - 球心单帧大位移，超过 `max(MIN_BALL_MOVE_PX, MIN_BALL_MOVE_RATIO * image_width, MIN_BALL_SPEED_PXPF)`；
   - 当前球速相对前几帧明显突增；
   - 脚/脚尖运动方向与球运动方向一致；
   - 事件帧附近脚球距离通过宽松 sanity check，默认不超过 `MAX_VISIBLE_EVENT_DIST_NORM=2.20` 个球半径。

2. `blur_loss`
   - 只有首选可见球逻辑不成立时才使用；
   - 用于球可见后突然连续丢失、疑似运动模糊的情况。

## 为什么这样改

之前的错误主要有两个：

- 允许 `ball_speed_strong` 在没有脚同向证据时触发，容易把纯球框跳动、远处误检、非踢球飞行段误判为 kick；
- 事件帧用脚球距离在 `j-1` 和 `j` 中二选一，容易把人工答案提前一帧。现在固定使用大位移后的 `j` 帧。

在用户提供的 debug 记录中，本版检测结果为：

```text
327, 452, 556
```

## 推荐参数

```powershell
$MIN_BALL_MOVE_PX = "35"
$MIN_BALL_MOVE_RATIO = "0.03"
$MIN_BALL_SPEED_PXPF = "0"
$FOOT_BALL_SAME_DIR_COS = "0.35"
$MIN_FOOT_MOVE_PX = "15"
$VISIBLE_REQUIRE_FOOT_DIR = "1"
$VISIBLE_EVENT_COOLDOWN_SEC = "0.60"
$MAX_VISIBLE_EVENT_DIST_NORM = "2.20"
$BALL_SPEED_LOOKBACK = "3"
$BALL_SPEED_JUMP_RATIO = "1.6"
```

## 调参建议

- 如果仍然误报：

```powershell
$MAX_VISIBLE_EVENT_DIST_NORM = "2.00"
$FOOT_BALL_SAME_DIR_COS = "0.45"
$MIN_BALL_MOVE_RATIO = "0.04"
```

- 如果真实踢球漏检：

```powershell
$MAX_VISIBLE_EVENT_DIST_NORM = "2.50"
$FOOT_BALL_SAME_DIR_COS = "0.25"
$MIN_BALL_MOVE_RATIO = "0.02"
```

- 不建议关闭脚同向要求。除非调试：

```powershell
$VISIBLE_REQUIRE_FOOT_DIR = "0"
```

